import { db } from './index.ts';
import { users } from './schema.ts';

export async function getOrCreateUser(uid: string, email: string, name?: string) {
  if (!db) {
    // If PostgreSQL database is not provisioned, operate seamlessly in local storage / demo mode
    return {
      uid,
      email,
      name: name || email.split('@')[0],
      role: 'ADMIN',
      createdAt: new Date(),
    };
  }

  try {
    const result = await db
      .insert(users)
      .values({
        uid,
        email,
        name: name || email.split('@')[0],
      })
      .onConflictDoUpdate({
        target: users.uid,
        set: {
          email,
          name: name || email.split('@')[0],
        },
      })
      .returning();

    return result[0];
  } catch (error) {
    console.error('Database user upsert failed:', error);
    return {
      uid,
      email,
      name: name || email.split('@')[0],
      role: 'ADMIN',
      createdAt: new Date(),
    };
  }
}
