import React, { useState, useRef } from 'react';
import { Course } from '../../types.ts';
import { ChevronDown, Search, ArrowRight, Menu, X } from 'lucide-react';

interface HeaderNavProps {
  courses: Course[];
  searchQuery: string;
  onSearchChange: (val: string) => void;
  onSearchSubmit: () => void;
  onSelectCategory: (catSlug: string, queryText?: string) => void;
  onNavigateHome: () => void;
  onEnrollClick: (course: Course, referrer: string) => void;
  onOpenCategoryPage: (slug: string) => void;
  onNavigate?: (path: string) => void;
}

type NavKey = 'school' | 'hsc27' | 'hsc28' | 'admission' | 'popular' | 'books';

interface SubMenuItem {
  label: string;
  categorySlug: string;
  searchFilter: string;
  urlPath?: string;
}

export const HeaderNav: React.FC<HeaderNavProps> = ({
  searchQuery,
  onSearchChange,
  onSearchSubmit,
  onSelectCategory,
  onNavigateHome,
  onNavigate,
}) => {
  const [activeMenu, setActiveMenu] = useState<NavKey | null>(null);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const timeoutRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  const handleMouseEnter = (key: NavKey) => {
    if (timeoutRef.current) clearTimeout(timeoutRef.current);
    setActiveMenu(key);
  };

  const handleMouseLeave = () => {
    timeoutRef.current = setTimeout(() => {
      setActiveMenu(null);
    }, 180);
  };

  // Exact dropdown sub-items matching image_9b719cab.png with direct academic URLs
  const class6to12Items: SubMenuItem[] = [
    { label: '৬ষ্ঠ শ্রেণি– অনলাইন ব্যাচ', categorySlug: 'school', searchFilter: '৬ষ্ঠ', urlPath: '/academic/class6/' },
    { label: '৭ম শ্রেণি– অনলাইন ব্যাচ', categorySlug: 'school', searchFilter: '৭ম', urlPath: '/academic/class7/' },
    { label: '৮ম শ্রেণি– অনলাইন ব্যাচ', categorySlug: 'school', searchFilter: '৮ম', urlPath: '/academic/class8/' },
    { label: '৯ম শ্রেণি (SSC ২০২৮ ব্যাচ)', categorySlug: 'school', searchFilter: '৯ম', urlPath: '/academic/ssc/ssc-28/' },
    { label: '১০ম শ্রেণি (SSC ২০২৭ ব্যাচ)', categorySlug: 'school', searchFilter: '১০ম', urlPath: '/academic/ssc/ssc-27/' },
    { label: 'SSC 27 শেষ মুহূর্তের প্রস্তুতি', categorySlug: 'school', searchFilter: 'SSC 27', urlPath: '/academic/ssc/ssc-27/' },
    { label: 'HSC 2028 অনলাইন ব্যাচ', categorySlug: 'hsc', searchFilter: 'HSC 28', urlPath: '/academic/hsc/hsc-28/' },
    { label: 'HSC 2027 অনলাইন ব্যাচ', categorySlug: 'hsc', searchFilter: 'HSC 27', urlPath: '/academic/hsc/hsc-27/' },
  ];

  const hsc27Items: SubMenuItem[] = [
    { label: 'HSC 2027 ফুল সায়েন্স বান্ডেল', categorySlug: 'hsc', searchFilter: 'সায়েন্স বান্ডেল', urlPath: '/academic/hsc/hsc-27/' },
    { label: 'HSC 2027 সাইকেল ১ (Physics, Chemistry)', categorySlug: 'hsc', searchFilter: 'সাইকেল ১', urlPath: '/academic/hsc/hsc-27/' },
    { label: 'HSC 2027 সাইকেল ২ (Math, Biology)', categorySlug: 'hsc', searchFilter: 'সাইকেল ২', urlPath: '/academic/hsc/hsc-27/' },
    { label: 'HSC 2027 বাংলা ও ইংরেজি কোর্স', categorySlug: 'hsc', searchFilter: 'বাংলা ও ইংরেজি', urlPath: '/academic/hsc/hsc-27/' },
    { label: 'HSC 2027 শেষ মুহূর্তের রিভিশন', categorySlug: 'hsc', searchFilter: 'রিভিশন', urlPath: '/academic/hsc/hsc-27/' },
    { label: 'HSC 2027 এর সকল কোর্স দেখুন', categorySlug: 'hsc', searchFilter: '27', urlPath: '/academic/hsc/hsc-27/' },
  ];

  const hsc28Items: SubMenuItem[] = [
    { label: 'HSC 2028 PCMB সাইকেল ১ [Physics, Chem, Math, Bio]', categorySlug: 'hsc', searchFilter: 'PCMB', urlPath: '/academic/hsc/hsc-28/' },
    { label: 'HSC 2028 BEI সাইকেল ১ [বাংলা, ইংরেজি ও ICT]', categorySlug: 'hsc', searchFilter: 'BEI', urlPath: '/academic/hsc/hsc-28/' },
    { label: 'HSC 2028 ফুল ইয়ার আর্লি বার্ড বান্ডেল', categorySlug: 'hsc', searchFilter: 'বান্ডেল', urlPath: '/academic/hsc/hsc-28/' },
    { label: 'HSC 2028 ফ্রি লাইভ মাস্টারক্লাস', categorySlug: 'hsc', searchFilter: 'লাইভ', urlPath: '/academic/hsc/hsc-28/' },
    { label: 'HSC 2028 এর সকল কোর্স দেখুন', categorySlug: 'hsc', searchFilter: '28', urlPath: '/academic/hsc/hsc-28/' },
  ];

  const handleSubItemClick = (item: SubMenuItem) => {
    setActiveMenu(null);
    setMobileMenuOpen(false);
    if (item.urlPath && onNavigate) {
      onNavigate(item.urlPath);
    } else {
      onSelectCategory(item.categorySlug, item.searchFilter);
    }
  };

  const handleDirectNavClick = (key: NavKey) => {
    setActiveMenu(null);
    setMobileMenuOpen(false);
    if (key === 'school') {
      if (onNavigate) onNavigate('/academic/class6/');
      else onSelectCategory('school', '');
    } else if (key === 'hsc27') {
      if (onNavigate) onNavigate('/academic/hsc/hsc-27/');
      else onSelectCategory('hsc', 'HSC 27');
    } else if (key === 'hsc28') {
      if (onNavigate) onNavigate('/academic/hsc/hsc-28/');
      else onSelectCategory('hsc', 'HSC 28');
    } else if (key === 'admission') {
      onSelectCategory('admission', '');
    } else if (key === 'popular') {
      onSelectCategory('all', '');
    } else if (key === 'books') {
      onSelectCategory('all', 'বুক');
    }
  };

  return (
    <header className="sticky top-0 z-40 bg-white/98 backdrop-blur-md border-b border-slate-200/90 shadow-2xs">
      <div className="max-w-[1320px] mx-auto px-4 sm:px-6 py-2.5 flex items-center justify-between gap-3 lg:gap-6">
        
        {/* LEFT: 10 MINUTE SCHOOL LOGO (Matching image_1e8b1920.png) */}
        <button
          type="button"
          onClick={() => {
            setMobileMenuOpen(false);
            onNavigateHome();
          }}
          className="flex flex-col items-start cursor-pointer group shrink-0 select-none text-left"
          title="হোমপেজে ফিরে যান"
        >
          <div className="flex items-center gap-1.5">
            {/* 10 Symbol with red folded corner */}
            <div className="flex items-center">
              <span className="text-2xl sm:text-[28px] font-black tracking-tighter text-slate-900 leading-none">
                1
              </span>
              <div className="relative w-6 h-6 sm:w-7 sm:h-7 mx-0.5 flex items-center justify-center">
                <div className="w-5 h-5 sm:w-6 sm:h-6 rounded-md border-[3.5px] border-slate-900 relative overflow-hidden flex items-center justify-center">
                  <span className="absolute -top-1 -right-1 w-3 h-3 bg-red-600 rotate-45 transform" />
                </div>
              </div>
            </div>

            {/* MINUTE / SCHOOL Stack */}
            <div className="flex flex-col -space-y-0.5 leading-none">
              <span className="text-[12px] sm:text-[13px] font-black tracking-widest text-slate-800 uppercase">
                MINUTE
              </span>
              <span className="text-[12px] sm:text-[13px] font-black tracking-wider text-slate-900 uppercase">
                SCHOOL
              </span>
            </div>
          </div>

          {/* Red underline banner with domain */}
          <div className="w-full bg-[#eb1c24] text-white text-[8px] sm:text-[8.5px] font-extrabold tracking-tight px-1.5 py-[1px] mt-0.5 rounded-2xs text-center">
            10mscourses.com
          </div>
        </button>

        {/* MIDDLE: NAVBAR MENU LINKS (Exact match to requested order & style) */}
        <nav className="hidden lg:flex items-center gap-2 xl:gap-3 text-[14px] font-semibold text-slate-800 relative py-1">
          {/* 1. ক্লাস 6-12 (with dropdown) */}
          <div
            onMouseEnter={() => handleMouseEnter('school')}
            onMouseLeave={handleMouseLeave}
            className="relative"
          >
            <button
              type="button"
              onClick={() => handleDirectNavClick('school')}
              className={`flex items-center gap-1 py-1.5 px-2.5 rounded-lg transition-colors cursor-pointer whitespace-nowrap font-bold text-[13.5px] xl:text-[14px] ${
                activeMenu === 'school'
                  ? 'text-[#eb1c24] bg-red-50/70'
                  : 'text-slate-800 hover:text-[#eb1c24]'
              }`}
            >
              <span>ক্লাস 6-12</span>
              <ChevronDown
                className={`w-3.5 h-3.5 transition-transform duration-200 ${
                  activeMenu === 'school' ? 'rotate-180 text-[#eb1c24]' : 'text-slate-500'
                }`}
              />
            </button>

            {/* Compact Vertical Dropdown Card matching image_9b719cab.png */}
            {activeMenu === 'school' && (
              <div
                onMouseEnter={() => {
                  if (timeoutRef.current) clearTimeout(timeoutRef.current);
                }}
                onMouseLeave={handleMouseLeave}
                className="absolute left-0 top-full mt-1 w-[265px] bg-white rounded-b-xl shadow-xl border border-slate-100 border-t-[3px] border-t-[#eb1c24] py-1.5 z-50 animate-in fade-in slide-in-from-top-1 duration-150"
              >
                {class6to12Items.map((item, idx) => (
                  <button
                    key={idx}
                    type="button"
                    onClick={() => handleSubItemClick(item)}
                    className="w-full text-left px-4 py-2.5 text-[13px] font-semibold text-slate-800 hover:text-[#eb1c24] hover:bg-red-50/70 transition-colors flex items-center justify-between cursor-pointer"
                  >
                    <span>{item.label}</span>
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* 2. HSC 27 (with dropdown) */}
          <div
            onMouseEnter={() => handleMouseEnter('hsc27')}
            onMouseLeave={handleMouseLeave}
            className="relative"
          >
            <button
              type="button"
              onClick={() => onSelectCategory('hsc', 'HSC 27')}
              className={`flex items-center gap-1 py-1.5 px-2.5 rounded-lg transition-colors cursor-pointer whitespace-nowrap font-bold text-[13.5px] xl:text-[14px] ${
                activeMenu === 'hsc27'
                  ? 'text-[#eb1c24] bg-red-50/70'
                  : 'text-slate-800 hover:text-[#eb1c24]'
              }`}
            >
              <span>HSC 27</span>
              <ChevronDown
                className={`w-3.5 h-3.5 transition-transform duration-200 ${
                  activeMenu === 'hsc27' ? 'rotate-180 text-[#eb1c24]' : 'text-slate-500'
                }`}
              />
            </button>

            {/* Compact Vertical Dropdown Card */}
            {activeMenu === 'hsc27' && (
              <div
                onMouseEnter={() => {
                  if (timeoutRef.current) clearTimeout(timeoutRef.current);
                }}
                onMouseLeave={handleMouseLeave}
                className="absolute left-0 top-full mt-1 w-[285px] bg-white rounded-b-xl shadow-xl border border-slate-100 border-t-[3px] border-t-[#eb1c24] py-1.5 z-50 animate-in fade-in slide-in-from-top-1 duration-150"
              >
                {hsc27Items.map((item, idx) => (
                  <button
                    key={idx}
                    type="button"
                    onClick={() => handleSubItemClick(item)}
                    className="w-full text-left px-4 py-2.5 text-[13px] font-semibold text-slate-800 hover:text-[#eb1c24] hover:bg-red-50/70 transition-colors flex items-center justify-between cursor-pointer"
                  >
                    <span>{item.label}</span>
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* 3. HSC 28 (with dropdown) */}
          <div
            onMouseEnter={() => handleMouseEnter('hsc28')}
            onMouseLeave={handleMouseLeave}
            className="relative"
          >
            <button
              type="button"
              onClick={() => onSelectCategory('hsc', 'HSC 28')}
              className={`flex items-center gap-1 py-1.5 px-2.5 rounded-lg transition-colors cursor-pointer whitespace-nowrap font-bold text-[13.5px] xl:text-[14px] ${
                activeMenu === 'hsc28'
                  ? 'text-[#eb1c24] bg-red-50/70'
                  : 'text-slate-800 hover:text-[#eb1c24]'
              }`}
            >
              <span>HSC 28</span>
              <ChevronDown
                className={`w-3.5 h-3.5 transition-transform duration-200 ${
                  activeMenu === 'hsc28' ? 'rotate-180 text-[#eb1c24]' : 'text-slate-500'
                }`}
              />
            </button>

            {/* Compact Vertical Dropdown Card */}
            {activeMenu === 'hsc28' && (
              <div
                onMouseEnter={() => {
                  if (timeoutRef.current) clearTimeout(timeoutRef.current);
                }}
                onMouseLeave={handleMouseLeave}
                className="absolute left-0 top-full mt-1 w-[300px] bg-white rounded-b-xl shadow-xl border border-slate-100 border-t-[3px] border-t-[#eb1c24] py-1.5 z-50 animate-in fade-in slide-in-from-top-1 duration-150"
              >
                {hsc28Items.map((item, idx) => (
                  <button
                    key={idx}
                    type="button"
                    onClick={() => handleSubItemClick(item)}
                    className="w-full text-left px-4 py-2.5 text-[13px] font-semibold text-slate-800 hover:text-[#eb1c24] hover:bg-red-50/70 transition-colors flex items-center justify-between cursor-pointer"
                  >
                    <span>{item.label}</span>
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* 4. ভর্তি পরীক্ষা (Direct Link) */}
          <button
            type="button"
            onClick={() => handleDirectNavClick('admission')}
            className="py-1.5 px-2.5 rounded-lg transition-colors cursor-pointer whitespace-nowrap font-bold text-[13.5px] xl:text-[14px] text-slate-800 hover:text-[#eb1c24]"
          >
            ভর্তি পরীক্ষা
          </button>

          {/* 5. জনপ্রিয় (Direct Link) */}
          <button
            type="button"
            onClick={() => handleDirectNavClick('popular')}
            className="py-1.5 px-2.5 rounded-lg transition-colors cursor-pointer whitespace-nowrap font-bold text-[13.5px] xl:text-[14px] text-slate-800 hover:text-[#eb1c24]"
          >
            জনপ্রিয়
          </button>

          {/* 6. বুক স্টোর (Direct Link) */}
          <button
            type="button"
            onClick={() => handleDirectNavClick('books')}
            className="py-1.5 px-2.5 rounded-lg transition-colors cursor-pointer whitespace-nowrap font-bold text-[13.5px] xl:text-[14px] text-slate-800 hover:text-[#eb1c24]"
          >
            বুক স্টোর
          </button>
        </nav>

        {/* RIGHT: SEARCH BAR WITH GREEN CIRCULAR ICON BUTTON (Exact matching image_1e8b1920.png) */}
        <div className="flex items-center gap-2 max-w-[280px] sm:max-w-[320px] w-full">
          <form
            onSubmit={(e) => {
              e.preventDefault();
              onSearchSubmit();
            }}
            className="relative flex items-center w-full bg-slate-50/90 hover:bg-white focus-within:bg-white border border-slate-300 focus-within:border-emerald-600 rounded-full pl-3.5 pr-1 py-1 transition-all shadow-2xs"
          >
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => onSearchChange(e.target.value)}
              placeholder="কোর্স সার্চ করুন..."
              className="w-full bg-transparent border-none outline-none text-xs sm:text-[13px] text-slate-800 placeholder-slate-400 font-medium pr-1"
            />

            {/* Circular Green Search Button matching image_1e8b1920.png */}
            <button
              type="submit"
              className="w-7 h-7 sm:w-8 sm:h-8 rounded-full bg-[#107c41] hover:bg-[#0b6132] text-white flex items-center justify-center shrink-0 cursor-pointer shadow-xs transition-transform active:scale-95"
              title="সার্চ করুন"
            >
              <Search className="w-3.5 h-3.5 sm:w-4 sm:h-4 stroke-[2.5]" />
            </button>
          </form>

          {/* Mobile hamburger menu toggle */}
          <button
            type="button"
            onClick={() => setMobileMenuOpen((prev) => !prev)}
            className="lg:hidden p-2 rounded-lg text-slate-700 hover:bg-slate-100 cursor-pointer"
            aria-label="Toggle Navigation Menu"
          >
            {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>
        </div>
      </div>

      {/* MOBILE EXPANDED MENU DRAWER */}
      {mobileMenuOpen && (
        <div className="lg:hidden bg-white border-t border-slate-200 px-4 py-3 shadow-lg space-y-3 animate-in fade-in">
          <div className="space-y-1">
            <div className="text-xs font-bold text-slate-400 px-2 py-1 uppercase tracking-wider">
              কোর্স ক্যাটাগরি ও ব্যাচ
            </div>

            {/* ক্লাস 6-12 collapsible section */}
            <details className="group">
              <summary className="flex items-center justify-between px-3 py-2 rounded-lg text-sm font-bold text-slate-800 hover:bg-slate-50 cursor-pointer list-none">
                <span>ক্লাস 6-12</span>
                <ChevronDown className="w-4 h-4 text-slate-400 group-open:rotate-180 transition-transform" />
              </summary>
              <div className="pl-3 pr-1 py-1 space-y-1 border-l-2 border-red-500 ml-3 my-1">
                {class6to12Items.map((item, idx) => (
                  <button
                    key={idx}
                    type="button"
                    onClick={() => handleSubItemClick(item)}
                    className="w-full text-left px-2.5 py-2 text-xs rounded-md text-slate-700 hover:text-[#eb1c24] hover:bg-red-50/70 font-medium transition-colors"
                  >
                    {item.label}
                  </button>
                ))}
              </div>
            </details>

            {/* HSC 27 collapsible section */}
            <details className="group">
              <summary className="flex items-center justify-between px-3 py-2 rounded-lg text-sm font-bold text-slate-800 hover:bg-slate-50 cursor-pointer list-none">
                <span>HSC 27</span>
                <ChevronDown className="w-4 h-4 text-slate-400 group-open:rotate-180 transition-transform" />
              </summary>
              <div className="pl-3 pr-1 py-1 space-y-1 border-l-2 border-red-500 ml-3 my-1">
                {hsc27Items.map((item, idx) => (
                  <button
                    key={idx}
                    type="button"
                    onClick={() => handleSubItemClick(item)}
                    className="w-full text-left px-2.5 py-2 text-xs rounded-md text-slate-700 hover:text-[#eb1c24] hover:bg-red-50/70 font-medium transition-colors"
                  >
                    {item.label}
                  </button>
                ))}
              </div>
            </details>

            {/* HSC 28 collapsible section */}
            <details className="group">
              <summary className="flex items-center justify-between px-3 py-2 rounded-lg text-sm font-bold text-slate-800 hover:bg-slate-50 cursor-pointer list-none">
                <span>HSC 28</span>
                <ChevronDown className="w-4 h-4 text-slate-400 group-open:rotate-180 transition-transform" />
              </summary>
              <div className="pl-3 pr-1 py-1 space-y-1 border-l-2 border-red-500 ml-3 my-1">
                {hsc28Items.map((item, idx) => (
                  <button
                    key={idx}
                    type="button"
                    onClick={() => handleSubItemClick(item)}
                    className="w-full text-left px-2.5 py-2 text-xs rounded-md text-slate-700 hover:text-[#eb1c24] hover:bg-red-50/70 font-medium transition-colors"
                  >
                    {item.label}
                  </button>
                ))}
              </div>
            </details>

            {/* Direct links */}
            <button
              type="button"
              onClick={() => handleDirectNavClick('admission')}
              className="w-full text-left px-3 py-2 rounded-lg text-sm font-bold text-slate-800 hover:bg-slate-50 hover:text-[#eb1c24]"
            >
              ভর্তি পরীক্ষা
            </button>
            <button
              type="button"
              onClick={() => handleDirectNavClick('popular')}
              className="w-full text-left px-3 py-2 rounded-lg text-sm font-bold text-slate-800 hover:bg-slate-50 hover:text-[#eb1c24]"
            >
              জনপ্রিয় কোর্স
            </button>
            <button
              type="button"
              onClick={() => handleDirectNavClick('books')}
              className="w-full text-left px-3 py-2 rounded-lg text-sm font-bold text-slate-800 hover:bg-slate-50 hover:text-[#eb1c24]"
            >
              বুক স্টোর ও প্রিন্টেড নোট
            </button>
          </div>
        </div>
      )}
    </header>
  );
};
