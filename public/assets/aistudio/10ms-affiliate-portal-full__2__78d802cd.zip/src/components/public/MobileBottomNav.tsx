import React from 'react';

export type MobileTab = 'home' | 'hsc27' | 'skills' | 'school' | 'hsc28' | 'admission';

interface MobileBottomNavProps {
  activeTab: MobileTab;
  onTabChange: (tab: MobileTab) => void;
}

export const MobileBottomNav: React.FC<MobileBottomNavProps> = ({
  activeTab,
  onTabChange,
}) => {
  const tabs = [
    {
      id: 'home' as MobileTab,
      label: 'Home',
      icon: (isActive: boolean) => (
        <svg
          className={`w-6 h-6 transition-colors ${isActive ? 'text-[#eb1c24]' : 'text-slate-600'}`}
          viewBox="0 0 24 24"
          fill="currentColor"
        >
          <path d="M12 3L2 12h3v8h6v-6h2v6h6v-8h3L12 3z" />
        </svg>
      ),
    },
    {
      id: 'hsc27' as MobileTab,
      label: 'HSC 27',
      icon: (isActive: boolean) => (
        <svg
          className={`w-6 h-6 transition-colors ${isActive ? 'text-[#eb1c24]' : 'text-slate-600'}`}
          viewBox="0 0 24 24"
          fill="none"
          stroke="currentColor"
          strokeWidth="2"
          strokeLinecap="round"
          strokeLinejoin="round"
        >
          {/* Person on left */}
          <circle cx="6" cy="8" r="2.5" fill={isActive ? '#eb1c24' : 'currentColor'} stroke="none" />
          <path d="M2.5 19c0-2.8 2.3-5 5-5s5 2.2 5 5" fill={isActive ? '#eb1c24' : 'currentColor'} stroke="none" />
          {/* Presentation board / screen on right */}
          <rect x="11" y="4" width="11" height="9" rx="1.5" />
          <line x1="16.5" y1="13" x2="16.5" y2="19" />
          <line x1="14" y1="19" x2="19" y2="19" />
        </svg>
      ),
    },
    {
      id: 'skills' as MobileTab,
      label: 'Skills',
      icon: (isActive: boolean) => (
        <svg
          className={`w-6 h-6 transition-colors ${isActive ? 'text-[#eb1c24]' : 'text-slate-600'}`}
          viewBox="0 0 24 24"
          fill={isActive ? '#eb1c24' : 'currentColor'}
        >
          <path d="M9.19 6.35c-2.04 2.29-3.44 5.58-3.57 5.89-.25.59-.14 1.27.3 1.74l3.78 3.78c.34.34.8.52 1.26.52.16 0 .32-.02.48-.07.31-.13 3.6-1.53 5.89-3.57 2.05-1.83 3.67-4.43 4.67-7.64.21-.68-.38-1.27-1.06-1.06-3.21 1-5.81 2.62-7.64 4.67zM15 11a2 2 0 1 1 0-4 2 2 0 0 1 0 4z" />
          <path d="M4.5 15.5l-2 4 4-2c-.63-.63-1.37-1.37-2-2z" />
          <path d="M19.5 8.5c-.63-.63-1.37-1.37-2-2l-2 4 4-2z" />
        </svg>
      ),
    },
    {
      id: 'school' as MobileTab,
      label: '6 to 12',
      icon: (isActive: boolean) => (
        <svg
          className={`w-6 h-6 transition-colors ${isActive ? 'text-[#eb1c24]' : 'text-slate-600'}`}
          viewBox="0 0 24 24"
          fill="none"
          stroke="currentColor"
          strokeWidth="1.8"
          strokeLinecap="round"
          strokeLinejoin="round"
        >
          {/* School house with pediment, clock, and windows matching image_59f09c57.png */}
          <path d="M12 2L2 7v13h20V7L12 2z" />
          <circle cx="12" cy="7.5" r="1.75" fill={isActive ? '#eb1c24' : 'currentColor'} stroke="none" />
          <rect x="5" y="11" width="3" height="3" fill={isActive ? '#eb1c24' : 'currentColor'} stroke="none" />
          <rect x="16" y="11" width="3" height="3" fill={isActive ? '#eb1c24' : 'currentColor'} stroke="none" />
          <path d="M10 20v-5h4v5" />
        </svg>
      ),
    },
    {
      id: 'hsc28' as MobileTab,
      label: 'HSC 28',
      icon: (isActive: boolean) => (
        <svg
          className={`w-6 h-6 transition-colors ${isActive ? 'text-[#eb1c24]' : 'text-slate-600'}`}
          viewBox="0 0 24 24"
          fill="none"
          stroke="currentColor"
          strokeWidth="2"
          strokeLinecap="round"
          strokeLinejoin="round"
        >
          <circle cx="6" cy="8" r="2.5" fill={isActive ? '#eb1c24' : 'currentColor'} stroke="none" />
          <path d="M2.5 19c0-2.8 2.3-5 5-5s5 2.2 5 5" fill={isActive ? '#eb1c24' : 'currentColor'} stroke="none" />
          <rect x="11" y="4" width="11" height="9" rx="1.5" />
          <line x1="16.5" y1="13" x2="16.5" y2="19" />
          <line x1="14" y1="19" x2="19" y2="19" />
        </svg>
      ),
    },
    {
      id: 'admission' as MobileTab,
      label: 'Admission',
      icon: (isActive: boolean) => (
        <svg
          className={`w-6 h-6 transition-colors ${isActive ? 'text-[#eb1c24]' : 'text-slate-600'}`}
          viewBox="0 0 24 24"
          fill={isActive ? '#eb1c24' : 'currentColor'}
        >
          <path d="M12 3L1 9l11 6 9-4.91V17h2V9L12 3z" />
          <path d="M5 13.18v4L12 21l7-3.82v-4L12 17l-7-3.82z" />
        </svg>
      ),
    },
  ];

  return (
    <nav
      aria-label="Mobile Bottom Navigation"
      style={{ paddingBottom: 'calc(0.35rem + env(safe-area-inset-bottom, 0px))' }}
      className="md:hidden fixed bottom-0 left-0 right-0 z-50 bg-white/95 backdrop-blur-md border-t border-slate-200/90 pt-1.5 px-0.5 shadow-[0_-4px_20px_rgba(0,0,0,0.08)] flex justify-around items-center"
    >
      {tabs.map((tab) => {
        const isActive = activeTab === tab.id;
        return (
          <button
            key={tab.id}
            type="button"
            onClick={() => onTabChange(tab.id)}
            className="flex flex-col items-center justify-center py-1 px-1 min-w-[48px] max-w-[62px] flex-1 cursor-pointer transition-all active:scale-95 group touch-manipulation select-none"
          >
            <div className="relative flex items-center justify-center h-5 w-5 sm:h-6 sm:w-6">
              {tab.icon(isActive)}
            </div>
            <span
              className={`text-[9.5px] sm:text-[10.5px] font-bold mt-1 tracking-tight transition-colors truncate max-w-full ${
                isActive ? 'text-[#eb1c24]' : 'text-slate-600 group-hover:text-slate-900'
              }`}
            >
              {tab.label}
            </span>
          </button>
        );
      })}
    </nav>
  );
};
