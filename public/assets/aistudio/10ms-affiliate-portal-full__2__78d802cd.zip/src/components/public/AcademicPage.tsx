import React, { useState, useMemo } from 'react';
import { Course } from '../../types.ts';
import { CourseCard } from './CourseCard.tsx';
import { toBengaliNumber } from '../../utils/format.ts';
import { Search, Sparkles, BookOpen, GraduationCap, ChevronRight, CheckCircle2 } from 'lucide-react';
import { motion } from 'motion/react';

export type AcademicLevel = 'ssc' | 'hsc' | 'class';

export type DepartmentType = 'all' | 'science' | 'business' | 'humanities';

interface AcademicPageProps {
  level: AcademicLevel;
  batchOrClass: string; // e.g. 'ssc-27', 'ssc-28', 'hsc-26', 'hsc-27', 'hsc-28', 'class6', 'class7', 'class8', 'class9', 'class10'
  courses: Course[];
  onNavigate: (path: string) => void;
  onEnrollClick: (course: Course, referrer: string) => void;
}

interface ToggleOption {
  id: string;
  label: string;
  subLabel?: string;
  path: string;
}

export const AcademicPage: React.FC<AcademicPageProps> = ({
  level,
  batchOrClass,
  courses,
  onNavigate,
  onEnrollClick,
}) => {
  const [selectedDept, setSelectedDept] = useState<DepartmentType>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [priceFilter, setPriceFilter] = useState('all');

  // Define toggle buttons per academic level
  const toggleOptions: ToggleOption[] = useMemo(() => {
    if (level === 'ssc') {
      return [
        { id: 'ssc-27', label: 'SSC 27', subLabel: 'দশম শ্রেণি', path: '/academic/ssc/ssc-27/' },
        { id: 'ssc-28', label: 'SSC 28', subLabel: '৯ম শ্রেণি', path: '/academic/ssc/ssc-28/' },
      ];
    }
    if (level === 'hsc') {
      return [
        { id: 'hsc-26', label: 'HSC 26', subLabel: 'এডমিশন ও রিভিশন', path: '/academic/hsc/hsc-26/' },
        { id: 'hsc-27', label: 'HSC 27', subLabel: '২য় বর্ষ', path: '/academic/hsc/hsc-27/' },
        { id: 'hsc-28', label: 'HSC 28', subLabel: '১ম বর্ষ', path: '/academic/hsc/hsc-28/' },
      ];
    }
    // class 6 - 10
    return [
      { id: 'class6', label: 'Class 6', subLabel: '৬ষ্ঠ শ্রেণি', path: '/academic/class6/' },
      { id: 'class7', label: 'Class 7', subLabel: '৭ম শ্রেণি', path: '/academic/class7/' },
      { id: 'class8', label: 'Class 8', subLabel: '৮ম শ্রেণি', path: '/academic/class8/' },
      { id: 'class9', label: 'Class 9', subLabel: '৯ম শ্রেণি', path: '/academic/class9/' },
      { id: 'class10', label: 'Class 10', subLabel: '১০ম শ্রেণি', path: '/academic/class10/' },
    ];
  }, [level]);

  // Compute page heading details
  const pageDetails = useMemo(() => {
    if (level === 'ssc') {
      const isSsc27 = batchOrClass === 'ssc-27';
      return {
        badge: isSsc27 ? 'SSC ২০২৭ প্রস্তুতি' : 'SSC ২০২৮ প্রস্তুতি',
        title: isSsc27 ? 'SSC 27 একাডেমিক অনলাইন ব্যাচ' : 'SSC 28 একাডেমিক অনলাইন ব্যাচ',
        subtitle: isSsc27
          ? '১০ম শ্রেণি ও এসএসসি ২০২৭ পরীক্ষার্থীদের জন্য বিষয়ভিত্তিক লাইভ ক্লাস, মডেল টেস্ট ও বোর্ড রিভিশন।'
          : '৯ম শ্রেণি (SSC ২০২৮) শিক্ষার্থীদের জন্য নতুন কারিকুলাম ও বোর্ড সিলেবাসের গোছানো অনলাইন ব্যাচ।',
        activeName: isSsc27 ? 'SSC 27' : 'SSC 28',
      };
    }
    if (level === 'hsc') {
      let bTitle = 'HSC 28';
      let bSub = 'HSC ২০২৮ ব্যাচ এর সম্পূর্ণ সাইকেল কভারেজ ও ফুল ইয়ার লাইভ ক্লাস';
      if (batchOrClass === 'hsc-26') {
        bTitle = 'HSC 26';
        bSub = 'HSC ২৬ পরীক্ষার্থীদের শেষ মুহূর্তের টেস্ট পেপার সলভিং ও পূর্ণাঙ্গ বিশ্ববিদ্যালয় এডমিশন প্রস্তুতি';
      } else if (batchOrClass === 'hsc-27') {
        bTitle = 'HSC 27';
        bSub = 'HSC ২৭ ২য় বর্ষের বিজ্ঞান, মানবিক ও ব্যবসায় শিক্ষা পূর্ণাঙ্গ সিলেবাস রিভিশন ও মডেল টেস্ট';
      }
      return {
        badge: `${bTitle} অনলাইন ব্যাচ`,
        title: `${bTitle} একাডেমিক অনলাইন প্রোগ্রাম`,
        subtitle: bSub,
        activeName: bTitle,
      };
    }

    // class levels
    const classNum = batchOrClass.replace('class', '');
    const ordinalMap: Record<string, string> = {
      '6': '৬ষ্ঠ',
      '7': '৭ম',
      '8': '৮ম',
      '9': '৯ম',
      '10': '১০ম',
    };
    const bengaliOrdinal = ordinalMap[classNum] || `${toBengaliNumber(parseInt(classNum, 10) || 6)}ষ্ঠ`;
    return {
      badge: `${bengaliOrdinal} শ্রেণি একাডেমিক`,
      title: `${bengaliOrdinal} শ্রেণি অনলাইন ব্যাচ ও বার্ষিক প্রস্তুতি`,
      subtitle: `জাতীয় শিক্ষাক্রমের আলোকে ${bengaliOrdinal} শ্রেণির সকল বিষয়ের গোছানো লাইভ ক্লাস ও নিয়মিত মূল্যায়ন পরীক্ষা।`,
      activeName: `Class ${classNum}`,
    };
  }, [level, batchOrClass]);

  // Filter courses strictly for this active batch/class
  const batchCourses = useMemo(() => {
    return courses.filter((c) => {
      const text = `${c.title} ${c.slug} ${c.headerTitle} ${c.headerSubtitle} ${c.targetStudents || ''} ${c.description} ${c.categorySlug}`.toLowerCase();

      if (level === 'ssc') {
        if (batchOrClass === 'ssc-27') {
          return (
            text.includes('ssc 27') ||
            text.includes('ssc-27') ||
            text.includes('ssc ২০২৭') ||
            text.includes('১০ম') ||
            text.includes('class-10') ||
            text.includes('দশম')
          );
        }
        if (batchOrClass === 'ssc-28') {
          return (
            text.includes('ssc 28') ||
            text.includes('ssc-28') ||
            text.includes('ssc ২০২৮') ||
            text.includes('৯ম') ||
            text.includes('class-9') ||
            text.includes('নবম')
          );
        }
      }

      if (level === 'hsc') {
        if (batchOrClass === 'hsc-26') {
          return (
            text.includes('hsc 26') ||
            text.includes('hsc-26') ||
            text.includes('hsc ২৬') ||
            text.includes('hsc ২০২৬') ||
            text.includes('varsity') ||
            text.includes('admission') ||
            text.includes('এডমিশন') ||
            text.includes('মেডিকেল') ||
            text.includes('বুয়েট') ||
            text.includes('buet')
          );
        }
        if (batchOrClass === 'hsc-27') {
          return (
            text.includes('hsc 27') ||
            text.includes('hsc-27') ||
            text.includes('hsc ২৭') ||
            text.includes('hsc ২০২৭')
          );
        }
        if (batchOrClass === 'hsc-28') {
          return (
            text.includes('hsc 28') ||
            text.includes('hsc-28') ||
            text.includes('hsc ২৮') ||
            text.includes('hsc ২০২৮')
          );
        }
      }

      if (level === 'class') {
        if (batchOrClass === 'class6') {
          return text.includes('৬ষ্ঠ') || text.includes('class 6') || text.includes('class-6');
        }
        if (batchOrClass === 'class7') {
          return text.includes('৭ম') || text.includes('class 7') || text.includes('class-7');
        }
        if (batchOrClass === 'class8') {
          return text.includes('৮ম') || text.includes('class 8') || text.includes('class-8');
        }
        if (batchOrClass === 'class9') {
          return (
            text.includes('৯ম') ||
            text.includes('class 9') ||
            text.includes('class-9') ||
            text.includes('ssc 28') ||
            text.includes('ssc-28')
          );
        }
        if (batchOrClass === 'class10') {
          return (
            text.includes('১০ম') ||
            text.includes('class 10') ||
            text.includes('class-10') ||
            text.includes('ssc 27') ||
            text.includes('ssc-27') ||
            text.includes('দশম')
          );
        }
      }

      return false;
    });
  }, [level, batchOrClass, courses]);

  // Helper to categorize course by department
  const getCourseDepartment = (c: Course): DepartmentType => {
    const text = `${c.title} ${c.slug} ${c.headerTitle} ${c.headerSubtitle} ${c.targetStudents || ''} ${c.description}`.toLowerCase();

    const isBusiness =
      text.includes('ব্যবসায়') ||
      text.includes('বাণিজ্য') ||
      text.includes('কমার্শ') ||
      text.includes('commerce') ||
      text.includes('business') ||
      text.includes('হিসাববিজ্ঞান') ||
      text.includes('ফিন্যান্স') ||
      text.includes('ব্যাংকিং') ||
      text.includes('c-unit') ||
      text.includes('গ’ ইউনিট');

    const isHumanities =
      text.includes('মানবিক') ||
      text.includes('আর্টস') ||
      text.includes('humanities') ||
      text.includes('arts') ||
      text.includes('ইতিহাস') ||
      text.includes('পৌরনীতি') ||
      text.includes('ভূগোল') ||
      text.includes('অর্থনীতি') ||
      text.includes('যুক্তিবিদ্যা');

    const isScience =
      text.includes('বিজ্ঞান') ||
      text.includes('সায়েন্স') ||
      text.includes('science') ||
      text.includes('pcmb') ||
      text.includes('physics') ||
      text.includes('chem') ||
      text.includes('biology') ||
      text.includes('পদার্থ') ||
      text.includes('রসায়ন') ||
      text.includes('উচ্চতর গণিত') ||
      text.includes('গণিত') ||
      text.includes('বুয়েট') ||
      text.includes('মেডিকেল') ||
      text.includes('ভার্সিটি ‘ক’');

    if (isScience && !isBusiness && !isHumanities) return 'science';
    if (isBusiness && !isScience && !isHumanities) return 'business';
    if (isHumanities && !isScience && !isBusiness) return 'humanities';

    // If covers multiple or common (like BEI or general batch)
    if (isBusiness) return 'business';
    if (isHumanities) return 'humanities';
    if (isScience) return 'science';

    return 'all';
  };

  // Department counts within current active batch
  const departmentCounts = useMemo(() => {
    const counts = { all: batchCourses.length, science: 0, business: 0, humanities: 0 };
    batchCourses.forEach((c) => {
      const dept = getCourseDepartment(c);
      if (dept === 'science') counts.science += 1;
      else if (dept === 'business') counts.business += 1;
      else if (dept === 'humanities') counts.humanities += 1;
      else {
        // General course applies across all departments
        counts.science += 1;
        counts.business += 1;
        counts.humanities += 1;
      }
    });
    return counts;
  }, [batchCourses]);

  // Apply Subject Category filter + search + price filter
  const displayedCourses = useMemo(() => {
    return batchCourses.filter((c) => {
      // 1. Department filter
      if (selectedDept !== 'all') {
        const dept = getCourseDepartment(c);
        if (dept !== selectedDept && dept !== 'all') {
          return false;
        }
      }

      // 2. Search query filter
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase().trim();
        const text = `${c.title} ${c.headerTitle} ${c.headerSubtitle} ${c.description}`.toLowerCase();
        if (!text.includes(q)) return false;
      }

      // 3. Price filter
      if (priceFilter === 'under3000' && c.discountPrice > 3000) return false;
      if (priceFilter === '3000to5000' && (c.discountPrice <= 3000 || c.discountPrice > 5000))
        return false;
      if (priceFilter === 'above5000' && c.discountPrice <= 5000) return false;

      return true;
    });
  }, [batchCourses, selectedDept, searchQuery, priceFilter]);

  return (
    <div className="min-h-screen bg-slate-50/60 pb-16">
      {/* =========================================================================
          HERO SECTION: MATCHING EXISTING WEBSITE DESIGN & DARK GRADIENT THEME
          Dark Navy/Black Gradient (#0B0F19 via #111827 to #0B0F19)
          Ambient blur orbs, subtle red SVG pattern, centered Heading & gradient text
          ========================================================================= */}
      <section className="relative bg-gradient-to-b from-[#0B0F19] via-[#111827] to-[#0B0F19] text-white pt-8 sm:pt-10 pb-12 sm:pb-16 overflow-hidden border-b border-slate-800">
        {/* Subtle Background Pattern */}
        <div
          className="absolute inset-0 pointer-events-none z-0"
          style={{
            backgroundImage: `url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='220' height='220' viewBox='0 0 220 220'%3E%3Cg fill='none' stroke='%23E22B2B' stroke-width='1.6' stroke-linecap='round' stroke-linejoin='round' opacity='0.12'%3E%3Cpath d='M18 30c8-4 18-4 24 0v26c-6-4-16-4-24 0z'/%3E%3Cpath d='M66 30c-8-4-18-4-24 0v26c6-4 16-4 24 0z'/%3E%3Cpath d='M120 24l14 14-30 30-16 3 3-16z'/%3E%3Cpath d='M131 35l-6-6'/%3E%3Cpath d='M170 100l30-12-30-12-30 12z'/%3E%3Cpath d='M155 92v16c0 5 8 9 15 9s15-4 15-9V92'/%3E%3Cpath d='M200 89v18'/%3E%3Ccircle cx='40' cy='140' r='14'/%3E%3Cpath d='M34 158h12'/%3E%3Cpath d='M36 152h8'/%3E%3Crect x='100' y='150' width='60' height='14' rx='2' transform='rotate(-12 100 150)'/%3E%3Cpath d='M188 150l4 9 10 1-7 7 2 10-9-5-9 5 2-10-7-7 10-1z'/%3E%3C/g%3E%3C/svg%3E")`,
            backgroundSize: '220px 220px',
            backgroundRepeat: 'repeat',
          }}
        />

        {/* Ambient Glow Orbs */}
        <div className="absolute top-0 left-1/4 w-80 h-80 bg-red-600/15 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute top-1/3 right-10 w-80 h-80 bg-emerald-600/15 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute -bottom-10 left-1/2 -translate-x-1/2 w-[500px] h-32 bg-blue-500/10 rounded-full blur-3xl pointer-events-none" />

        <div className="max-w-[1240px] mx-auto px-4 sm:px-6 relative z-10">
          {/* Breadcrumb Navigation */}
          <div className="flex items-center gap-2 text-xs text-slate-400 font-medium mb-6">
            <button
              type="button"
              onClick={() => onNavigate('/')}
              className="hover:text-white transition-colors cursor-pointer"
            >
              হোম
            </button>
            <span className="text-slate-600">/</span>
            <span className="text-slate-400">একাডেমিক</span>
            <span className="text-slate-600">/</span>
            <span className="text-emerald-400 font-bold">{pageDetails.activeName}</span>
          </div>

          {/* Centered Heading with Gradient */}
          <motion.div
            initial={{ opacity: 0, y: 18 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.4 }}
            className="text-center max-w-3xl mx-auto mb-8"
          >
            <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-emerald-500/10 border border-emerald-500/30 text-emerald-300 text-xs font-bold mb-3 shadow-xs">
              <Sparkles className="w-3.5 h-3.5 text-emerald-400" />
              <span>{pageDetails.badge}</span>
            </div>

            <h1 className="text-2xl sm:text-4xl md:text-5xl font-black text-white tracking-tight mb-3">
              {pageDetails.title.split(' ')[0]}{' '}
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-emerald-400 via-teal-300 to-cyan-400">
                {pageDetails.title.split(' ').slice(1).join(' ')}
              </span>
            </h1>

            <p className="text-xs sm:text-sm md:text-base text-slate-300 font-normal leading-relaxed max-w-2xl mx-auto">
              {pageDetails.subtitle}
            </p>
          </motion.div>

          {/* =========================================================================
              TOGGLE BUTTONS IN A SINGLE ROW
              Active button: Green (#107c41 / #10b981), White Text, Bold, Subtle Glow
              Inactive button: Dark translucent (bg-slate-900/80 border-slate-700/60)
              Clicking navigates to specific separate URL via onNavigate()
              ========================================================================= */}
          {/* =========================================================================
              TOGGLE BUTTONS IN A SINGLE ROW
              Active button: Green (#107c41 / #10b981), White Text, Bold, Subtle Glow
              Inactive button: Dark translucent (bg-slate-900/80 border-slate-700/60)
              Clicking navigates to specific separate URL via onNavigate()
              ========================================================================= */}
          <div className="flex items-center justify-center mb-6 w-full px-1">
            <div className="flex items-center gap-1.5 sm:gap-2.5 p-1.5 sm:p-2 rounded-2xl bg-slate-950/90 border border-slate-800 backdrop-blur-xl shadow-2xl max-w-full overflow-x-auto no-scrollbar scroll-smooth justify-start sm:justify-center mx-auto">
              {toggleOptions.map((opt) => {
                const isActive = opt.id === batchOrClass;
                return (
                  <button
                    key={opt.id}
                    type="button"
                    onClick={() => {
                      if (!isActive) {
                        onNavigate(opt.path);
                      }
                    }}
                    className={`px-3.5 sm:px-5 py-2 sm:py-2.5 rounded-xl text-xs sm:text-sm font-black transition-all cursor-pointer whitespace-nowrap shrink-0 flex items-center gap-1.5 sm:gap-2 ${
                      isActive
                        ? 'bg-[#107c41] text-white shadow-lg shadow-emerald-950/50 border border-emerald-400/50 scale-[1.02]'
                        : 'bg-slate-900/90 text-slate-300 hover:text-white hover:bg-slate-800 border border-slate-800/80'
                    }`}
                  >
                    <span>{opt.label}</span>
                    {opt.subLabel && (
                      <span
                        className={`text-[10px] sm:text-[11px] font-semibold px-1.5 sm:px-2 py-0.5 rounded-md shrink-0 ${
                          isActive
                            ? 'bg-black/25 text-emerald-100'
                            : 'bg-white/5 text-slate-400 group-hover:text-slate-300'
                        }`}
                      >
                        {opt.subLabel}
                      </span>
                    )}
                  </button>
                );
              })}
            </div>
          </div>
        </div>
      </section>

      {/* =========================================================================
          SUBJECT CATEGORY NAVIGATION & FILTER STRIP (Within Current Page)
          Tabs: All | Science | Business Studies | Humanities
          Rule: Clicking Subject Category filters only courses in current page
                WITHOUT navigating away or altering the active year/URL!
          ========================================================================= */}
      <section className="max-w-[1240px] mx-auto px-4 sm:px-6 -mt-6 sm:-mt-7 relative z-20">
        <div className="bg-white rounded-2xl sm:rounded-3xl border border-slate-200/90 p-3.5 sm:p-5 shadow-lg flex flex-col md:flex-row md:items-center justify-between gap-3 sm:gap-4">
          
          {/* Department Tabs */}
          <div className="flex items-center gap-1.5 sm:gap-2 overflow-x-auto pb-1 md:pb-0 no-scrollbar scroll-smooth w-full md:w-auto">
            {/* All */}
            <button
              type="button"
              onClick={() => setSelectedDept('all')}
              className={`px-3 sm:px-4 py-2 rounded-xl text-xs sm:text-sm font-bold transition cursor-pointer whitespace-nowrap shrink-0 flex items-center gap-1.5 ${
                selectedDept === 'all'
                  ? 'bg-[#107c41] text-white shadow-xs'
                  : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
              }`}
            >
              <span className="hidden sm:inline">All (সকল বিষয়)</span>
              <span className="sm:hidden inline">সব বিষয়</span>
              <span
                className={`inline-flex items-center justify-center min-w-[20px] h-5 px-1.5 rounded-md text-[10.5px] font-bold shrink-0 ${
                  selectedDept === 'all' ? 'bg-black/20 text-white' : 'bg-slate-200 text-slate-700'
                }`}
              >
                {toBengaliNumber(departmentCounts.all)}
              </span>
            </button>

            {/* Science */}
            <button
              type="button"
              onClick={() => setSelectedDept('science')}
              className={`px-3 sm:px-4 py-2 rounded-xl text-xs sm:text-sm font-bold transition cursor-pointer whitespace-nowrap shrink-0 flex items-center gap-1.5 ${
                selectedDept === 'science'
                  ? 'bg-[#107c41] text-white shadow-xs'
                  : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
              }`}
            >
              <span className="hidden sm:inline">Science (বিজ্ঞান)</span>
              <span className="sm:hidden inline">বিজ্ঞান</span>
              <span
                className={`inline-flex items-center justify-center min-w-[20px] h-5 px-1.5 rounded-md text-[10.5px] font-bold shrink-0 ${
                  selectedDept === 'science'
                    ? 'bg-black/20 text-white'
                    : 'bg-slate-200 text-slate-700'
                }`}
              >
                {toBengaliNumber(departmentCounts.science)}
              </span>
            </button>

            {/* Business Studies */}
            <button
              type="button"
              onClick={() => setSelectedDept('business')}
              className={`px-3 sm:px-4 py-2 rounded-xl text-xs sm:text-sm font-bold transition cursor-pointer whitespace-nowrap shrink-0 flex items-center gap-1.5 ${
                selectedDept === 'business'
                  ? 'bg-[#107c41] text-white shadow-xs'
                  : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
              }`}
            >
              <span className="hidden sm:inline">Business Studies (ব্যবসায় শিক্ষা)</span>
              <span className="sm:hidden inline">ব্যবসায় শিক্ষা</span>
              <span
                className={`inline-flex items-center justify-center min-w-[20px] h-5 px-1.5 rounded-md text-[10.5px] font-bold shrink-0 ${
                  selectedDept === 'business'
                    ? 'bg-black/20 text-white'
                    : 'bg-slate-200 text-slate-700'
                }`}
              >
                {toBengaliNumber(departmentCounts.business)}
              </span>
            </button>

            {/* Humanities */}
            <button
              type="button"
              onClick={() => setSelectedDept('humanities')}
              className={`px-3 sm:px-4 py-2 rounded-xl text-xs sm:text-sm font-bold transition cursor-pointer whitespace-nowrap shrink-0 flex items-center gap-1.5 ${
                selectedDept === 'humanities'
                  ? 'bg-[#107c41] text-white shadow-xs'
                  : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
              }`}
            >
              <span className="hidden sm:inline">Humanities (মানবিক)</span>
              <span className="sm:hidden inline">মানবিক</span>
              <span
                className={`inline-flex items-center justify-center min-w-[20px] h-5 px-1.5 rounded-md text-[10.5px] font-bold shrink-0 ${
                  selectedDept === 'humanities'
                    ? 'bg-black/20 text-white'
                    : 'bg-slate-200 text-slate-700'
                }`}
              >
                {toBengaliNumber(departmentCounts.humanities)}
              </span>
            </button>
          </div>

          {/* Search & Price Filter Controls */}
          <div className="flex items-center gap-2 sm:gap-2.5 w-full md:w-auto shrink-0 pt-1 md:pt-0">
            <div className="relative flex-1 sm:w-56">
              <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="কোর্সের নাম লিখুন..."
                className="w-full pl-8 pr-3 py-2 rounded-xl border border-slate-200 text-xs text-slate-800 placeholder-slate-400 bg-slate-50 focus:bg-white focus:border-emerald-600 outline-none transition"
              />
            </div>

            <select
              value={priceFilter}
              onChange={(e) => setPriceFilter(e.target.value)}
              className="px-3 py-2 rounded-xl border border-slate-200 text-xs font-bold text-slate-700 bg-slate-50 outline-none cursor-pointer shrink-0"
            >
              <option value="all">সকল মূল্য</option>
              <option value="under3000">৳৩,০০০ নিচে</option>
              <option value="3000to5000">৳৩,০০০ - ৳৫,০০০</option>
              <option value="above5000">৳৫,০০০ উপরে</option>
            </select>
          </div>
        </div>
      </section>

      {/* =========================================================================
          COURSES GRID: RESPONSIVE 4-COLUMN LAYOUT WITH COURSECARD
          ========================================================================= */}
      <section className="max-w-[1240px] mx-auto px-4 sm:px-6 pt-8">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h2 className="text-xl sm:text-2xl font-black text-slate-900 tracking-tight flex items-center gap-2">
              <span>{pageDetails.activeName} সকল কোর্স ও অনলাইন ব্যাচ</span>
              <span className="text-xs font-extrabold text-emerald-800 bg-emerald-50 border border-emerald-200/60 px-2.5 py-0.5 rounded-full">
                {toBengaliNumber(displayedCourses.length)}টি কোর্স
              </span>
            </h2>
            <p className="text-xs text-slate-500 mt-1">
              {selectedDept === 'all'
                ? 'সকল বিভাগের জন্য প্রযোজ্য কোর্স ও স্পেশাল সাইকেল'
                : selectedDept === 'science'
                ? 'বিজ্ঞান বিভাগের আবশ্যিক ও ঐচ্ছিক বিষয়সমূহের বিশেষ ব্যাচ'
                : selectedDept === 'business'
                ? 'ব্যবসায় শিক্ষা বিভাগের হিসাববিজ্ঞান, ফিন্যান্স ও বিষয়ভিত্তিক ব্যাচ'
                : 'মানবিক বিভাগের ইতিহাস, পৌরনীতি, অর্থনীতি ও সাধারণ বিষয়'}
            </p>
          </div>

          {(selectedDept !== 'all' || searchQuery || priceFilter !== 'all') && (
            <button
              type="button"
              onClick={() => {
                setSelectedDept('all');
                setSearchQuery('');
                setPriceFilter('all');
              }}
              className="text-xs font-bold text-emerald-700 hover:text-emerald-800 hover:underline cursor-pointer"
            >
              ফিল্টার রিসেট ✕
            </button>
          )}
        </div>

        {displayedCourses.length === 0 ? (
          <div className="bg-white rounded-3xl border border-slate-200 p-12 text-center space-y-4 max-w-xl mx-auto shadow-xs">
            <div className="w-16 h-16 rounded-2xl bg-emerald-50 text-emerald-600 flex items-center justify-center mx-auto">
              <BookOpen className="w-8 h-8" />
            </div>
            <div className="space-y-1">
              <h3 className="text-base font-bold text-slate-900">
                এই বিভাগে কোনো কোর্স পাওয়া যায়নি
              </h3>
              <p className="text-xs text-slate-500">
                অন্যান্য বিভাগ নির্বাচন করুন অথবা ফিল্টার রিসেট করে সকল কোর্স দেখুন।
              </p>
            </div>
            <button
              type="button"
              onClick={() => {
                setSelectedDept('all');
                setSearchQuery('');
                setPriceFilter('all');
              }}
              className="px-5 py-2.5 rounded-xl bg-[#107c41] text-white text-xs font-bold hover:bg-[#0e6b37] transition cursor-pointer"
            >
              সব কোর্স দেখুন (All Courses)
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-5 items-stretch">
            {displayedCourses.map((course, idx) => (
              <motion.div
                key={`academic-course-${course.id}-${course.slug}`}
                initial={{ opacity: 0, y: 16 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.3, delay: idx * 0.04 }}
                className="h-full flex flex-col"
              >
                <CourseCard course={course} onEnrollClick={onEnrollClick} />
              </motion.div>
            ))}
          </div>
        )}
      </section>
    </div>
  );
};
