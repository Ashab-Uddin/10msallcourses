import React from 'react';
import { Course } from '../../types.ts';
import { toBengaliNumber } from '../../utils/format.ts';
import { X } from 'lucide-react';

interface CourseCardProps {
  course: Course;
  onSelectCourse?: (slug: string) => void;
  onEnrollClick: (course: Course, referrer: string) => void;
}

export const CourseCard: React.FC<CourseCardProps> = ({
  course,
  onEnrollClick,
}) => {
  const savingsAmount = Math.max(0, course.originalPrice - course.discountPrice);
  const isClosed = course.status === 'closed' || course.slug.includes('beim');

  // Determine Banner Gradient and Accents based on course theme / category
  const getBannerStyle = () => {
    switch (course.gradientTheme) {
      case 'emerald':
      case 'green':
        return {
          bg: 'bg-gradient-to-br from-[#15803d] via-[#166534] to-[#14532d]',
          pillBg: 'bg-[#eab308]',
          pillText: 'text-slate-950',
          textColor: 'text-[#15803d]',
        };
      case 'purple':
      case 'violet':
        return {
          bg: 'bg-gradient-to-br from-[#7e22ce] via-[#6b21a8] to-[#581c87]',
          pillBg: 'bg-[#eab308]',
          pillText: 'text-slate-950',
          textColor: 'text-[#7e22ce]',
        };
      case 'crimson':
      case 'rose':
        return {
          bg: 'bg-gradient-to-br from-[#991b1b] via-[#881337] to-[#701a75]',
          pillBg: 'bg-[#eab308]',
          pillText: 'text-slate-950',
          textColor: 'text-[#991b1b]',
        };
      case 'amber':
      case 'orange':
        return {
          bg: 'bg-gradient-to-br from-[#c2410c] via-[#9a3412] to-[#7c2d12]',
          pillBg: 'bg-[#eab308]',
          pillText: 'text-slate-950',
          textColor: 'text-[#c2410c]',
        };
      case 'slate':
      case 'navy':
        return {
          bg: 'bg-gradient-to-br from-[#1e293b] via-[#0f172a] to-[#020617]',
          pillBg: 'bg-[#eab308]',
          pillText: 'text-slate-950',
          textColor: 'text-[#dc2626]',
        };
      case 'blue':
        return {
          bg: 'bg-gradient-to-br from-[#1e40af] via-[#1d4ed8] to-[#1e3a8a]',
          pillBg: 'bg-[#eab308]',
          pillText: 'text-slate-950',
          textColor: 'text-[#1d4ed8]',
        };
      case 'red':
      default:
        return {
          bg: 'bg-gradient-to-br from-[#dc2626] via-[#b91c1c] to-[#991b1b]',
          pillBg: 'bg-[#eab308]',
          pillText: 'text-slate-950',
          textColor: 'text-[#dc2626]',
        };
    }
  };

  const banner = getBannerStyle();

  const handleCardClick = (referrer: string) => {
    if (isClosed) return;
    onEnrollClick(course, referrer);
  };

  // Default short description fallback if not available
  const displayDescription =
    course.description ||
    (course.categorySlug === 'school'
      ? '২০২৭ সালে SSC 2027 বোর্ড পরীক্ষায় সেরা রেজাল্ট করার জন্য সঠিক গাইডলাইন ও ফুল রিভিশন...'
      : 'দেশসেরা অভিজ্ঞ শিক্ষকদের পরিচালিত লাইভ ক্লাস ও পূর্ণাঙ্গ পরীক্ষার প্রস্তুতি নিয়ে এগিয়ে থাকুন...');

  // Determine banner aspect ratio and image fitting ('contain' | 'square' | 'video')
  const fitMode = course.imageFit || 'contain';
  const aspectClass =
    fitMode === 'video'
      ? 'aspect-video'
      : fitMode === 'square'
      ? 'aspect-square'
      : 'aspect-square sm:aspect-[4/3]';

  return (
    <div className="bg-white rounded-2xl border border-slate-200 overflow-hidden shadow-xs hover:shadow-md transition-all duration-200 flex flex-col justify-between h-full group">
      <div className="flex flex-col h-full justify-between">
        {/* TOP BANNER / IMAGE AREA */}
        <div>
          <div
            onClick={() => handleCardClick('card_banner')}
            className={`relative w-full ${aspectClass} ${banner.bg} text-white flex flex-col justify-between overflow-hidden cursor-pointer select-none rounded-t-2xl`}
            title="১০ মিনিট স্কুলে সরাসরি ভর্তি হতে ক্লিক করুন"
          >
            {course.imageUrl ? (
              <>
                {/* Subtle blurred backdrop to frame the image and eliminate empty space */}
                <img
                  src={course.imageUrl}
                  alt=""
                  aria-hidden="true"
                  className="absolute inset-0 w-full h-full object-cover blur-md opacity-35 scale-110 pointer-events-none"
                />
                {/* Crisp foreground image: 100% full image is visible, no text or graphic is cut off */}
                <img
                  src={course.imageUrl}
                  alt={course.title}
                  loading="lazy"
                  referrerPolicy="no-referrer"
                  className={`relative z-10 w-full h-full ${
                    fitMode === 'square' ? 'object-cover' : 'object-contain'
                  } object-center group-hover:scale-[1.02] transition-transform duration-300`}
                  onError={(e) => {
                    (e.target as HTMLElement).style.display = 'none';
                  }}
                />
              </>
            ) : null}

            {/* Fallback gradient styling when no image is uploaded */}
            {!course.imageUrl && (
              <>
                {/* Subtle radial backdrop highlights */}
                <div
                  className="absolute inset-0 pointer-events-none opacity-25"
                  style={{
                    backgroundImage: `radial-gradient(circle at 10% 20%, rgba(255,255,255,0.2) 0%, transparent 40%), radial-gradient(circle at 90% 80%, rgba(255,255,255,0.15) 0%, transparent 45%)`,
                  }}
                />
                {/* Decorative Yellow Lightning Bolt Left */}
                <div className="absolute -bottom-2 -left-2 text-yellow-400 opacity-90 pointer-events-none">
                  <svg width="42" height="50" viewBox="0 0 24 24" fill="currentColor">
                    <path d="M13 2L3 14h8l-2 8 10-12h-8l2-8z" />
                  </svg>
                </div>
                {/* Decorative Yellow Lightning Bolt Right */}
                <div className="absolute -top-1 -right-1 text-yellow-400 opacity-75 pointer-events-none">
                  <svg width="34" height="42" viewBox="0 0 24 24" fill="currentColor">
                    <path d="M13 2L3 14h8l-2 8 10-12h-8l2-8z" />
                  </svg>
                </div>

                {/* Center Boxed Title Assembly */}
                <div className="relative z-10 text-center my-auto px-2">
                  <div className="inline-block bg-black text-white text-[10px] sm:text-[11px] font-black px-2.5 py-0.5 rounded-sm tracking-wider uppercase shadow-xs">
                    {course.headerTitle || course.shortBadge || '10MS কোর্স'}
                  </div>
                  <div>
                    <div
                      className={`inline-block bg-white ${banner.textColor} font-black text-xs sm:text-sm px-3 py-1 rounded-sm mt-1 shadow-xs leading-tight line-clamp-1`}
                    >
                      {course.title.includes('বোর্ড')
                        ? 'বোর্ড পরীক্ষা প্রস্তুতি কোর্স'
                        : course.title.includes('BEIM')
                        ? 'শেষ মুহূর্তের প্রস্তুতি BEIM কোর্স'
                        : course.title.includes('অনলাইন ব্যাচ')
                        ? 'অনলাইন ব্যাচ'
                        : 'অনলাইন লাইভ কোর্স'}
                    </div>
                  </div>
                  <div className="text-white font-bold text-[11px] sm:text-xs mt-1 drop-shadow-xs truncate max-w-[260px] mx-auto">
                    {course.headerSubtitle ||
                      (course.title.includes('বিজ্ঞান')
                        ? '[বিজ্ঞান বিভাগ]'
                        : course.title.includes('BEIM')
                        ? '[বাংলা, ইংরেজি, আইসিটি ও গণিত]'
                        : '[১০ মিনিট স্কুল]')}
                  </div>
                </div>
              </>
            )}

            {/* Top Row Overlay Badges (Pill Left + Discount Tag Right) */}
            <div className="relative z-20 flex items-start justify-between w-full p-2.5 sm:p-3 pointer-events-none">
              {course.shortBadge ? (
                <span className="bg-slate-950/80 backdrop-blur-md text-white text-[10px] sm:text-[11px] font-bold px-2.5 py-0.5 rounded-full shadow-md border border-white/20">
                  {course.shortBadge}
                </span>
              ) : (
                <span />
              )}
              {(savingsAmount > 0 || course.discountBadgeText) && (
                <span className="bg-[#10b981] text-white font-extrabold text-[10px] sm:text-[11px] px-2.5 py-0.5 rounded-full shadow-md tracking-tight">
                  {course.discountBadgeText ||
                    (course.discountPercent > 0
                      ? `${toBengaliNumber(course.discountPercent)}% ছাড়`
                      : `৳${toBengaliNumber(savingsAmount)} ছাড়`)}
                </span>
              )}
            </div>
          </div>

          {/* CARD BODY CONTENT */}
          <div className="p-4 sm:p-5 flex flex-col justify-between">
            {/* Title - 2 lines max */}
            <h4
              onClick={() => handleCardClick('card_title')}
              className="font-bold text-slate-900 text-sm sm:text-[15px] leading-snug line-clamp-2 min-h-[2.5rem] hover:text-[#1b75d0] transition-colors cursor-pointer"
              title="১০ মিনিট স্কুলে সরাসরি ভর্তি হতে ক্লিক করুন"
            >
              {course.title}
            </h4>

            {/* Description - 2 lines max */}
            <p className="text-xs text-slate-500 leading-relaxed line-clamp-2 min-h-[2rem] mt-2 mb-3">
              {displayDescription}
            </p>
          </div>
        </div>

        {/* BOTTOM SECTION: PRICING & ACTION BUTTON (Anchor to bottom for identical card size) */}
        <div className="p-4 sm:p-5 pt-0">
          {/* PRICING & SAVINGS ROW */}
          <div className="flex items-center justify-between pt-2.5 pb-2 tabular-nums border-t border-slate-100">
            <div className="flex items-baseline gap-2">
              <span className="text-xl sm:text-2xl font-bold text-[#007a3d] tracking-tight">
                ৳{toBengaliNumber(course.discountPrice)}
              </span>
              {course.originalPrice > course.discountPrice && (
                <span className="text-xs sm:text-sm text-slate-400 line-through font-normal">
                  ৳{toBengaliNumber(course.originalPrice)}
                </span>
              )}
            </div>

            {savingsAmount > 0 && (
              <span className="border border-[#007a3d] text-[#007a3d] bg-emerald-50/60 font-semibold text-xs px-2.5 py-0.5 rounded-md whitespace-nowrap">
                ৳{toBengaliNumber(savingsAmount)} ছাড়
              </span>
            )}
          </div>

          {/* ACTION BUTTON WITH DYNAMIC COLOR-CHANGING HOVER (Blue to 10MS Signature Red) */}
          {isClosed ? (
            <button
              type="button"
              disabled
              className="w-full bg-[#94a3b8] text-white font-bold text-sm sm:text-base py-2.5 px-4 rounded-xl flex items-center justify-center gap-1.5 cursor-not-allowed mt-2 shadow-xs"
            >
              <span>কোর্সটিতে ভর্তি বন্ধ রয়েছে</span>
              <X className="w-4 h-4 text-white" />
            </button>
          ) : (
            <button
              type="button"
              onClick={() => handleCardClick('card_button')}
              className="group/btn relative overflow-hidden w-full bg-gradient-to-r from-[#1a73e8] via-[#1b75d0] to-[#1557b0] hover:from-[#eb2026] hover:via-[#dc2626] hover:to-[#b91c1c] text-white font-bold text-sm sm:text-base py-2.5 px-4 rounded-xl flex items-center justify-center gap-2 shadow-sm hover:shadow-xl hover:shadow-red-500/30 hover:-translate-y-0.5 active:translate-y-0 active:scale-[0.98] transition-all duration-300 cursor-pointer mt-2"
            >
              {/* Smooth Color Shift Overlay */}
              <span className="absolute inset-0 bg-gradient-to-r from-[#eb2026] via-[#dc2626] to-[#b91c1c] opacity-0 group-hover/btn:opacity-100 transition-opacity duration-300 pointer-events-none" />
              {/* Shimmer light sweep */}
              <span className="absolute inset-0 w-1/2 h-full bg-white/30 skew-x-[-25deg] -translate-x-full group-hover/btn:translate-x-[350%] transition-transform duration-700 ease-out pointer-events-none" />
              <span className="relative z-10 font-bold tracking-tight">কোর্সটিতে ভর্তি হোন</span>
              <svg
                className="w-4 h-4 transition-transform duration-300 group-hover/btn:translate-x-1.5 relative z-10"
                fill="none"
                viewBox="0 0 24 24"
                stroke="currentColor"
                strokeWidth="2.5"
              >
                <path strokeLinecap="round" strokeLinejoin="round" d="M13.5 4.5L21 12m0 0l-7.5 7.5M21 12H3" />
              </svg>
            </button>
          )}
        </div>
      </div>
    </div>
  );
};
