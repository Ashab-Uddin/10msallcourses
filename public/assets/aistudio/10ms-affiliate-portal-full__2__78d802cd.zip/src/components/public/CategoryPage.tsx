import React, { useState } from 'react';
import { Category, Course } from '../../types.ts';
import { CourseCard } from './CourseCard.tsx';
import { toBengaliNumber } from '../../utils/format.ts';
import { Search } from 'lucide-react';
import { motion } from 'motion/react';

interface CategoryPageProps {
  categorySlug: string;
  categories: Category[];
  courses: Course[];
  onBack: () => void;
  onEnrollClick: (course: Course, referrer: string) => void;
  onSelectCategory: (slug: string) => void;
}

export const CategoryPage: React.FC<CategoryPageProps> = ({
  categorySlug,
  categories,
  courses,
  onBack,
  onEnrollClick,
  onSelectCategory,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [priceFilter, setPriceFilter] = useState('all');

  const currentCategory =
    categories.find((c) => c.slug === categorySlug) ||
    categories[0] || {
      id: 0,
      name: 'কোর্স ক্যাটালগ',
      slug: categorySlug,
      subtitle: 'সকল উপলব্ধ কোর্স ও অনলাইন ব্যাচ',
    };

  const categoryCourses = courses.filter((c) => c.categorySlug === currentCategory.slug);

  const filteredCourses = categoryCourses.filter((c) => {
    const q = searchQuery.toLowerCase().trim();
    const matchesSearch =
      !q ||
      c.title.toLowerCase().includes(q) ||
      c.description.toLowerCase().includes(q) ||
      c.headerTitle.toLowerCase().includes(q) ||
      c.headerSubtitle.toLowerCase().includes(q);

    const matchesPrice =
      priceFilter === 'all' ||
      (priceFilter === 'under3000' && c.discountPrice <= 3000) ||
      (priceFilter === '3000to5000' && c.discountPrice > 3000 && c.discountPrice <= 5000) ||
      (priceFilter === 'above5000' && c.discountPrice > 5000);

    return matchesSearch && matchesPrice;
  });

  return (
    <div className="max-w-[1240px] mx-auto px-4 sm:px-6 py-6 sm:py-8">
      {/* Clean Breadcrumb Navigation */}
      <div className="flex items-center gap-2 text-xs text-slate-500 font-medium mb-5">
        <button
          type="button"
          onClick={onBack}
          className="hover:text-[#1a73e8] transition-colors cursor-pointer"
        >
          হোম
        </button>
        <span className="text-slate-300">/</span>
        <span>কোর্স ক্যাটালগ</span>
        <span className="text-slate-300">/</span>
        <span className="text-slate-900 font-bold">{currentCategory.name}</span>
      </div>

      {/* Category Hero Header Card */}
      <motion.div
        initial={{ opacity: 0, y: 15 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.4 }}
        className="bg-white rounded-3xl border border-slate-200 p-6 sm:p-8 shadow-xs mb-8"
      >
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="space-y-2">
            <div className="inline-flex items-center gap-2">
              <span className="text-[11px] font-extrabold text-[#1a73e8] bg-blue-50 border border-blue-200/60 px-3 py-1 rounded-full uppercase tracking-wider">
                অনলাইন প্রোগ্রাম
              </span>
              <span className="text-xs font-semibold text-emerald-700 bg-emerald-50 px-3 py-1 rounded-full">
                সর্বমোট {toBengaliNumber(categoryCourses.length)}টি কোর্স
              </span>
            </div>
            <h1 className="text-2xl sm:text-3xl lg:text-4xl font-black text-slate-900 tracking-tight">
              {currentCategory.name}
            </h1>
            <p className="text-xs sm:text-sm text-slate-600 max-w-2xl leading-relaxed">
              {currentCategory.subtitle ||
                'টেন মিনিট স্কুলের অনুমোদিত এই সেকশনের সকল অনলাইন কোর্স ও ব্যাচে সরাসরি সর্বোচ্চ ছাড়ে ভর্তি হতে পারবেন।'}
            </p>
          </div>

          {/* In-Category Search & Filter Bar */}
          <div className="flex flex-wrap sm:flex-nowrap items-center gap-2.5 shrink-0">
            <div className="relative w-full sm:w-64">
              <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="এই সেকশনে খুঁজুন..."
                className="w-full pl-9 pr-3 py-2 rounded-xl border border-slate-200 text-xs text-slate-800 placeholder-slate-400 bg-slate-50 focus:bg-white focus:border-blue-500 outline-none transition"
              />
            </div>

            <select
              value={priceFilter}
              onChange={(e) => setPriceFilter(e.target.value)}
              className="px-3 py-2 rounded-xl border border-slate-200 text-xs font-bold text-slate-700 bg-slate-50 outline-none cursor-pointer"
            >
              <option value="all">সকল মূল্য</option>
              <option value="under3000">৳৩,০০০ এর নিচে</option>
              <option value="3000to5000">৳৩,০০০ – ৳৫,০০০</option>
              <option value="above5000">৳৫,০০০ এর উপরে</option>
            </select>
          </div>
        </div>

        {/* Quick Category Switcher Tabs */}
        <div className="flex items-center gap-2 overflow-x-auto pt-6 mt-6 border-t border-slate-100 no-scrollbar">
          {categories.map((cat) => (
            <button
              key={cat.slug}
              type="button"
              onClick={() => {
                setSearchQuery('');
                setPriceFilter('all');
                onSelectCategory(cat.slug);
              }}
              className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition whitespace-nowrap cursor-pointer ${
                cat.slug === currentCategory.slug
                  ? 'bg-slate-900 text-white shadow-xs'
                  : 'bg-slate-100 text-slate-600 hover:bg-slate-200 hover:text-slate-900'
              }`}
            >
              {cat.name}
            </button>
          ))}
        </div>
      </motion.div>

      {/* Courses Grid Showing ALL Cards of This Section (Equal 4-Column Responsive Grid) */}
      {filteredCourses.length === 0 ? (
        <div className="bg-white rounded-3xl border border-slate-200 p-12 text-center space-y-3">
          <p className="text-base font-bold text-slate-700">
            এই ফিল্টারের সাথে মিলে এমন কোনো কোর্স পাওয়া যায়নি।
          </p>
          <button
            type="button"
            onClick={() => {
              setSearchQuery('');
              setPriceFilter('all');
            }}
            className="px-4 py-2 rounded-xl bg-blue-600 text-white text-xs font-bold cursor-pointer hover:bg-blue-700 transition"
          >
            ফিল্টার রিসেট করুন
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-5 items-stretch">
          {filteredCourses.map((course, idx) => (
            <motion.div
              key={`category-course-${course.id}-${course.slug}`}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: '-20px' }}
              transition={{ duration: 0.35, delay: idx * 0.05 }}
              className="h-full flex flex-col"
            >
              <CourseCard course={course} onEnrollClick={onEnrollClick} />
            </motion.div>
          ))}
        </div>
      )}
    </div>
  );
};
