import { Request, Response, NextFunction } from 'express';

export interface AuthRequest extends Request {
  user?: {
    uid: string;
    email: string;
    name?: string;
  };
}

export const requireAuth = (
  req: AuthRequest,
  res: Response,
  next: NextFunction
) => {
  const authHeader = req.headers.authorization;
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return res.status(401).json({ error: 'Unauthorized: Missing token' });
  }

  const token = authHeader.split('Bearer ')[1];

  // Validate admin token (support DEMO, GOOGLE, and standard admin tokens)
  if (
    token === 'DEMO_ADMIN_TOKEN' ||
    token === 'GOOGLE_ADMIN_TOKEN' ||
    token.startsWith('ADMIN_')
  ) {
    req.user = {
      uid: 'admin-uid',
      email: 'ashabuddin2274@gmail.com',
      name: 'Ashab Uddin (Admin)',
    };
    return next();
  }

  return res.status(401).json({ error: 'Unauthorized: Invalid token' });
};
