-- ==============================================================
-- 10 MINUTE SCHOOL AFFILIATE COURSE MARKETPLACE SUPABASE SCHEMA
-- PostgreSQL + Row Level Security (RLS) + Automated Discount Calc
-- ==============================================================

-- 1. Create categories table
CREATE TABLE IF NOT EXISTS public.categories (
    id BIGSERIAL PRIMARY KEY,
    name TEXT NOT NULL,
    slug TEXT NOT NULL UNIQUE,
    subtitle TEXT,
    badge_color TEXT DEFAULT 'red' NOT NULL,
    display_order INT DEFAULT 0 NOT NULL,
    status TEXT DEFAULT 'active' NOT NULL, -- 'active', 'inactive'
    icon TEXT DEFAULT 'school' NOT NULL,
    created_at TIMESTAMPTZ DEFAULT NOW() NOT NULL
);

-- 2. Create courses table
CREATE TABLE IF NOT EXISTS public.courses (
    id BIGSERIAL PRIMARY KEY,
    title TEXT NOT NULL,
    slug TEXT NOT NULL UNIQUE,
    category_slug TEXT NOT NULL REFERENCES public.categories(slug) ON DELETE CASCADE,
    category_name TEXT,
    short_badge TEXT DEFAULT 'অনলাইন ব্যাচ' NOT NULL,
    header_title TEXT DEFAULT '10MS' NOT NULL,
    header_subtitle TEXT DEFAULT 'অনলাইন কোর্স' NOT NULL,
    discount_badge_text TEXT DEFAULT 'স্পেশাল ছাড়' NOT NULL,
    gradient_theme TEXT DEFAULT 'red' NOT NULL, -- 'red', 'blue', 'emerald', 'purple', 'amber'
    description TEXT NOT NULL,
    full_description TEXT,
    image_url TEXT NOT NULL,
    original_price INT NOT NULL CHECK (original_price >= 0),
    discount_price INT NOT NULL CHECK (discount_price >= 0),
    discount_percent INT GENERATED ALWAYS AS (
        CASE WHEN original_price > 0 AND original_price > discount_price THEN 
            ROUND(((original_price - discount_price)::NUMERIC / original_price) * 100)
        ELSE 0 END
    ) STORED,
    rating TEXT DEFAULT '৪.৯' NOT NULL,
    student_count TEXT DEFAULT '১০k+ শিক্ষার্থী' NOT NULL,
    duration TEXT DEFAULT '৬ মাস' NOT NULL,
    target_students TEXT DEFAULT 'সকল শিক্ষার্থী',
    instructor_info TEXT DEFAULT 'টেন মিনিট স্কুলের শীর্ষ মেন্টর প্যানেল' NOT NULL,
    instructor_icon TEXT DEFAULT 'school' NOT NULL,
    features JSONB DEFAULT '[]'::jsonb NOT NULL,
    affiliate_url TEXT NOT NULL,
    is_popular BOOLEAN DEFAULT false NOT NULL,
    is_featured BOOLEAN DEFAULT false NOT NULL,
    status TEXT DEFAULT 'published' NOT NULL, -- 'published', 'draft'
    click_count INT DEFAULT 0 NOT NULL,
    created_at TIMESTAMPTZ DEFAULT NOW() NOT NULL,
    updated_at TIMESTAMPTZ DEFAULT NOW() NOT NULL
);

-- 3. Click Analytics (No unnecessary personal data stored)
CREATE TABLE IF NOT EXISTS public.clicks (
    id BIGSERIAL PRIMARY KEY,
    course_id BIGINT REFERENCES public.courses(id) ON DELETE CASCADE,
    course_slug TEXT NOT NULL,
    referrer TEXT DEFAULT 'direct',
    clicked_at TIMESTAMPTZ DEFAULT NOW() NOT NULL
);

-- 4. Site Settings (Single Row Pattern)
CREATE TABLE IF NOT EXISTS public.site_settings (
    id INT PRIMARY KEY DEFAULT 1,
    site_title TEXT NOT NULL,
    whatsapp_number TEXT NOT NULL,
    whatsapp_link TEXT NOT NULL,
    hero_badge TEXT,
    hero_title TEXT,
    hero_subtitle TEXT,
    countdown_label TEXT,
    countdown_end_date TIMESTAMPTZ,
    affiliate_disclosure_short TEXT,
    contact_email TEXT,
    notice_bar_text TEXT,
    notice_bar_active BOOLEAN DEFAULT true,
    updated_at TIMESTAMPTZ DEFAULT NOW() NOT NULL,
    CONSTRAINT single_row CHECK (id = 1)
);

-- 5. Performance Indexes
CREATE INDEX IF NOT EXISTS idx_courses_slug ON public.courses(slug);
CREATE INDEX IF NOT EXISTS idx_courses_category ON public.courses(category_slug);
CREATE INDEX IF NOT EXISTS idx_courses_status ON public.courses(status);
CREATE INDEX IF NOT EXISTS idx_categories_slug ON public.categories(slug);
CREATE INDEX IF NOT EXISTS idx_clicks_slug ON public.clicks(course_slug);

-- 6. Row Level Security (RLS) Configuration
ALTER TABLE public.categories ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.courses ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.clicks ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.site_settings ENABLE ROW LEVEL SECURITY;

-- Public READ Policies
CREATE POLICY "Public Read Active Categories" ON public.categories
    FOR SELECT TO public USING (status = 'active');

CREATE POLICY "Public Read Published Courses" ON public.courses
    FOR SELECT TO public USING (status = 'published');

CREATE POLICY "Public Read Settings" ON public.site_settings
    FOR SELECT TO public USING (true);

CREATE POLICY "Public Insert Clicks" ON public.clicks
    FOR INSERT TO public WITH CHECK (true);

-- Authenticated Admin Policies (CRUD)
CREATE POLICY "Admin Full Control Categories" ON public.categories
    FOR ALL TO authenticated USING (true) WITH CHECK (true);

CREATE POLICY "Admin Full Control Courses" ON public.courses
    FOR ALL TO authenticated USING (true) WITH CHECK (true);

CREATE POLICY "Admin Full Control Settings" ON public.site_settings
    FOR ALL TO authenticated USING (true) WITH CHECK (true);

CREATE POLICY "Admin Read Clicks" ON public.clicks
    FOR SELECT TO authenticated USING (true);
