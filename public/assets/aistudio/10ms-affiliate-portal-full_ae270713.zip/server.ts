import 'dotenv/config';
import express from 'express';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import { createServer as createViteServer } from 'vite';
import JSZip from 'jszip';
import { requireAuth } from './src/middleware/auth.ts';
import {
  createNewCategory,
  createNewCourse,
  deleteCategoryById,
  deleteCourseById,
  getAdminOverviewData,
  getCourseBySlug,
  getPublicPortalData,
  recordCourseClick,
  updateExistingCategory,
  updateExistingCourse,
  updatePortalSettings,
} from './src/db/repository.ts';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const app = express();
const port = Number(process.env.PORT || 3000);

app.use(express.json({ limit: '15mb' }));

// 1. Public Portal Data (Categories, Courses, Settings)
app.get('/api/public/data', async (_req, res) => {
  try {
    const data = await getPublicPortalData();
    res.json(data);
  } catch (error) {
    console.error('Public data endpoint failed:', error);
    res.status(500).json({ error: 'Failed to load public portal data.' });
  }
});

// 2. Public Course Details by Slug
app.get('/api/public/course/:slug', async (req, res) => {
  try {
    const course = await getCourseBySlug(req.params.slug);
    if (!course) {
      return res.status(404).json({ error: 'কোর্সটি খুঁজে পাওয়া যায়নি।' });
    }
    res.json(course);
  } catch (error) {
    console.error('Public course endpoint failed:', error);
    res.status(500).json({ error: 'Failed to load course details.' });
  }
});

// 3. Track Affiliate Click
app.post('/api/public/click/:slug', async (req, res) => {
  try {
    const result = await recordCourseClick(
      req.params.slug,
      req.body?.referrer,
      req.get('user-agent') || undefined
    );
    res.json({ success: true, ...result });
  } catch (error) {
    console.error('Course click endpoint failed:', error);
    res.status(500).json({ error: 'Failed to record click.' });
  }
});

// 4. Outbound Affiliate Redirector: /go/:slug
app.get('/go/:slug', async (req, res) => {
  try {
    const course = await getCourseBySlug(req.params.slug);
    if (!course || !course.affiliateUrl) {
      return res.redirect('/');
    }

    // Record outbound click in background
    recordCourseClick(course.slug, req.get('referer'), req.get('user-agent')).catch(() => {});

    // 307 Temporary Redirect preserving headers & query
    res.redirect(307, course.affiliateUrl);
  } catch (error) {
    console.error('Outbound redirect failed:', error);
    res.redirect('/');
  }
});

// 5. Admin Authentication & Management Endpoints
app.post('/api/admin/login', (req, res) => {
  try {
    const { email, password } = req.body || {};
    if (email === 'ashabuddin2274@gmail.com' && password === 'admin123') {
      return res.json({
        success: true,
        token: 'DEMO_ADMIN_TOKEN',
        email: 'ashabuddin2274@gmail.com',
        name: 'Ashab Uddin (Admin)',
      });
    }
    return res.status(401).json({
      error: 'ভুল ইমেইল অথবা পাসওয়ার্ড। অনুগ্রহ করে সঠিক ক্রেডেনশিয়াল দিন।',
    });
  } catch (err) {
    console.error('Admin login error:', err);
    return res.status(500).json({ error: 'লগইন প্রসেসে সমস্যা হয়েছে।' });
  }
});

app.get('/api/admin/overview', requireAuth, async (_req, res) => {
  try {
    const data = await getAdminOverviewData();
    res.json(data);
  } catch (error) {
    console.error('Admin overview endpoint failed:', error);
    res.status(500).json({ error: 'Failed to load admin overview.' });
  }
});

app.get('/api/admin/categories', requireAuth, async (_req, res) => {
  try {
    const data = await getAdminOverviewData();
    res.json(data.categories || []);
  } catch (error) {
    console.error('Admin categories endpoint failed:', error);
    res.status(500).json({ error: 'Failed to load categories.' });
  }
});

app.post('/api/admin/categories', requireAuth, async (req, res) => {
  try {
    const data = await createNewCategory(req.body || {});
    res.status(201).json(data);
  } catch (error) {
    console.error('Create category endpoint failed:', error);
    res.status(500).json({ error: 'Failed to create category.' });
  }
});

app.put('/api/admin/categories/:id', requireAuth, async (req, res) => {
  try {
    const data = await updateExistingCategory(Number(req.params.id), req.body || {});
    res.json(data);
  } catch (error) {
    console.error('Update category endpoint failed:', error);
    res.status(500).json({ error: 'Failed to update category.' });
  }
});

app.delete('/api/admin/categories/:id', requireAuth, async (req, res) => {
  try {
    const result = await deleteCategoryById(Number(req.params.id));
    res.json(result);
  } catch (error) {
    console.error('Delete category endpoint failed:', error);
    res.status(500).json({ error: 'Failed to delete category.' });
  }
});

app.get('/api/admin/courses', requireAuth, async (_req, res) => {
  try {
    const data = await getAdminOverviewData();
    res.json(data.courses || []);
  } catch (error) {
    console.error('Admin courses endpoint failed:', error);
    res.status(500).json({ error: 'Failed to load courses.' });
  }
});

app.post('/api/admin/courses', requireAuth, async (req, res) => {
  try {
    const data = await createNewCourse(req.body || {});
    res.status(201).json(data);
  } catch (error) {
    console.error('Create course endpoint failed:', error);
    res.status(500).json({ error: 'Failed to create course.' });
  }
});

app.put('/api/admin/courses/:id', requireAuth, async (req, res) => {
  try {
    const data = await updateExistingCourse(Number(req.params.id), req.body || {});
    res.json(data);
  } catch (error) {
    console.error('Update course endpoint failed:', error);
    res.status(500).json({ error: 'Failed to update course.' });
  }
});

app.patch('/api/admin/courses/:id/status', requireAuth, async (req, res) => {
  try {
    const data = await updateExistingCourse(Number(req.params.id), {
      status: String(req.body?.status || 'active'),
    });
    res.json(data);
  } catch (error) {
    console.error('Update course status endpoint failed:', error);
    res.status(500).json({ error: 'Failed to update course status.' });
  }
});

app.delete('/api/admin/courses/:id', requireAuth, async (req, res) => {
  try {
    const result = await deleteCourseById(Number(req.params.id));
    res.json(result);
  } catch (error) {
    console.error('Delete course endpoint failed:', error);
    res.status(500).json({ error: 'Failed to delete course.' });
  }
});

app.get('/api/admin/settings', requireAuth, async (_req, res) => {
  try {
    const data = await getAdminOverviewData();
    res.json(data.settings || null);
  } catch (error) {
    console.error('Admin settings endpoint failed:', error);
    res.status(500).json({ error: 'Failed to load settings.' });
  }
});

app.post('/api/admin/settings', requireAuth, async (req, res) => {
  try {
    const data = await updatePortalSettings(req.body || {});
    res.json(data);
  } catch (error) {
    console.error('Admin settings save endpoint failed:', error);
    res.status(500).json({ error: 'Failed to save settings.' });
  }
});

// 6. Download Full Website Source Code as ZIP
app.get('/api/download-project-zip', async (_req, res) => {
  try {
    const zip = new JSZip();
    const rootDir = __dirname;

    const shouldInclude = (relPath: string) => {
      const parts = relPath.split(path.sep);
      if (
        parts.includes('node_modules') ||
        parts.includes('.git') ||
        parts.includes('dist') ||
        parts.includes('.vscode') ||
        parts.includes('user_theme_ref') ||
        parts.includes('.DS_Store')
      ) {
        return false;
      }
      return true;
    };

    const addFilesRecursively = (dir: string, currentPrefix = '') => {
      const items = fs.readdirSync(dir);
      for (const item of items) {
        const fullPath = path.join(dir, item);
        const relPath = currentPrefix ? `${currentPrefix}/${item}` : item;

        if (!shouldInclude(relPath)) continue;

        const stat = fs.statSync(fullPath);
        if (stat.isDirectory()) {
          addFilesRecursively(fullPath, relPath);
        } else {
          const content = fs.readFileSync(fullPath);
          zip.file(relPath, content);
        }
      }
    };

    addFilesRecursively(rootDir);

    const zipBuffer = await zip.generateAsync({
      type: 'nodebuffer',
      compression: 'DEFLATE',
      compressionOptions: { level: 6 },
    });

    res.setHeader('Content-Type', 'application/zip');
    res.setHeader('Content-Disposition', 'attachment; filename="10ms-affiliate-portal-full.zip"');
    res.send(zipBuffer);
  } catch (error) {
    console.error('ZIP generation error:', error);
    res.status(500).json({ error: 'Failed to generate project zip.' });
  }
});

// 7. Dynamic SEO Sitemap.xml & Robots.txt
app.get('/sitemap.xml', async (_req, res) => {
  try {
    const data = await getPublicPortalData();
    const baseUrl = process.env.APP_URL || 'https://10mscourses.com';
    const now = new Date().toISOString();

    let xml = `<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n`;
    xml += `  <url>\n    <loc>${baseUrl}</loc>\n    <lastmod>${now}</lastmod>\n    <changefreq>daily</changefreq>\n    <priority>1.0</priority>\n  </url>\n`;

    data.categories.forEach((cat: any) => {
      xml += `  <url>\n    <loc>${baseUrl}/#${cat.slug}-section</loc>\n    <lastmod>${now}</lastmod>\n    <changefreq>weekly</changefreq>\n    <priority>0.8</priority>\n  </url>\n`;
    });

    data.courses.forEach((c: any) => {
      xml += `  <url>\n    <loc>${baseUrl}/courses/${c.slug}</loc>\n    <lastmod>${now}</lastmod>\n    <changefreq>weekly</changefreq>\n    <priority>0.9</priority>\n  </url>\n`;
    });

    xml += `</urlset>`;
    res.setHeader('Content-Type', 'application/xml');
    res.send(xml);
  } catch (error) {
    res.status(500).send('Error generating sitemap');
  }
});

app.get('/robots.txt', (_req, res) => {
  const baseUrl = process.env.APP_URL || 'https://10mscourses.com';
  res.setHeader('Content-Type', 'text/plain');
  res.send(`User-agent: *\nAllow: /\nDisallow: /admin\nDisallow: /go/\nSitemap: ${baseUrl}/sitemap.xml\n`);
});

// 8. Vite Dev Server / Static Production
if (process.env.NODE_ENV !== 'production') {
  const vite = await createViteServer({
    server: { middlewareMode: true },
    appType: 'spa',
    root: __dirname,
  });

  app.use(vite.middlewares);
  app.use('*', async (req, res, next) => {
    try {
      let template = fs.readFileSync(path.resolve(__dirname, 'index.html'), 'utf-8');
      template = await vite.transformIndexHtml(req.originalUrl, template);
      res.status(200).set({ 'Content-Type': 'text/html' }).end(template);
    } catch (error) {
      next(error);
    }
  });
} else {
  const distPath = path.resolve(__dirname, 'dist');
  app.use(express.static(distPath));
  app.get('*', (_req, res) => {
    res.sendFile(path.join(distPath, 'index.html'));
  });
}

app.listen(port, () => {
  console.log(`10MS Portal running on http://localhost:${port}`);
});
