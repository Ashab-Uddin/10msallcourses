import React from 'react';
import { Course } from '../../types.ts';
import { parseFeatures, toBengaliNumber } from '../../utils/format.ts';

interface CourseCardProps {
  course: Course;
  onSelectCourse?: (slug: string) => void;
  onEnrollClick: (course: Course, referrer: string) => void;
}

export const CourseCard: React.FC<CourseCardProps> = ({
  course,
  onEnrollClick,
}) => {
  const features = parseFeatures(course.features);
  const savingsAmount = Math.max(0, course.originalPrice - course.discountPrice);
  const isClosed = course.status === 'closed' || course.slug.includes('beim');

  // Determine Banner Gradient and Accents based on course theme / category
  const getBannerStyle = () => {
    switch (course.gradientTheme) {
      case 'emerald':
      case 'green':
        return {
          bg: 'bg-gradient-to-br from-[#15803d] via-[#166534] to-[#14532d]',
          pillBg: 'bg-[#dc2626]',
          textColor: 'text-[#15803d]',
        };
      case 'purple':
      case 'violet':
        return {
          bg: 'bg-gradient-to-br from-[#7e22ce] via-[#6b21a8] to-[#581c87]',
          pillBg: 'bg-[#e11d48]',
          textColor: 'text-[#7e22ce]',
        };
      case 'crimson':
      case 'rose':
        return {
          bg: 'bg-gradient-to-br from-[#991b1b] via-[#881337] to-[#701a75]',
          pillBg: 'bg-[#dc2626]',
          textColor: 'text-[#991b1b]',
        };
      case 'amber':
      case 'orange':
        return {
          bg: 'bg-gradient-to-br from-[#c2410c] via-[#9a3412] to-[#7c2d12]',
          pillBg: 'bg-[#dc2626]',
          textColor: 'text-[#c2410c]',
        };
      case 'slate':
      case 'navy':
        return {
          bg: 'bg-gradient-to-br from-[#1e293b] via-[#0f172a] to-[#020617]',
          pillBg: 'bg-[#e11d48]',
          textColor: 'text-[#dc2626]',
        };
      case 'red':
      default:
        return {
          bg: 'bg-gradient-to-br from-[#dc2626] via-[#b91c1c] to-[#991b1b]',
          pillBg: 'bg-[#dc2626]',
          textColor: 'text-[#dc2626]',
        };
    }
  };

  const banner = getBannerStyle();

  const handleCardClick = (referrer: string) => {
    if (isClosed) return;
    onEnrollClick(course, referrer);
  };

  // Determine feature icons
  const getFeatureIcon = (idx: number) => {
    switch (idx) {
      case 0:
        return 'desktop_windows';
      case 1:
        return 'help';
      case 2:
        return 'groups';
      case 3:
      default:
        return 'description';
    }
  };

  return (
    <div className="bg-white rounded-[18px] border border-slate-200 overflow-hidden shadow-xs hover:shadow-md transition-shadow duration-200 flex flex-col justify-between h-full group">
      <div>
        {/* TOP BANNER (Exact Replica of Reference Design image_5d69a538.png & image_ad78b06e.png) */}
        <div
          onClick={() => handleCardClick('card_banner')}
          className={`relative h-44 ${banner.bg} text-white p-3.5 sm:p-4 flex flex-col justify-between overflow-hidden cursor-pointer select-none`}
          title="১০ মিনিট স্কুলে সরাসরি ভর্তি হতে ক্লিক করুন"
        >
          {/* Subtle Dynamic Graphic Waves & Lightning Accents */}
          <div
            className="absolute inset-0 pointer-events-none opacity-25"
            style={{
              backgroundImage: `radial-gradient(circle at 10% 20%, rgba(255,255,255,0.2) 0%, transparent 40%), radial-gradient(circle at 90% 80%, rgba(255,255,255,0.15) 0%, transparent 45%)`,
            }}
          />
          {/* Decorative Yellow Lightning Bolt Left */}
          <div className="absolute -bottom-2 -left-2 text-yellow-400 opacity-90 pointer-events-none">
            <svg width="46" height="54" viewBox="0 0 24 24" fill="currentColor">
              <path d="M13 2L3 14h8l-2 8 10-12h-8l2-8z" />
            </svg>
          </div>
          {/* Decorative Yellow Lightning Bolt Right */}
          <div className="absolute -top-1 -right-1 text-yellow-400 opacity-75 pointer-events-none">
            <svg width="38" height="46" viewBox="0 0 24 24" fill="currentColor">
              <path d="M13 2L3 14h8l-2 8 10-12h-8l2-8z" />
            </svg>
          </div>

          {/* Top Row: Pill Tag (Left) + Yellow Discount Ribbon (Right) */}
          <div className="relative z-10 flex items-start justify-between w-full">
            <span
              className={`${banner.pillBg} text-white text-[11px] sm:text-xs font-bold px-3 py-0.5 rounded-full shadow-xs border border-white/20`}
            >
              {course.shortBadge || 'বিজ্ঞান'}
            </span>
            <span className="bg-[#facc15] text-slate-950 font-black text-xs px-2.5 py-1 rounded-bl-xl shadow-xs font-mono tracking-tight">
              {course.discountBadgeText || `${toBengaliNumber(course.discountPercent)}% ছাড়`}
            </span>
          </div>

          {/* Center Boxed Title Assembly */}
          <div className="relative z-10 text-center my-auto px-1">
            {/* Small Black Series Pill */}
            <div className="inline-block bg-black text-white text-[11px] font-black px-3 py-0.5 rounded-sm tracking-wider uppercase shadow-xs">
              {course.headerTitle || 'SSC 27'}
            </div>
            {/* White Boxed Red Series Title */}
            <div>
              <div
                className={`inline-block bg-white ${banner.textColor} font-black text-sm sm:text-[15px] px-3.5 py-1 rounded-sm mt-1 shadow-sm leading-tight`}
              >
                শেষ মুহূর্তের প্রস্তুতি কোর্স
              </div>
            </div>
            {/* Subtitle in Brackets */}
            <div className="text-white font-bold text-xs sm:text-[13px] mt-1 drop-shadow-xs truncate">
              {course.headerSubtitle
                ? course.headerSubtitle.startsWith('[')
                  ? course.headerSubtitle
                  : `[${course.headerSubtitle}]`
                : '[বিজ্ঞান বিভাগ]'}
            </div>
          </div>
        </div>

        {/* CARD BODY */}
        <div className="p-4 sm:p-5 flex flex-col justify-between">
          {/* Title */}
          <h4
            onClick={() => handleCardClick('card_title')}
            className="font-black text-slate-900 text-[15px] sm:text-base leading-snug line-clamp-2 hover:text-[#107c41] transition-colors cursor-pointer"
            title="১০ মিনিট স্কুলে সরাসরি ভর্তি হতে ক্লিক করুন"
          >
            {course.title}
          </h4>

          {/* Fine Dashed Divider */}
          <div className="border-b border-dashed border-slate-200 my-3.5" />

          {/* Pricing & Savings Row */}
          <div className="flex items-center justify-between tabular-nums">
            <div className="flex items-baseline gap-2">
              <span className="text-2xl font-black text-[#107c41] tracking-tight">
                ৳{toBengaliNumber(course.discountPrice)}
              </span>
              {course.originalPrice > course.discountPrice && (
                <span className="text-xs sm:text-sm text-slate-400 line-through font-normal">
                  ৳{toBengaliNumber(course.originalPrice)}
                </span>
              )}
            </div>

            {savingsAmount > 0 && (
              <span className="border border-[#107c41] text-[#107c41] bg-emerald-50/70 font-bold text-xs px-2.5 py-1 rounded-lg whitespace-nowrap">
                বাঁচবে ৳{toBengaliNumber(savingsAmount)}
              </span>
            )}
          </div>

          {/* CTA Action Button */}
          {isClosed ? (
            <button
              type="button"
              disabled
              className="w-full bg-[#94a3b8] text-white font-bold text-sm sm:text-base py-2.5 px-4 rounded-xl flex items-center justify-center gap-2 cursor-not-allowed mt-3 shadow-xs"
            >
              <span>কোর্সটিতে ভর্তি বন্ধ রয়েছে</span>
              <span className="material-symbols-outlined text-[17px]">close</span>
            </button>
          ) : (
            <button
              type="button"
              onClick={() => handleCardClick('card_button')}
              className="w-full bg-[#107c41] hover:bg-[#0b6132] text-white font-bold text-sm sm:text-base py-2.5 px-4 rounded-xl flex items-center justify-center gap-2 shadow-xs transition duration-150 cursor-pointer mt-3 active:scale-[0.99]"
            >
              <span>কোর্সটিতে ভর্তি হোন</span>
            </button>
          )}

          {/* FEATURES SECTION ("এই কোর্সে যা যা থাকছে") */}
          <div className="mt-4 pt-1">
            <div className="text-xs sm:text-[13px] font-extrabold text-slate-900 mb-2.5 flex items-center gap-1.5">
              <span>এই কোর্সে যা যা থাকছে</span>
            </div>

            <div className="space-y-2 text-xs text-slate-700">
              {features.length > 0 ? (
                features.slice(0, 4).map((feat, idx) => (
                  <div key={idx} className="flex items-start gap-2.5">
                    <span className="material-symbols-outlined text-[17px] text-slate-500 shrink-0 mt-0.5">
                      {getFeatureIcon(idx)}
                    </span>
                    <span className="leading-snug line-clamp-1">{feat}</span>
                  </div>
                ))
              ) : (
                <>
                  <div className="flex items-start gap-2.5">
                    <span className="material-symbols-outlined text-[17px] text-slate-500 shrink-0 mt-0.5">
                      desktop_windows
                    </span>
                    <span className="leading-snug">৫০+ বিষয়ের উপর ডিটেইলড লাইভ ক্লাস</span>
                  </div>
                  <div className="flex items-start gap-2.5">
                    <span className="material-symbols-outlined text-[17px] text-slate-500 shrink-0 mt-0.5">
                      help
                    </span>
                    <span className="leading-snug">বোর্ড প্রশ্ন অ্যানালাইসিস করে পড়ানো</span>
                  </div>
                  <div className="flex items-start gap-2.5">
                    <span className="material-symbols-outlined text-[17px] text-slate-500 shrink-0 mt-0.5">
                      groups
                    </span>
                    <span className="leading-snug">গাইডলাইন সেশন ও স্পেশাল আর্কাইভ</span>
                  </div>
                  <div className="flex items-start gap-2.5">
                    <span className="material-symbols-outlined text-[17px] text-slate-500 shrink-0 mt-0.5">
                      description
                    </span>
                    <span className="leading-snug">অধ্যায়ভিত্তিক ডেইলি MCQ ও মডেল টেস্ট</span>
                  </div>
                </>
              )}

              {/* Bottom Schedule & Status Row */}
              <div className="flex items-center justify-between text-[11px] text-slate-500 pt-1.5 border-t border-slate-100">
                <span className="flex items-center gap-1">
                  <span className="material-symbols-outlined text-[15px] text-slate-400">
                    schedule
                  </span>
                  <span>{course.duration || 'পরীক্ষা পর্যন্ত'}</span>
                </span>
                <span className="flex items-center gap-1 font-semibold text-emerald-700">
                  <span className="material-symbols-outlined text-[15px] text-emerald-600">
                    school
                  </span>
                  <span>{isClosed ? 'ভর্তি বন্ধ রয়েছে' : 'ভর্তি চলমান'}</span>
                </span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
