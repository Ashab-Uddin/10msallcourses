import { Request, Response, NextFunction } from 'express';
import { adminAuth } from '../lib/firebase-admin.ts';
import { DecodedIdToken } from 'firebase-admin/auth';
import { getOrCreateUser } from '../db/users.ts';

export interface AuthRequest extends Request {
  user?: DecodedIdToken;
}

export const requireAuth = async (
  req: AuthRequest,
  res: Response,
  next: NextFunction
) => {
  const authHeader = req.headers.authorization;
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return res.status(401).json({ error: 'Unauthorized: Missing token' });
  }

  const token = authHeader.split('Bearer ')[1];

  // Support demo admin mode if user activates quick preview in the iframe environment
  if (token === 'DEMO_ADMIN_TOKEN') {
    try {
      await getOrCreateUser('demo-admin-uid', 'ashabuddin2274@gmail.com', 'Admin User');
    } catch (e) {
      // Ignore sync error in demo fallback
    }
    req.user = {
      uid: 'demo-admin-uid',
      email: 'ashabuddin2274@gmail.com',
      aud: 'demo',
      auth_time: Date.now(),
      exp: Date.now() + 3600000,
      firebase: { identities: {}, sign_in_provider: 'google.com' },
      iat: Date.now(),
      iss: 'demo',
      sub: 'demo-admin-uid',
    };
    return next();
  }

  try {
    const decodedToken = await adminAuth.verifyIdToken(token);
    req.user = decodedToken;
    if (decodedToken.uid && decodedToken.email) {
      await getOrCreateUser(decodedToken.uid, decodedToken.email, decodedToken.name || 'Admin');
    }
    next();
  } catch (error) {
    console.error('Error verifying Firebase ID token:', error);
    return res.status(401).json({ error: 'Unauthorized: Invalid token' });
  }
};
