import React, { useState, useEffect, useRef } from 'react';
import { X, Send, CheckCircle2 } from 'lucide-react';

interface FloatingContactWidgetProps {
  whatsappLink: string;
  whatsappNumber: string;
}

export const FloatingContactWidget: React.FC<FloatingContactWidgetProps> = ({
  whatsappLink,
  whatsappNumber,
}) => {
  // Modal states: WhatsApp Popup vs Direct Interactive Support Form
  const [isWhatsAppOpen, setIsWhatsAppOpen] = useState(false);
  const [isSupportFormOpen, setIsSupportFormOpen] = useState(false);

  // WhatsApp chat input & sending state
  const [waMessage, setWaMessage] = useState('');
  const [isSendingWa, setIsSendingWa] = useState(false);
  const [waSentSuccess, setWaSentSuccess] = useState(false);

  // Support inquiry form state (for 3-dot message bubble button)
  const [name, setName] = useState('');
  const [phoneOrEmail, setPhoneOrEmail] = useState('');
  const [message, setMessage] = useState('');
  const [courseTitle, setCourseTitle] = useState('সাধারণ কোর্স তথ্য');
  const [submitting, setSubmitting] = useState(false);
  const [successReply, setSuccessReply] = useState<string | null>(null);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  // Formatted date & time state (matching image_66e03fdc.png format: "04 November 2026 10:34:43 AM")
  const [formattedTime, setFormattedTime] = useState<string>('');
  const [greeting, setGreeting] = useState<{ text: string; icon: string }>({
    text: 'শুভ সকাল',
    icon: '🌤',
  });

  // Calculate live greeting and timestamp
  useEffect(() => {
    const updateTimeAndGreeting = () => {
      const now = new Date();
      const hour = now.getHours();

      // Dynamic Bengali Greeting based on time of day
      if (hour >= 5 && hour < 12) {
        setGreeting({ text: 'শুভ সকাল', icon: '🌤' });
      } else if (hour >= 12 && hour < 15) {
        setGreeting({ text: 'শুভ দুপুর', icon: '☀️' });
      } else if (hour >= 15 && hour < 18) {
        setGreeting({ text: 'শুভ অপরাহ্ন', icon: '⛅' });
      } else {
        setGreeting({ text: 'শুভ সন্ধ্যা', icon: '🌙' });
      }

      // Format date like screenshot: "04 November 2026 10:34:43 AM"
      const day = String(now.getDate()).padStart(2, '0');
      const months = [
        'January', 'February', 'March', 'April', 'May', 'June',
        'July', 'August', 'September', 'October', 'November', 'December',
      ];
      const month = months[now.getMonth()];
      const year = now.getFullYear();

      let hours12 = hour % 12;
      hours12 = hours12 ? hours12 : 12; // '0' should be '12'
      const formattedHours = String(hours12).padStart(2, '0');
      const minutes = String(now.getMinutes()).padStart(2, '0');
      const seconds = String(now.getSeconds()).padStart(2, '0');
      const ampm = hour >= 12 ? 'PM' : 'AM';

      setFormattedTime(`${day} ${month} ${year} ${formattedHours}:${minutes}:${seconds} ${ampm}`);
    };

    updateTimeAndGreeting();
    const interval = setInterval(updateTimeAndGreeting, 1000);
    return () => clearInterval(interval);
  }, []);

  // Automatic WhatsApp popup on user visit
  useEffect(() => {
    try {
      const dismissed = sessionStorage.getItem('10ms_wa_popup_dismissed');
      if (!dismissed) {
        const timer = setTimeout(() => {
          setIsWhatsAppOpen(true);
        }, 1200);
        return () => clearTimeout(timer);
      }
    } catch {
      const timer = setTimeout(() => {
        setIsWhatsAppOpen(true);
      }, 1200);
      return () => clearTimeout(timer);
    }
  }, []);

  const handleCloseWhatsApp = () => {
    setIsWhatsAppOpen(false);
    try {
      sessionStorage.setItem('10ms_wa_popup_dismissed', 'true');
    } catch {}
  };

  // Helper to determine accurate and detailed message source across all pages and home page sections
  const resolveMessageSource = (userTypedText: string): string => {
    const pathname = window.location.pathname;

    // 1. If on a dedicated subpage other than home (e.g. /academic/class8, /academic/ssc/ssc-27, /category/hsc)
    if (pathname && pathname !== '/') {
      const clean = pathname.replace(/\/+$/, '') || '/';
      return clean + (window.location.search || '');
    }

    // 2. We are on the Home Page ('/'):
    // Detect which section the user is currently viewing in the viewport!
    let bestSection: HTMLElement | null = null;
    let maxVisibleHeight = 0;

    if (typeof window !== 'undefined' && typeof document !== 'undefined') {
      const windowHeight = window.innerHeight || document.documentElement.clientHeight;
      const sections = Array.from(
        document.querySelectorAll('[id$="-section"], #courses, #pathways, #reviews, #hero, header')
      );

      for (const sec of sections) {
        const el = sec as HTMLElement;
        const rect = el.getBoundingClientRect();
        const visibleTop = Math.max(0, rect.top);
        const visibleBottom = Math.min(windowHeight, rect.bottom);
        const visibleHeight = Math.max(0, visibleBottom - visibleTop);

        if (visibleHeight > maxVisibleHeight) {
          maxVisibleHeight = visibleHeight;
          bestSection = el;
        }
      }
    }

    const query = userTypedText.toLowerCase().trim();
    const secId = bestSection?.id || '';
    const heading = bestSection?.querySelector('h2, h3, h4')?.textContent?.trim() || '';

    // Check query content for high-intent keywords
    const isHsc28 =
      query.includes('28') ||
      query.includes('২৮') ||
      query.includes('hsc 28') ||
      query.includes('hsc28');
    const isHsc27 =
      query.includes('27') ||
      query.includes('২৭') ||
      query.includes('hsc 27') ||
      query.includes('hsc27');

    // 1. HSC Sections or Query
    if (secId.includes('hsc') || query.includes('hsc') || isHsc28 || isHsc27) {
      if (isHsc28) return '/hsc28 (HSC 28 অনলাইন ব্যাচ)';
      if (isHsc27) return '/hsc27 (HSC 27 অনলাইন ব্যাচ)';
      return '/hsc (HSC 28 ও HSC 27 অনলাইন ব্যাচ)';
    }

    // 2. School Classes (6 to 10) & SSC
    if (
      secId.includes('school') ||
      query.includes('ssc') ||
      query.includes('class') ||
      query.includes('শ্রেণি') ||
      query.includes('ক্লাস')
    ) {
      if (query.includes('6') || query.includes('৬')) return '/academic/class6';
      if (query.includes('7') || query.includes('৭')) return '/academic/class7';
      if (query.includes('8') || query.includes('৮')) return '/academic/class8';
      if (query.includes('9') || query.includes('৯') || query.includes('28') || query.includes('২৮'))
        return '/academic/ssc/ssc-28';
      if (query.includes('10') || query.includes('১০') || query.includes('27') || query.includes('২৭'))
        return '/academic/ssc/ssc-27';
      return '/school (Class 6-10 ও SSC প্রস্তুতি)';
    }

    // 3. Skills & Spoken English / IELTS
    if (
      secId.includes('skills') ||
      query.includes('skill') ||
      query.includes('spoken') ||
      query.includes('ielts') ||
      query.includes('ইংরেজি')
    ) {
      return '/skills (স্কিলস ও প্রফেশনাল কোর্স)';
    }

    // 4. Admission / University / Medical
    if (
      secId.includes('admission') ||
      query.includes('admission') ||
      query.includes('ভর্তি') ||
      query.includes('মেডিকেল') ||
      query.includes('ভার্সিটি')
    ) {
      return '/admission (বিশ্ববিদ্যালয় ও মেডিকেল এডমিশন)';
    }

    // 5. If near a section with an identifiable heading
    if (heading) {
      const slug = secId.replace('-section', '') || 'courses';
      return `/${slug} (${heading})`;
    }

    // 6. Home Page fallback
    return '/home (হোমপেজ - সকল কোর্স)';
  };

  // User sends message in the WhatsApp widget -> saves to backend & opens official WhatsApp
  const handleSendWhatsApp = async (e: React.FormEvent) => {
    e.preventDefault();
    const textToSend = waMessage.trim();
    if (!textToSend) return;

    setIsSendingWa(true);

    try {
      // Dynamic source resolution (handles dedicated routes as well as home page sections/queries)
      const sourcePath = resolveMessageSource(textToSend);
      const formattedMessage = `${textToSend}\n\n— Message Source: ${sourcePath}`;

      // 1. Save to backend database for admin analytics and record keeping
      await fetch('/api/public/message', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name: 'WhatsApp ভিজিটর',
          phoneOrEmail: 'হোয়াটসঅ্যাপ চ্যাট',
          message: formattedMessage,
          courseTitle: `হোয়াটসঅ্যাপ লাইভ চ্যাট সহায়তা (${sourcePath})`,
        }),
      }).catch((err) => {
        console.error('Failed to log WhatsApp message to backend:', err);
      });

      // 2. Open official WhatsApp with the user's pre-filled message + page source reference
      const targetPhone = whatsappNumber.replace(/[^0-9]/g, '') || '8801814946474';
      const cleanPhone = targetPhone.startsWith('88') ? targetPhone : `88${targetPhone}`;
      const waUrl = `https://wa.me/${cleanPhone}?text=${encodeURIComponent(formattedMessage)}`;
      window.open(waUrl, '_blank', 'noopener,noreferrer');

      setWaSentSuccess(true);
      setWaMessage('');
      setTimeout(() => {
        setWaSentSuccess(false);
      }, 3500);
    } catch (error) {
      console.error('Error handling WhatsApp message:', error);
    } finally {
      setIsSendingWa(false);
    }
  };

  // Support counselor inquiry submission (3-dot modal)
  const handleSupportFormSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!message.trim()) return;

    setSubmitting(true);
    setErrorMsg(null);

    try {
      const sourcePath = resolveMessageSource(message.trim());
      const fullMessage = `${message.trim()}\n\n— Message Source: ${sourcePath}`;

      const res = await fetch('/api/public/message', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name: name.trim() || 'শিক্ষার্থী',
          phoneOrEmail: phoneOrEmail.trim(),
          message: fullMessage,
          courseTitle: `${courseTitle.trim()} (${sourcePath})`,
        }),
      });

      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || 'বার্তা পাঠানো সম্ভব হয়নি।');
      }

      setSuccessReply(data.reply || 'আপনার বার্তাটি পেয়েছি। আমরা দ্রুত যোগাযোগ করব।');
      setMessage('');
    } catch (err: any) {
      setErrorMsg(err.message || 'সার্ভারে সংযোগে সমস্যা হয়েছে। অনুগ্রহ করে হোয়াটসঅ্যাপে চেষ্টা করুন।');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="fixed bottom-20 md:bottom-6 right-4 md:right-6 z-50 flex flex-col items-end gap-2.5">
      {/* 1. WHATSAPP LIVE CHAT POPUP (Exact match to image_66e03fdc.png) */}
      {isWhatsAppOpen && (
        <div className="w-[310px] sm:w-[350px] md:w-[370px] bg-white rounded-2xl shadow-2xl border border-black/10 overflow-hidden mb-1 animate-in fade-in slide-in-from-bottom-5 duration-200 select-none">
          {/* Dark Green WhatsApp Header (#075e54) */}
          <div className="bg-[#075e54] text-white px-4 py-3 flex items-center justify-between shadow-xs">
            <div className="flex items-center gap-3">
              {/* White circular logo with 10 Minute School badge */}
              <div className="w-10 h-10 rounded-full bg-white flex items-center justify-center shrink-0 shadow-sm overflow-hidden p-1">
                <div className="flex items-center justify-center font-black text-slate-900 leading-none text-base">
                  <span className="tracking-tighter">1</span>
                  <div className="w-4 h-4 rounded-xs border-2 border-slate-900 relative overflow-hidden flex items-center justify-center mx-0.5">
                    <span className="absolute -top-0.5 -right-0.5 w-2 h-2 bg-red-600 rotate-45 transform" />
                  </div>
                </div>
              </div>

              {/* Title & Subtitle */}
              <div className="flex flex-col">
                <h4 className="font-bold text-[15px] sm:text-[16px] text-white leading-tight">
                  10 Minute School
                </h4>
                <span className="text-[11px] sm:text-xs text-emerald-100/90 font-normal">
                  Typically replies instantly
                </span>
              </div>
            </div>

            {/* Circular Close Button */}
            <button
              type="button"
              onClick={handleCloseWhatsApp}
              className="w-7 h-7 rounded-full bg-black/25 hover:bg-black/40 flex items-center justify-center text-white transition cursor-pointer"
              title="বন্ধ করুন"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          {/* WhatsApp Chat Area with Light Beige Background (#efeae2) */}
          <div className="bg-[#efeae2] p-4 sm:p-4.5 space-y-3 min-h-[170px] flex flex-col justify-between">
            {/* White Chat Bubble */}
            <div className="bg-white rounded-2xl rounded-tl-xs p-3.5 sm:p-4 shadow-sm border border-black/5 text-slate-800 text-[13px] sm:text-[13.5px] leading-relaxed relative max-w-[95%]">
              {/* Dynamic Greeting line matching image_66e03fdc.png */}
              <div className="font-bold text-slate-900 mb-2 flex items-center gap-1.5">
                <span>{greeting.text}</span>
                <span>{greeting.icon}</span>
              </div>

              {/* Greeting message */}
              <p className="text-slate-800 font-normal">
                আসসালামু আলাইকুম। আমাদের হোয়াটসঅ্যাপ সাপোর্টে আপনাকে স্বাগতম! অনুগ্রহ করে জানাবেন, আপনি কোন ক্লাসের শিক্ষার্থী এবং কোন কোর্স সম্পর্কে জানতে চাচ্ছেন?
              </p>

              {/* Timestamp at bottom right matching format */}
              <span className="text-[10px] text-slate-400 font-medium text-right mt-2.5 block tracking-tight">
                {formattedTime || '04 November 2026 10:34:43 AM'}
              </span>
            </div>

            {/* Optional brief confirmation feedback */}
            {waSentSuccess && (
              <div className="p-2.5 bg-emerald-100/90 border border-emerald-300 rounded-xl text-xs text-emerald-900 flex items-center gap-1.5 animate-in fade-in">
                <CheckCircle2 className="w-4 h-4 text-emerald-700 shrink-0" />
                <span>বার্তা পাঠানো হয়েছে! হোয়াটসঅ্যাপ ওপেন হচ্ছে...</span>
              </div>
            )}
          </div>

          {/* WhatsApp Bottom Input Pill & Send Button (Matching image_66e03fdc.png) */}
          <div className="bg-[#efeae2] px-3.5 pb-3.5 pt-1">
            <form onSubmit={handleSendWhatsApp} className="flex items-center gap-2">
              <input
                type="text"
                value={waMessage}
                onChange={(e) => setWaMessage(e.target.value)}
                placeholder="এখানে আপনার মেসেজ লিখুন..."
                className="flex-1 bg-white border border-[#25D366] focus:border-[#075e54] rounded-full px-4 py-2 sm:py-2.5 text-xs sm:text-[13px] text-slate-800 placeholder:text-slate-400 outline-none shadow-2xs font-normal transition"
              />

              {/* Circular Send Button with Paper Plane Icon (Matching image_6c7a6d16.png) */}
              <button
                type="submit"
                disabled={isSendingWa}
                className={`w-10 h-10 rounded-full bg-[#25D366] hover:bg-[#20bd5a] text-white flex items-center justify-center shrink-0 shadow-md transition-all cursor-pointer ${
                  waMessage.trim() ? 'hover:scale-105 active:scale-95 shadow-lg' : 'opacity-90'
                } disabled:opacity-50`}
                title="মেসেজ পাঠান ও হোয়াটসঅ্যাপে যুক্ত হোন"
              >
                {/* Solid white paper airplane send icon matching image_6c7a6d16.png */}
                <svg
                  className="w-5 h-5 fill-white transform -rotate-45 translate-x-0.5 -translate-y-0.5"
                  viewBox="0 0 24 24"
                >
                  <path d="M2.01 21L23 12 2.01 3 2 10l15 2-15 2z" />
                </svg>
              </button>
            </form>
          </div>
        </div>
      )}

      {/* 2. DIRECT COURSE INQUIRY & SUPPORT MODAL (3-Dot Message Bubble Popup) */}
      {isSupportFormOpen && (
        <div className="w-[310px] sm:w-[360px] bg-white rounded-2xl shadow-2xl border border-slate-200 overflow-hidden mb-1 animate-in fade-in slide-in-from-bottom-5 duration-200 select-none">
          {/* Header */}
          <div className="bg-gradient-to-r from-[#107c41] via-[#16a34a] to-[#15803d] text-white p-3.5 flex items-center justify-between shadow-xs">
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-full bg-white/20 flex items-center justify-center font-bold text-white text-sm">
                10
              </div>
              <div>
                <h4 className="font-extrabold text-sm leading-tight">১০ মিনিট স্কুল সহায়তা</h4>
                <div className="flex items-center gap-1.5 text-[11px] text-emerald-100">
                  <span className="w-2 h-2 rounded-full bg-white animate-pulse" />
                  <span>কাউন্সেলর অনলাইন</span>
                </div>
              </div>
            </div>
            <button
              type="button"
              onClick={() => setIsSupportFormOpen(false)}
              className="w-7 h-7 rounded-full bg-white/10 hover:bg-white/20 flex items-center justify-center text-white transition cursor-pointer"
              title="বন্ধ করুন"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          {/* Chat Body */}
          <div className="p-4 bg-slate-50/70 max-h-[380px] overflow-y-auto space-y-3">
            {/* Counselor Note */}
            <div className="flex items-start gap-2">
              <div className="w-6 h-6 rounded-full bg-emerald-600 text-white flex items-center justify-center text-[10px] font-bold shrink-0 mt-0.5">
                ১০
              </div>
              <div className="bg-white border border-slate-200/90 rounded-2xl rounded-tl-xs p-2.5 text-xs text-slate-700 shadow-2xs leading-relaxed">
                আসসালামু আলাইকুম! কোনো কোর্স, ভর্তি কিংবা বিশেষ ছাড় সংক্রান্ত তথ্য জানতে আপনার প্রশ্নটি এখানে লিখুন।
              </div>
            </div>

            {/* Success Notification */}
            {successReply && (
              <div className="p-3 bg-emerald-50 border border-emerald-200 rounded-xl text-xs text-emerald-800 space-y-2">
                <div className="flex items-center gap-1.5 font-bold text-emerald-900">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                  <span>বার্তা পাঠানো সফল হয়েছে!</span>
                </div>
                <p className="leading-relaxed">{successReply}</p>
                <div className="pt-1 border-t border-emerald-200/70 flex items-center justify-between text-[11px]">
                  <span>জরুরি হলে সরাসরি কল/হোয়াটসঅ্যাপ:</span>
                  <a
                    href={whatsappLink}
                    target="_blank"
                    rel="noreferrer"
                    className="font-bold text-emerald-700 hover:underline"
                  >
                    {whatsappNumber}
                  </a>
                </div>
              </div>
            )}

            {errorMsg && (
              <div className="p-2.5 bg-red-50 border border-red-200 rounded-xl text-xs text-red-700">
                {errorMsg}
              </div>
            )}

            {/* Inquiry Form */}
            {!successReply && (
              <form onSubmit={handleSupportFormSubmit} className="space-y-2.5 bg-white p-3 rounded-xl border border-slate-200 shadow-2xs">
                <div>
                  <label className="block text-[11px] font-bold text-slate-700 mb-1">
                    আপনার নাম
                  </label>
                  <input
                    type="text"
                    required
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder="যেমন: সাকিব হাসান"
                    className="w-full text-xs bg-slate-50 border border-slate-200 rounded-lg px-2.5 py-1.5 focus:outline-none focus:border-emerald-500 focus:bg-white"
                  />
                </div>

                <div>
                  <label className="block text-[11px] font-bold text-slate-700 mb-1">
                    মোবাইল / হোয়াটসঅ্যাপ নম্বর
                  </label>
                  <input
                    type="text"
                    required
                    value={phoneOrEmail}
                    onChange={(e) => setPhoneOrEmail(e.target.value)}
                    placeholder="যেমন: 017xxxxxxxx"
                    className="w-full text-xs bg-slate-50 border border-slate-200 rounded-lg px-2.5 py-1.5 focus:outline-none focus:border-emerald-500 focus:bg-white"
                  />
                </div>

                <div>
                  <label className="block text-[11px] font-bold text-slate-700 mb-1">
                    যে কোর্স সম্পর্কে জানতে চান
                  </label>
                  <select
                    value={courseTitle}
                    onChange={(e) => setCourseTitle(e.target.value)}
                    className="w-full text-xs bg-slate-50 border border-slate-200 rounded-lg px-2 py-1.5 focus:outline-none focus:border-emerald-500 focus:bg-white"
                  >
                    <option value="HSC 28 অনলাইন ব্যাচ">HSC 28 অনলাইন ব্যাচ</option>
                    <option value="HSC 27 অনলাইন ব্যাচ">HSC 27 অনলাইন ব্যাচ</option>
                    <option value="SSC 27 প্রস্তুতি কোর্স">SSC 27 প্রস্তুতি কোর্স</option>
                    <option value="Spoken English ও আইইএলটিএস">Spoken English ও আইইএলটিএস</option>
                    <option value="বিশ্ববিদ্যালয় ও মেডিকেল এডমিশন">বিশ্ববিদ্যালয় ও মেডিকেল এডমিশন</option>
                    <option value="অন্যান্য কোর্স ও ছাড়">অন্যান্য কোর্স ও ছাড়</option>
                  </select>
                </div>

                <div>
                  <label className="block text-[11px] font-bold text-slate-700 mb-1">
                    আপনার বার্তা বা প্রশ্ন
                  </label>
                  <textarea
                    rows={2}
                    required
                    value={message}
                    onChange={(e) => setMessage(e.target.value)}
                    placeholder="কোর্সের ফি, সাইকেল বা ভর্তি প্রক্রিয়া নিয়ে লিখুন..."
                    className="w-full text-xs bg-slate-50 border border-slate-200 rounded-lg px-2.5 py-1.5 focus:outline-none focus:border-emerald-500 focus:bg-white resize-none"
                  />
                </div>

                <button
                  type="submit"
                  disabled={submitting}
                  className="w-full py-2 bg-[#107c41] hover:bg-[#0b6132] text-white text-xs font-bold rounded-lg flex items-center justify-center gap-1.5 transition cursor-pointer shadow-xs active:scale-98 disabled:opacity-60"
                >
                  <Send className="w-3.5 h-3.5" />
                  <span>{submitting ? 'পাঠানো হচ্ছে...' : 'বার্তা পাঠান'}</span>
                </button>
              </form>
            )}

            {successReply && (
              <button
                type="button"
                onClick={() => setSuccessReply(null)}
                className="w-full py-1.5 bg-slate-200 hover:bg-slate-300 text-slate-800 text-xs font-bold rounded-lg transition cursor-pointer text-center"
              >
                আরেকটি বার্তা পাঠান
              </button>
            )}
          </div>
        </div>
      )}

      {/* 3. DUAL FLOATING ACTION BUTTONS STACK (Exact match to image_e44f80c7.png & image_66e03fdc.png) */}
      <div className="flex flex-col items-center gap-2.5 select-none">
        {/* Top: WhatsApp Floating Button */}
        <button
          type="button"
          onClick={() => {
            setIsSupportFormOpen(false);
            setIsWhatsAppOpen((prev) => !prev);
          }}
          className="w-13 h-13 rounded-full bg-[#25D366] hover:bg-[#20bd5a] text-white flex items-center justify-center shadow-lg hover:shadow-2xl hover:scale-105 active:scale-95 transition-all duration-200 cursor-pointer group relative"
          aria-label="WhatsApp Live Chat"
          title="হোয়াটসঅ্যাপে সরাসরি চ্যাট করুন"
        >
          {/* Official WhatsApp icon (phone inside bubble) */}
          <svg
            className="w-7 h-7 fill-white"
            viewBox="0 0 24 24"
          >
            <path d="M12.04 2c-5.46 0-9.91 4.45-9.91 9.91 0 1.75.46 3.45 1.32 4.95L2.05 22l5.25-1.38c1.45.79 3.08 1.21 4.74 1.21 5.46 0 9.91-4.45 9.91-9.91 0-2.65-1.03-5.14-2.9-7.01A9.816 9.816 0 0012.04 2zm5.78 14.15c-.24.67-1.39 1.28-1.92 1.36-.5.08-1.14.12-3.66-.92-3.22-1.33-5.3-4.57-5.46-4.78-.16-.21-1.3-1.73-1.3-3.3 0-1.57.82-2.34 1.11-2.66.29-.32.64-.4.85-.4.21 0 .43.002.61.01.2.008.47-.076.73.55.27.64.91 2.22.99 2.38.08.16.13.35.03.56-.1.21-.16.34-.31.52-.16.18-.33.4-.47.54-.16.15-.32.32-.14.63.19.31.83 1.37 1.78 2.22 1.22 1.09 2.25 1.42 2.57 1.58.32.16.51.13.7-.08.19-.21.82-.95 1.04-1.28.22-.32.43-.27.73-.16.29.11 1.87.88 2.19 1.04.32.16.53.24.61.37.08.14.08.79-.16 1.46z" />
          </svg>

          {/* Tooltip on hover */}
          <span className="hidden md:group-hover:block absolute right-15 bg-slate-900 text-white text-[11px] font-bold px-2.5 py-1 rounded-lg whitespace-nowrap shadow-md pointer-events-none">
            {isWhatsAppOpen ? 'হোয়াটসঅ্যাপ বন্ধ করুন' : 'হোয়াটসঅ্যাপে চ্যাট করুন'}
          </span>
        </button>

        {/* Bottom: 3-Dots Message Bubble Button (Direct support & interactive counselor modal) */}
        <button
          type="button"
          onClick={() => {
            setIsWhatsAppOpen(false);
            setIsSupportFormOpen((prev) => !prev);
          }}
          className="w-13 h-13 rounded-full bg-[#10b981] hover:bg-[#059669] text-white flex items-center justify-center shadow-lg hover:shadow-2xl hover:scale-105 active:scale-95 transition-all duration-200 cursor-pointer group relative"
          aria-label="Direct Support Inquiry Message"
          title="কোর্স বিষয়ক সহায়তা বার্তা পাঠান"
        >
          {isSupportFormOpen ? (
            <X className="w-7 h-7 text-white" />
          ) : (
            /* 3-dots chat bubble icon matching image_e44f80c7.png */
            <svg
              className="w-7 h-7 fill-white"
              viewBox="0 0 24 24"
            >
              <path d="M20 2H4c-1.1 0-2 .9-2 2v18l4-4h14c1.1 0 2-.9 2-2V4c0-1.1-.9-2-2-2zM8 11c-.55 0-1-.45-1-1s.45-1 1-1 1 .45 1 1-.45 1-1 1zm4 0c-.55 0-1-.45-1-1s.45-1 1-1 1 .45 1 1-.45 1-1 1zm4 0c-.55 0-1-.45-1-1s.45-1 1-1 1 .45 1 1-.45 1-1 1z" />
            </svg>
          )}

          {/* Tooltip on hover */}
          <span className="hidden md:group-hover:block absolute right-15 bg-slate-900 text-white text-[11px] font-bold px-2.5 py-1 rounded-lg whitespace-nowrap shadow-md pointer-events-none">
            {isSupportFormOpen ? 'কাউন্সিলিং বন্ধ করুন' : 'কোর্স সহায়তা পাঠান'}
          </span>
        </button>
      </div>
    </div>
  );
};
