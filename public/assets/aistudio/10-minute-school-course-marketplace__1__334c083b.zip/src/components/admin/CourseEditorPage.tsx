import React, { useState, useRef, useMemo, useEffect } from 'react';
import { Category, Course } from '../../types.ts';
import { toBengaliNumber } from '../../utils/format.ts';
import { CourseCard } from '../public/CourseCard.tsx';

interface CourseEditorPageProps {
  course: Course | null; // null means creating a new course
  categories: Category[];
  onBackToList: () => void;
  onSave: (courseData: any, id?: number) => Promise<void>;
}

export const CourseEditorPage: React.FC<CourseEditorPageProps> = ({
  course,
  categories,
  onBackToList,
  onSave,
}) => {
  // Essential Core States Only (Clean, Dynamic & Uncluttered)
  const [title, setTitle] = useState(course?.title || '');
  const [slug, setSlug] = useState(course?.slug || '');
  const [categorySlug, setCategorySlug] = useState(
    course?.categorySlug || (categories[0]?.slug ?? 'hsc')
  );
  const [imageUrl, setImageUrl] = useState(course?.imageUrl || '');
  const [imageFit, setImageFit] = useState<'contain' | 'cover'>(
    (course?.imageFit as any) === 'contain' ? 'contain' : 'cover'
  );
  const [originalPrice, setOriginalPrice] = useState(course?.originalPrice ?? 45000);
  const [discountPrice, setDiscountPrice] = useState(course?.discountPrice ?? 4000);
  const [affiliateUrl, setAffiliateUrl] = useState(
    course?.affiliateUrl || 'https://10minuteschool.com/?ref=10ms_affiliate'
  );
  const [shortBadge, setShortBadge] = useState(course?.shortBadge || 'লাইভ ব্যাচ চলমান');
  const [description, setDescription] = useState(
    course?.description ||
      '২০২৭ সালে SSC 2027 বোর্ড পরীক্ষায় সেরা রেজাল্ট করার জন্য সঠিক গাইডলাইন ও ফুল রিভিশন কোর্স...'
  );
  const [isPopular, setIsPopular] = useState(course?.isPopular ?? true);
  const [status, setStatus] = useState(course?.status || 'active');

  // Mobile / Tablet Tab Switcher: 'form' or 'preview'
  const [mobileTab, setMobileTab] = useState<'form' | 'preview'>('form');
  const [previewWidthMode, setPreviewWidthMode] = useState<'card' | 'full'>('card');

  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [uploadingImage, setUploadingImage] = useState(false);
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  // Auto-calculated discount & savings
  const computedFlatSavings = Math.max(0, originalPrice - discountPrice);
  const computedDiscountPercent =
    originalPrice > 0 && originalPrice > discountPrice
      ? Math.round(((originalPrice - discountPrice) / originalPrice) * 100)
      : 0;

  // Title change with auto-slug generation for new courses
  const handleTitleChange = (val: string) => {
    setTitle(val);
    if (!course) {
      const autoSlug = val
        .toLowerCase()
        .replace(/[^a-z0-9\u0980-\u09FF\s-]/g, '')
        .trim()
        .replace(/\s+/g, '-')
        .slice(0, 50);
      setSlug(autoSlug || `course-${Date.now()}`);
    }
  };

  // Compress & optimize uploaded image on client side
  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setUploadingImage(true);
    const reader = new FileReader();
    reader.onload = (event) => {
      const img = new Image();
      img.onload = () => {
        const canvas = document.createElement('canvas');
        const maxDim = 1200;
        let width = img.width;
        let height = img.height;

        if (width > maxDim || height > maxDim) {
          if (width > height) {
            height = Math.round((height * maxDim) / width);
            width = maxDim;
          } else {
            width = Math.round((width * maxDim) / height);
            height = maxDim;
          }
        }

        canvas.width = width;
        canvas.height = height;
        const ctx = canvas.getContext('2d');
        if (ctx) {
          ctx.drawImage(img, 0, 0, width, height);
          const dataUrl = canvas.toDataURL('image/jpeg', 0.88);
          setImageUrl(dataUrl);
        }
        setUploadingImage(false);
      };
      img.onerror = () => {
        setError('ইমেজ ফাইলটি লোড করা যায়নি। অনুগ্রহ করে বৈধ JPG/PNG/WebP ফাইল ব্যবহার করুন।');
        setUploadingImage(false);
      };
      img.src = String(event.target?.result || '');
    };
    reader.readAsDataURL(file);
  };

  // Dynamic Live Preview Course Object
  const previewCourse: Course = useMemo(() => {
    const matchedCat = categories.find((c) => c.slug === categorySlug);
    return {
      id: course?.id || 999999,
      title: title.trim() || 'HSC 28 অনলাইন ব্যাচ (ফিজিক্স, কেমিস্ট্রি, ম্যাথ, বায়োলজি)',
      slug: slug.trim() || 'hsc-28-sample',
      categoryId: matchedCat ? matchedCat.id : null,
      categorySlug,
      shortBadge: shortBadge.trim() || 'লাইভ ব্যাচ চলমান',
      headerTitle: shortBadge.trim() || 'HSC 28',
      headerSubtitle: '',
      discountBadgeText:
        computedDiscountPercent > 0
          ? `${toBengaliNumber(computedDiscountPercent)}% ছাড়`
          : computedFlatSavings > 0
          ? `৳${toBengaliNumber(computedFlatSavings)} ছাড়`
          : '',
      gradientTheme: course?.gradientTheme || 'red',
      description:
        description.trim() ||
        '২০২৭ সালে SSC 2027 বোর্ড পরীক্ষায় সেরা রেজাল্ট করার জন্য সঠিক গাইডলাইন ও ফুল রিভিশন কোর্স...',
      fullDescription: null,
      imageUrl: imageUrl.trim() || null,
      imageFit,
      originalPrice: Number(originalPrice) || 0,
      discountPrice: Number(discountPrice) || 0,
      discountPercent: computedDiscountPercent,
      rating: '৪.৯',
      studentCount: '১০k+',
      duration: '৬ মাস',
      targetStudents: null,
      instructorInfo: '',
      instructorIcon: 'school',
      features: '[]',
      affiliateUrl: affiliateUrl.trim() || 'https://10minuteschool.com',
      isPopular,
      status,
      clickCount: course?.clickCount || 0,
    };
  }, [
    categories,
    categorySlug,
    computedDiscountPercent,
    computedFlatSavings,
    course,
    description,
    discountPrice,
    imageUrl,
    imageFit,
    isPopular,
    originalPrice,
    shortBadge,
    slug,
    status,
    title,
    affiliateUrl,
  ]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim() || !slug.trim() || !affiliateUrl.trim()) {
      setError('কোর্সের নাম, Slug এবং Affiliate URL অবশ্যই পূরণ করতে হবে।');
      return;
    }

    setSaving(true);
    setError(null);
    try {
      const matchedCat = categories.find((c) => c.slug === categorySlug);
      const computedDiscountBadge =
        computedDiscountPercent > 0
          ? `${toBengaliNumber(computedDiscountPercent)}% ছাড়`
          : computedFlatSavings > 0
          ? `৳${toBengaliNumber(computedFlatSavings)} ছাড়`
          : '';

      await onSave(
        {
          title: title.trim(),
          slug: slug.trim(),
          categoryId: matchedCat ? matchedCat.id : null,
          categorySlug,
          shortBadge: shortBadge.trim() || 'লাইভ ব্যাচ চলমান',
          headerTitle: shortBadge.trim() || 'HSC 28',
          headerSubtitle: '',
          discountBadgeText: computedDiscountBadge,
          gradientTheme: course?.gradientTheme || 'red',
          description: description.trim(),
          fullDescription: description.trim(),
          imageUrl: imageUrl.trim() || null,
          imageFit,
          originalPrice: Number(originalPrice) || 0,
          discountPrice: Number(discountPrice) || 0,
          discountPercent: computedDiscountPercent,
          rating: '৪.৯',
          studentCount: '১০k+',
          duration: '৬ মাস',
          targetStudents: null,
          instructorInfo: '',
          instructorIcon: 'school',
          features: '[]',
          affiliateUrl: affiliateUrl.trim(),
          isPopular,
          status,
        },
        course?.id
      );
      onBackToList();
    } catch (err: any) {
      setError(err.message || 'কোর্স সেভ করতে সমস্যা হয়েছে।');
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="space-y-6 pb-20">
      {/* ========================================================= */}
      {/* TOP NAVIGATION & ACTION BAR                               */}
      {/* ========================================================= */}
      <div className="bg-white rounded-2xl border border-slate-200 p-4 sm:p-5 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <button
            type="button"
            onClick={onBackToList}
            className="px-3 py-2 rounded-xl border border-slate-200 bg-slate-50 hover:bg-slate-100 text-slate-700 text-xs font-bold flex items-center gap-1.5 transition cursor-pointer shrink-0"
            title="কোর্সের তালিকায় ফিরে যান"
          >
            <span className="material-symbols-outlined text-[18px]">arrow_back</span>
            <span>কোর্স লিস্ট</span>
          </button>

          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-base sm:text-lg font-extrabold text-slate-900 tracking-tight">
                {course ? 'কোর্স তথ্য ও ইমেজ এডিট করুন' : '+ নতুন কোর্স তৈরি করুন'}
              </h1>
              {course && (
                <span className="px-2 py-0.5 rounded-md bg-slate-100 text-slate-600 font-mono text-[11px] font-bold">
                  ID: #{course.id}
                </span>
              )}
            </div>
            <p className="text-xs text-slate-500 mt-0.5">
              সেভ করার সাথে সাথেই ওয়েবসাইট ও অ্যাফিলিয়েট লিংকে আপডেট কার্যকর হবে।
            </p>
          </div>
        </div>

        {/* Action Buttons & Mobile Tab Toggle */}
        <div className="flex items-center gap-2.5 justify-between md:justify-end">
          {/* Mobile / Tablet View Switcher: Form vs Preview */}
          <div className="lg:hidden flex items-center p-0.5 bg-slate-100 rounded-xl text-xs font-bold">
            <button
              type="button"
              onClick={() => setMobileTab('form')}
              className={`px-3 py-1.5 rounded-lg transition ${
                mobileTab === 'form' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600'
              }`}
            >
              ✏️ ফরম
            </button>
            <button
              type="button"
              onClick={() => setMobileTab('preview')}
              className={`px-3 py-1.5 rounded-lg transition flex items-center gap-1.5 ${
                mobileTab === 'preview' ? 'bg-red-600 text-white shadow-xs' : 'text-slate-600'
              }`}
            >
              <span>👁️ কার্ড প্রিভিউ</span>
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
            </button>
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={onBackToList}
              className="px-3.5 py-2 rounded-xl border border-slate-300 text-xs font-bold text-slate-700 hover:bg-slate-100 transition cursor-pointer"
            >
              বাতিল
            </button>
            <button
              type="submit"
              form="course-page-form"
              disabled={saving}
              className="px-5 py-2 rounded-xl bg-gradient-to-r from-red-600 to-rose-600 hover:from-red-500 hover:to-rose-500 text-white text-xs font-bold shadow-md hover:shadow-lg transition cursor-pointer disabled:opacity-50 flex items-center gap-1.5"
            >
              <span className="material-symbols-outlined text-[17px]">
                {saving ? 'hourglass_empty' : 'save'}
              </span>
              <span>{saving ? 'সেভ হচ্ছে...' : 'কোর্স সেভ ও পাবলিশ'}</span>
            </button>
          </div>
        </div>
      </div>

      {error && (
        <div className="p-4 rounded-xl bg-red-50 border border-red-200 text-xs font-bold text-red-700 flex items-center gap-2">
          <span className="material-symbols-outlined text-[18px]">error</span>
          <span>{error}</span>
        </div>
      )}

      {/* ========================================================= */}
      {/* 2-COLUMN RESPONSIVE LAYOUT (FORM LEFT, LIVE PREVIEW RIGHT)*/}
      {/* ========================================================= */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* ======================================================= */}
        {/* LEFT COLUMN: DYNAMIC STREAMLINED FORM (NO UNNECESSARY JUNK)*/}
        {/* ======================================================= */}
        <form
          id="course-page-form"
          onSubmit={handleSubmit}
          className={`space-y-6 ${
            mobileTab === 'preview' ? 'hidden lg:block lg:col-span-7' : 'lg:col-span-7'
          }`}
        >
          {/* SECTION 1: COURSE IMAGE (10 Minute School Image) */}
          <div className="bg-white rounded-2xl border border-slate-200 p-5 space-y-4 shadow-xs">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-100 pb-3">
              <div>
                <h2 className="text-sm font-extrabold text-slate-900 flex items-center gap-2">
                  <span className="material-symbols-outlined text-[20px] text-red-600">
                    photo_library
                  </span>
                  কোর্স ইমেজ (১০ মিনিট স্কুল থাম্বনেইল)
                </h2>
                <p className="text-xs text-slate-500 mt-0.5">
                  সরাসরি ইমেজ URL পেস্ট করুন অথবা কম্পিউটার থেকে আপলোড করুন।
                </p>
              </div>

              <div className="flex items-center gap-2 shrink-0">
                <input
                  ref={fileInputRef}
                  type="file"
                  accept="image/*"
                  onChange={handleFileUpload}
                  className="hidden"
                />
                <button
                  type="button"
                  onClick={() => fileInputRef.current?.click()}
                  className="px-3.5 py-1.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold flex items-center gap-1.5 transition cursor-pointer"
                >
                  <span className="material-symbols-outlined text-[16px]">upload</span>
                  <span>{imageUrl ? 'নতুন ইমেজ আপলোড' : 'ইমেজ আপলোড'}</span>
                </button>
                {imageUrl && (
                  <button
                    type="button"
                    onClick={() => setImageUrl('')}
                    className="px-2.5 py-1.5 rounded-xl bg-red-50 hover:bg-red-100 text-red-700 border border-red-200 text-xs font-bold flex items-center gap-1 transition cursor-pointer"
                    title="ইমেজ রিমুভ করে ডিফল্ট ব্যানার ব্যবহার করুন"
                  >
                    <span className="material-symbols-outlined text-[16px]">delete</span>
                    <span>রিমুভ</span>
                  </button>
                )}
              </div>
            </div>

            {/* Direct Image URL input */}
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                সরাসরি ইমেজ URL:
              </label>
              <input
                type="url"
                value={imageUrl}
                onChange={(e) => setImageUrl(e.target.value)}
                placeholder="https://cdn.10minuteschool.com/images/Thumbnails/..."
                className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 text-xs font-mono focus:border-red-600 focus:outline-none bg-slate-50/50 text-slate-800"
              />
              {uploadingImage && (
                <span className="text-[11px] text-blue-600 font-semibold mt-1 flex items-center gap-1">
                  <span className="w-2 h-2 rounded-full bg-blue-600 animate-ping" />
                  ইমেজ অপ্টিমাইজ ও লোড হচ্ছে...
                </span>
              )}
            </div>
          </div>

          {/* SECTION 2: CORE COURSE DETAILS */}
          <div className="bg-white rounded-2xl border border-slate-200 p-5 space-y-4 shadow-xs">
            <h2 className="text-sm font-extrabold text-slate-900 border-b border-slate-100 pb-2.5 flex items-center gap-2">
              <span className="material-symbols-outlined text-[20px] text-red-600">
                menu_book
              </span>
              কোর্সের নাম ও ক্যাটাগরি
            </h2>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                কোর্সের পূর্ণ নাম (Course Title) *
              </label>
              <input
                type="text"
                required
                value={title}
                onChange={(e) => handleTitleChange(e.target.value)}
                placeholder="যেমন: SSC 27 বোর্ড পরীক্ষা প্রস্তুতি - [বিজ্ঞান বিভাগ + শেষ মুহূর্তের প্রস্তুতি]"
                className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 text-xs sm:text-sm font-semibold focus:border-red-600 focus:outline-none bg-white text-slate-900"
              />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  কোর্স URL Slug (রিডাইরেক্ট কোড) *
                </label>
                <input
                  type="text"
                  required
                  value={slug}
                  onChange={(e) => setSlug(e.target.value)}
                  placeholder="ssc-27-board-prep"
                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 text-xs font-mono focus:border-red-600 focus:outline-none bg-white text-slate-800"
                />
                <span className="text-[10px] text-slate-400 mt-1 block">
                  লিংক: <code className="text-slate-600 font-mono">/go/{slug || 'slug'}</code>
                </span>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  ক্যাটাগরি (Category) *
                </label>
                <select
                  value={categorySlug}
                  onChange={(e) => setCategorySlug(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 text-xs font-bold focus:border-red-600 focus:outline-none bg-white text-slate-800"
                >
                  {categories.map((cat) => (
                    <option key={cat.slug} value={cat.slug}>
                      {cat.name} ({cat.slug})
                    </option>
                  ))}
                </select>
              </div>
            </div>
          </div>

          {/* SECTION 3: PRICING & 10MS AFFILIATE LINK */}
          <div className="bg-white rounded-2xl border border-slate-200 p-5 space-y-4 shadow-xs">
            <div className="flex items-center justify-between border-b border-slate-100 pb-2.5">
              <h2 className="text-sm font-extrabold text-slate-900 flex items-center gap-2">
                <span className="material-symbols-outlined text-[20px] text-emerald-600">
                  payments
                </span>
                মূল্য ও ১০ মিনিট স্কুল অ্যাফিলিয়েট লিংক
              </h2>
              <span className="text-[11px] font-bold text-emerald-800 bg-emerald-50 px-2.5 py-0.5 rounded-md border border-emerald-200">
                লাইভ ডিসকাউন্ট হিসাব
              </span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3.5 tabular-nums">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  রেগুলার প্রাইস / Original Price (৳) *
                </label>
                <input
                  type="number"
                  required
                  min={0}
                  value={originalPrice}
                  onChange={(e) => setOriginalPrice(Number(e.target.value))}
                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 text-xs font-bold bg-white text-slate-900"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  ডিসকাউন্ট প্রাইস / Discount Price (৳) *
                </label>
                <input
                  type="number"
                  required
                  min={0}
                  value={discountPrice}
                  onChange={(e) => setDiscountPrice(Number(e.target.value))}
                  className="w-full px-3.5 py-2.5 rounded-xl border-2 border-emerald-600 text-xs font-black text-emerald-700 bg-white"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  কার্ডে স্বয়ংক্রিয় ডিসকাউন্ট ব্যাজ
                </label>
                <div className="px-3.5 py-2.5 rounded-xl bg-emerald-50/80 border border-emerald-200 text-xs font-extrabold text-emerald-800 flex items-center justify-between min-h-[42px]">
                  <span>{toBengaliNumber(computedDiscountPercent)}% সেভিংস</span>
                  <span className="text-red-600 font-black">
                    (৳{toBengaliNumber(computedFlatSavings)} ছাড়)
                  </span>
                </div>
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                10 Minute School অফিশিয়াল অ্যাফিলিয়েট লিংক (Affiliate URL) *
              </label>
              <input
                type="url"
                required
                value={affiliateUrl}
                onChange={(e) => setAffiliateUrl(e.target.value)}
                placeholder="https://10ms.io/... অথবা https://10minuteschool.com/product/..."
                className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 text-xs font-mono bg-white focus:border-red-600 focus:outline-none text-slate-800"
              />
              <span className="text-[11px] text-slate-400 mt-1 block">
                শিক্ষার্থী কার্ডে ক্লিক করলে সরাসরি এই অ্যাফিলিয়েট লিংকে যাবে।
              </span>
            </div>
          </div>

          {/* SECTION 4: BADGES, SHORT DESCRIPTION & VISIBILITY */}
          <div className="bg-white rounded-2xl border border-slate-200 p-5 space-y-4 shadow-xs">
            <h2 className="text-sm font-extrabold text-slate-900 border-b border-slate-100 pb-2.5 flex items-center gap-2">
              <span className="material-symbols-outlined text-[20px] text-red-600">
                label
              </span>
              ব্যাচ ট্যাগ ও সংক্ষিপ্ত বিবরণ
            </h2>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  টপ ব্যাজ বা ব্যাচ ট্যাগ (যেমন: দশম শ্রেণি / HSC 28 / লাইভ ব্যাচ চলমান)
                </label>
                <input
                  type="text"
                  value={shortBadge}
                  onChange={(e) => setShortBadge(e.target.value)}
                  placeholder="যেমন: দশম শ্রেণি অথবা HSC 28"
                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 text-xs focus:border-red-600 focus:outline-none bg-white text-slate-800"
                />
                <div className="flex flex-wrap gap-1 mt-1.5">
                  {['দশম শ্রেণি', 'HSC 28', 'HSC 27', 'SSC 27', 'লাইভ ব্যাচ চলমান', 'অনলাইন ব্যাচ', 'স্পেশাল বান্ডেল'].map(
                    (b) => (
                      <button
                        key={b}
                        type="button"
                        onClick={() => setShortBadge(b)}
                        className="text-[10px] bg-slate-100 hover:bg-slate-200 px-2 py-0.5 rounded text-slate-700 font-semibold cursor-pointer"
                      >
                        + {b}
                      </button>
                    )
                  )}
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  সংক্ষিপ্ত বিবরণ (Card Description) *
                </label>
                <textarea
                  rows={2}
                  required
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  placeholder="কোর্সের সংক্ষেপ বিবরণ..."
                  className="w-full px-3.5 py-2 rounded-xl border border-slate-300 text-xs focus:border-red-600 focus:outline-none bg-white text-slate-800"
                />
              </div>
            </div>

            <div className="p-3.5 bg-slate-50 border border-slate-200 rounded-xl flex flex-wrap items-center justify-between gap-4">
              <div className="flex items-center gap-6">
                <label className="inline-flex items-center gap-2 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={status === 'active'}
                    onChange={(e) => setStatus(e.target.checked ? 'active' : 'inactive')}
                    className="w-4 h-4 rounded text-emerald-600 focus:ring-emerald-500"
                  />
                  <span className="text-xs font-bold text-slate-800">
                    পাবলিক ওয়েবসাইটে চালু (Active Course)
                  </span>
                </label>

                <label className="inline-flex items-center gap-2 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={isPopular}
                    onChange={(e) => setIsPopular(e.target.checked)}
                    className="w-4 h-4 rounded text-red-600 focus:ring-red-500"
                  />
                  <span className="text-xs font-bold text-slate-800">
                    জনপ্রিয় কোর্স (Popular / Featured)
                  </span>
                </label>
              </div>
            </div>
          </div>
        </form>

        {/* ======================================================= */}
        {/* RIGHT COLUMN: ACTUAL LIVE PREVIEW (CourseCard)          */}
        {/* ======================================================= */}
        <div
          className={`lg:col-span-5 lg:sticky lg:top-6 space-y-4 ${
            mobileTab === 'form' ? 'hidden lg:block' : 'block'
          }`}
        >
          <div className="bg-slate-900 text-white p-4 rounded-2xl border border-slate-800 space-y-3 shadow-md">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-pulse" />
                <span className="text-xs sm:text-sm font-extrabold tracking-tight">
                  লাইভ অ্যাকচুয়াল কোর্স কার্ড প্রিভিউ
                </span>
              </div>

              {/* Card Width Switcher */}
              <div className="flex items-center gap-1 text-[10px] font-bold">
                <button
                  type="button"
                  onClick={() => setPreviewWidthMode('card')}
                  className={`px-2.5 py-1 rounded-md transition ${
                    previewWidthMode === 'card'
                      ? 'bg-red-600 text-white'
                      : 'text-slate-400 hover:text-white'
                  }`}
                >
                  কার্ড ভিউ
                </button>
                <button
                  type="button"
                  onClick={() => setPreviewWidthMode('full')}
                  className={`px-2.5 py-1 rounded-md transition ${
                    previewWidthMode === 'full'
                      ? 'bg-red-600 text-white'
                      : 'text-slate-400 hover:text-white'
                  }`}
                >
                  ফুল ভিউ
                </button>
              </div>
            </div>

            <div className="text-[11px] text-slate-400">
              ফরমে যা দিচ্ছেন, শিক্ষার্থী ওয়েবসাইটে কার্ডটি হুবহু নিচের মতো দেখা যাবে।
            </div>
          </div>

          {/* Actual CourseCard Container */}
          <div className="p-4 sm:p-6 bg-slate-100 rounded-2xl border border-slate-200 flex flex-col items-center justify-center">
            <div
              className={`w-full transition-all duration-200 ${
                previewWidthMode === 'card' ? 'max-w-[340px]' : 'max-w-md'
              }`}
            >
              <CourseCard
                course={previewCourse}
                onEnrollClick={() => {
                  window.open(affiliateUrl, '_blank');
                }}
              />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
