import React, { useEffect, useState, useCallback } from 'react';
import { Category, ClickRecord, Course, SiteSettings, CustomerInquiry } from '../../types.ts';
import { getGradientClasses, toBengaliNumber } from '../../utils/format.ts';
import { CourseEditorPage } from './CourseEditorPage.tsx';

interface AdminDashboardProps {
  authToken: string;
  adminEmail: string;
  adminName: string;
  onLogout: () => void;
  onViewPublicSite: () => void;
  onDataMutated: () => void;
  onDownloadZip?: () => void;
}

type AdminTab = 'overview' | 'courses' | 'categories' | 'analytics' | 'messages' | 'settings' | 'course_editor';

export const AdminDashboard: React.FC<AdminDashboardProps> = ({
  authToken,
  adminEmail,
  adminName,
  onLogout,
  onViewPublicSite,
  onDataMutated,
  onDownloadZip,
}) => {
  const [activeTab, setActiveTab] = useState<AdminTab>('overview');
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [toast, setToast] = useState<string | null>(null);

  const [stats, setStats] = useState({
    totalCourses: 0,
    activeCourses: 0,
    inactiveCourses: 0,
    totalClicks: 0,
    totalCategories: 0,
  });
  const [courses, setCourses] = useState<Course[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [recentClicks, setRecentClicks] = useState<ClickRecord[]>([]);
  const [settings, setSettings] = useState<SiteSettings | null>(null);
  const [inquiries, setInquiries] = useState<CustomerInquiry[]>([]);

  // Course management states
  const [searchQuery, setSearchQuery] = useState('');
  const [filterCat, setFilterCat] = useState('all');
  const [editingCourse, setEditingCourse] = useState<Course | null>(null);
  const [confirmDeleteCourseId, setConfirmDeleteCourseId] = useState<number | null>(null);

  // Category form states
  const [editingCat, setEditingCat] = useState<Category | null>(null);
  const [catName, setCatName] = useState('');
  const [catSlug, setCatSlug] = useState('');
  const [catSubtitle, setCatSubtitle] = useState('');
  const [catColor, setCatColor] = useState('red');
  const [catOrder, setCatOrder] = useState(1);
  const [confirmDeleteCatId, setConfirmDeleteCatId] = useState<number | null>(null);

  // Settings form states
  const [siteTitle, setSiteTitle] = useState('');
  const [whatsappNumber, setWhatsappNumber] = useState('');
  const [whatsappLink, setWhatsappLink] = useState('');
  const [heroBadge, setHeroBadge] = useState('');
  const [heroTitle, setHeroTitle] = useState('');
  const [heroSubtitle, setHeroSubtitle] = useState('');
  const [countdownLabel, setCountdownLabel] = useState('HSC ২৮ আর্লি বার্ড স্পেশাল উপহার সহ ছাড়ে বাকি:');
  const [showCountdownTimer, setShowCountdownTimer] = useState(true);
  const [countdownTargetCourse, setCountdownTargetCourse] = useState('all');
  const [countdownTargetDate, setCountdownTargetDate] = useState('');
  const [savingTimer, setSavingTimer] = useState(false);
  const [defaultAffiliateRef, setDefaultAffiliateRef] = useState('');
  const [savingSettings, setSavingSettings] = useState(false);
  const [savingWhatsApp, setSavingWhatsApp] = useState(false);
  const [copiedSlug, setCopiedSlug] = useState<string | null>(null);

  const showToast = (msg: string) => {
    setToast(msg);
    setTimeout(() => setToast(null), 3200);
  };

  const fetchOverview = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await fetch('/api/admin/overview', {
        headers: {
          Authorization: `Bearer ${authToken}`,
        },
      });
      if (!res.ok) {
        throw new Error('অ্যাডমিন ডেটা লোড করতে ব্যর্থ হয়েছে।');
      }
      const data = await res.json();
      setStats(data.stats);
      setCourses(data.courses || []);
      setCategories(data.categories || []);
      setRecentClicks(data.recentClicks || []);
      if (data.settings) {
        setSettings(data.settings);
        setSiteTitle(data.settings.siteTitle || '');
        setWhatsappNumber(data.settings.whatsappNumber || '');
        setWhatsappLink(data.settings.whatsappLink || '');
        setHeroBadge(data.settings.heroBadge || '');
        setHeroTitle(data.settings.heroTitle || '');
        setHeroSubtitle(data.settings.heroSubtitle || '');
        setCountdownLabel(data.settings.countdownLabel || 'HSC ২৮ আর্লি বার্ড স্পেশাল উপহার সহ ছাড়ে বাকি:');
        setShowCountdownTimer(data.settings.showCountdownTimer !== false);
        setCountdownTargetCourse(data.settings.countdownTargetCourse || 'all');
        setCountdownTargetDate(data.settings.countdownTargetDate || '');
        setDefaultAffiliateRef(data.settings.defaultAffiliateRef || '');
      }

      // Also fetch inquiries
      try {
        const msgRes = await fetch('/api/admin/messages', {
          headers: { Authorization: `Bearer ${authToken}` },
        });
        if (msgRes.ok) {
          const msgData = await msgRes.json();
          setInquiries(msgData.inquiries || []);
        }
      } catch {}
    } catch (err: any) {
      setError(err.message || 'ডেটা লোড করতে সমস্যা হয়েছে।');
    } finally {
      setLoading(false);
    }
  }, [authToken]);

  const handleDeleteInquiry = async (id: number) => {
    try {
      const res = await fetch(`/api/admin/messages/${id}`, {
        method: 'DELETE',
        headers: { Authorization: `Bearer ${authToken}` },
      });
      if (!res.ok) throw new Error('মেসেজ মোছা যায়নি।');
      setInquiries((prev) => prev.filter((i) => i.id !== id));
      showToast('মেসেজটি সফলভাবে মুছে ফেলা হয়েছে।');
    } catch (err: any) {
      showToast(err.message || 'সমস্যা হয়েছে');
    }
  };

  useEffect(() => {
    fetchOverview();
  }, [fetchOverview]);

  // Save (Create or Update) Course
  const handleSaveCourse = async (courseData: any, id?: number) => {
    const url = id ? `/api/admin/courses/${id}` : '/api/admin/courses';
    const method = id ? 'PUT' : 'POST';
    const res = await fetch(url, {
      method,
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${authToken}`,
      },
      body: JSON.stringify(courseData),
    });

    if (!res.ok) {
      const errData = await res.json().catch(() => ({}));
      throw new Error(errData.error || 'কোর্স সংরক্ষণ করা যায়নি।');
    }

    await fetchOverview();
    onDataMutated();
    showToast(id ? 'কোর্স সফলভাবে আপডেট করা হয়েছে!' : 'নতুন কোর্স সফলভাবে যোগ করা হয়েছে!');
  };

  // Toggle Course Active/Inactive Status
  const handleToggleCourseStatus = async (course: Course) => {
    const nextStatus = course.status === 'active' ? 'inactive' : 'active';
    try {
      const res = await fetch(`/api/admin/courses/${course.id}/status`, {
        method: 'PATCH',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${authToken}`,
        },
        body: JSON.stringify({ status: nextStatus }),
      });
      if (!res.ok) throw new Error('স্ট্যাটাস পরিবর্তন করা যায়নি।');
      await fetchOverview();
      onDataMutated();
      showToast(
        nextStatus === 'active'
          ? `“${course.title}” পাবলিক ওয়েবসাইটে চালু করা হয়েছে।`
          : `“${course.title}” পাবলিক ওয়েবসাইট থেকে লুকানো (Disable) হয়েছে।`
      );
    } catch (err: any) {
      showToast(err.message || 'সমস্যা হয়েছে');
    }
  };

  // Delete Course
  const handleDeleteCourse = async (id: number) => {
    try {
      const res = await fetch(`/api/admin/courses/${id}`, {
        method: 'DELETE',
        headers: {
          Authorization: `Bearer ${authToken}`,
        },
      });
      if (!res.ok) throw new Error('কোর্স ডিলিট করা যায়নি।');
      setConfirmDeleteCourseId(null);
      await fetchOverview();
      onDataMutated();
      showToast('কোর্স সফলভাবে ডিলিট করা হয়েছে।');
    } catch (err: any) {
      showToast(err.message || 'ডিলিট করতে সমস্যা হয়েছে');
    }
  };

  // Create or Update Category
  const handleSaveCategory = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!catName.trim() || !catSlug.trim()) return;
    try {
      const url = editingCat
        ? `/api/admin/categories/${editingCat.id}`
        : '/api/admin/categories';
      const method = editingCat ? 'PUT' : 'POST';
      const res = await fetch(url, {
        method,
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${authToken}`,
        },
        body: JSON.stringify({
          name: catName.trim(),
          slug: catSlug.trim(),
          subtitle: catSubtitle.trim() || 'অনলাইন ব্যাচ ও কোর্স',
          badgeColor: catColor,
          displayOrder: Number(catOrder),
          status: editingCat ? editingCat.status : 'active',
        }),
      });
      if (!res.ok) throw new Error('ক্যাটাগরি সেভ করা যায়নি।');
      setEditingCat(null);
      setCatName('');
      setCatSlug('');
      setCatSubtitle('');
      await fetchOverview();
      onDataMutated();
      showToast(editingCat ? 'ক্যাটাগরি আপডেট হয়েছে!' : 'নতুন ক্যাটাগরি তৈরি হয়েছে!');
    } catch (err: any) {
      showToast(err.message || 'সমস্যা হয়েছে');
    }
  };

  const handleToggleCategoryStatus = async (cat: Category) => {
    const nextStatus = cat.status === 'active' ? 'inactive' : 'active';
    try {
      await fetch(`/api/admin/categories/${cat.id}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${authToken}`,
        },
        body: JSON.stringify({ status: nextStatus }),
      });
      await fetchOverview();
      onDataMutated();
      showToast('ক্যাটাগরি স্ট্যাটাস আপডেট করা হয়েছে।');
    } catch {
      showToast('স্ট্যাটাস আপডেট ব্যর্থ হয়েছে।');
    }
  };

  const handleDeleteCategory = async (id: number) => {
    try {
      await fetch(`/api/admin/categories/${id}`, {
        method: 'DELETE',
        headers: {
          Authorization: `Bearer ${authToken}`,
        },
      });
      setConfirmDeleteCatId(null);
      await fetchOverview();
      onDataMutated();
      showToast('ক্যাটাগরি ডিলিট করা হয়েছে।');
    } catch {
      showToast('ক্যাটাগরি ডিলিট করা যায়নি (এতে কোর্স যুক্ত থাকতে পারে)।');
    }
  };

  // Save Site Settings
  const handleSaveSettings = async (e: React.FormEvent) => {
    e.preventDefault();
    setSavingSettings(true);
    try {
      const res = await fetch('/api/admin/settings', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${authToken}`,
        },
        body: JSON.stringify({
          siteTitle,
          whatsappNumber,
          whatsappLink,
          heroBadge,
          heroTitle,
          heroSubtitle,
          showCountdownTimer,
          countdownLabel,
          countdownTargetCourse,
          countdownTargetDate,
          defaultAffiliateRef,
        }),
      });
      if (!res.ok) throw new Error('সেটিংস সেভ করা যায়নি।');
      await fetchOverview();
      onDataMutated();
      showToast('ওয়েবসাইট সেটিংস সফলভাবে আপডেট করা হয়েছে!');
    } catch (err: any) {
      showToast(err.message || 'সমস্যা হয়েছে');
    } finally {
      setSavingSettings(false);
    }
  };

  // Dedicated Auto-Sync and Instant Save Handlers for WhatsApp Number
  const handleWhatsappNumberChange = (val: string) => {
    setWhatsappNumber(val);
    const digits = val.replace(/[^0-9]/g, '');
    if (digits) {
      const clean = digits.startsWith('88') ? digits : `88${digits}`;
      setWhatsappLink(`https://wa.me/${clean}`);
    } else {
      setWhatsappLink('');
    }
  };

  const handleSaveWhatsAppOnly = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!whatsappNumber.trim()) {
      showToast('❌ অনুগ্রহ করে একটি বৈধ হোয়াটসঅ্যাপ নম্বর দিন।');
      return;
    }

    setSavingWhatsApp(true);
    try {
      const digits = whatsappNumber.replace(/[^0-9]/g, '');
      const clean = digits.startsWith('88') ? digits : `88${digits}`;
      const generatedLink = `https://wa.me/${clean}`;

      const res = await fetch('/api/admin/settings', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${authToken}`,
        },
        body: JSON.stringify({
          whatsappNumber: whatsappNumber.trim(),
          whatsappLink: generatedLink,
        }),
      });

      if (!res.ok) throw new Error('নম্বর সেভ করা সম্ভব হয়নি।');

      setWhatsappLink(generatedLink);
      await fetchOverview();
      onDataMutated();
      showToast(`✅ হোয়াটসঅ্যাপ নম্বর সফলভাবে সেভ হয়েছে: ${whatsappNumber.trim()}`);
    } catch (err: any) {
      showToast('❌ ' + (err.message || 'নম্বর সংরক্ষণে সমস্যা হয়েছে'));
    } finally {
      setSavingWhatsApp(false);
    }
  };

  // Dedicated Save Handler for Offer Countdown Timer
  const handleSaveTimerControl = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    setSavingTimer(true);
    try {
      const res = await fetch('/api/admin/settings', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${authToken}`,
        },
        body: JSON.stringify({
          showCountdownTimer,
          countdownLabel: countdownLabel.trim(),
          countdownTargetCourse,
          countdownTargetDate,
        }),
      });
      if (!res.ok) throw new Error('টাইমার সেটিংস সেভ করতে সমস্যা হয়েছে।');
      await fetchOverview();
      onDataMutated();
      showToast(
        showCountdownTimer
          ? '✅ অফার কাউন্টডাউন টাইমার সফলভাবে চালু ও আপডেট করা হয়েছে!'
          : '⏸️ কাউন্টডাউন টাইমার সফলভাবে বন্ধ (OFF) করা হয়েছে!'
      );
    } catch (err: any) {
      showToast('❌ ' + (err.message || 'ত্রুটি ঘটেছে'));
    } finally {
      setSavingTimer(false);
    }
  };

  // Instant 1-Click Toggle for Countdown Timer
  const handleToggleTimerQuick = async (newState: boolean) => {
    setShowCountdownTimer(newState);
    try {
      await fetch('/api/admin/settings', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${authToken}`,
        },
        body: JSON.stringify({
          showCountdownTimer: newState,
          countdownLabel,
          countdownTargetCourse,
          countdownTargetDate,
        }),
      });
      await fetchOverview();
      onDataMutated();
      showToast(
        newState
          ? '✅ হোমপেজে টাইমার সক্রিয় করা হয়েছে!'
          : '⏸️ হোমপেজ থেকে টাইমার নিষ্ক্রিয় (OFF) করা হয়েছে!'
      );
    } catch {
      showToast('❌ টাইমার স্ট্যাটাস পরিবর্তন ব্যর্থ হয়েছে।');
    }
  };

  // Course Selector Change handler with smart auto label suggest
  const handleCourseSelectionChange = (courseSlug: string) => {
    setCountdownTargetCourse(courseSlug);
    if (courseSlug === 'all') {
      setCountdownLabel('HSC ২৮ আর্লি বার্ড স্পেশাল উপহার সহ ছাড়ে বাকি:');
    } else {
      const matched = courses.find((c) => c.slug === courseSlug);
      if (matched) {
        const cleanName = matched.title.split('—')[0].replace(/\[.*\]/, '').trim();
        setCountdownLabel(`${cleanName} স্পেশাল উপহার সহ ছাড়ে বাকি:`);
      }
    }
  };

  // Helper to add days to target date
  const setQuickExpiryDays = (days: number) => {
    const d = new Date();
    d.setDate(d.getDate() + days);
    d.setHours(23, 59, 0, 0);
    // Format YYYY-MM-DDTHH:mm for datetime-local
    const pad = (n: number) => String(n).padStart(2, '0');
    const localStr = `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}T${pad(d.getHours())}:${pad(d.getMinutes())}`;
    setCountdownTargetDate(localStr);
  };

  const filteredCourses = courses.filter((c) => {
    const matchesCat = filterCat === 'all' || c.categorySlug === filterCat;
    const q = searchQuery.toLowerCase().trim();
    const matchesSearch =
      !q ||
      c.title.toLowerCase().includes(q) ||
      c.slug.toLowerCase().includes(q) ||
      c.headerTitle.toLowerCase().includes(q);
    return matchesCat && matchesSearch;
  });

  const maxClicks = Math.max(1, ...courses.map((c) => c.clickCount || 0));

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 flex flex-col lg:flex-row">
      {/* Toast Notification */}
      {toast && (
        <div className="fixed bottom-5 right-5 z-50 bg-slate-900 text-white px-4 py-3 rounded-xl shadow-xl border border-slate-700 text-xs font-bold flex items-center gap-2">
          <span className="material-symbols-outlined text-[18px] text-emerald-400">
            check_circle
          </span>
          <span>{toast}</span>
        </div>
      )}

      {/* SIDEBAR NAVIGATION */}
      <aside className="w-full lg:w-64 bg-slate-950 text-slate-300 border-b lg:border-b-0 lg:border-r border-slate-800 shrink-0 flex flex-col justify-between">
        <div className="p-5 space-y-6">
          <div className="flex items-center justify-between">
            <div>
              <div className="text-base font-extrabold text-white tracking-tight">
                10MS Admin Portal
              </div>
              <div className="text-[11px] text-slate-400">
                Affiliate & Course Manager
              </div>
            </div>
            <button
              type="button"
              onClick={onViewPublicSite}
              className="lg:hidden px-3 py-1.5 rounded-lg bg-slate-800 text-white text-xs font-bold"
            >
              লাইভ সাইট ↗
            </button>
          </div>

          <nav className="flex lg:flex-col gap-1.5 overflow-x-auto pb-1 lg:pb-0">
            {[
              { id: 'overview', label: 'ড্যাশবোর্ড ওভারভিউ', icon: 'space_dashboard' },
              { id: 'courses', label: 'কোর্স ও ইমেজ ম্যানেজমেন্ট', icon: 'menu_book' },
              { id: 'categories', label: 'ক্যাটাগরি ম্যানেজমেন্ট', icon: 'category' },
              { id: 'analytics', label: 'অ্যাফিলিয়েট ও ক্লিক অ্যানালিটিক্স', icon: 'monitoring' },
              { id: 'messages', label: `কাস্টমার মেসেজ (${inquiries.length})`, icon: 'forum' },
              { id: 'settings', label: 'সাইট ও হিরো সেটিংস', icon: 'settings' },
            ].map((item) => (
              <button
                key={item.id}
                type="button"
                onClick={() => setActiveTab(item.id as AdminTab)}
                className={`flex items-center gap-2.5 px-3.5 py-2.5 rounded-xl text-xs font-bold transition whitespace-nowrap cursor-pointer ${
                  activeTab === item.id || (activeTab === 'course_editor' && item.id === 'courses')
                    ? 'bg-red-600 text-white'
                    : 'text-slate-400 hover:bg-slate-900 hover:text-white'
                }`}
              >
                <span className="material-symbols-outlined text-[18px]">{item.icon}</span>
                <span>{item.label}</span>
              </button>
            ))}
          </nav>
        </div>

        <div className="hidden lg:block p-5 border-t border-slate-800/80 space-y-3">
          <div className="text-xs">
            <div className="font-bold text-white truncate">{adminName}</div>
            <div className="text-[11px] text-slate-400 truncate">{adminEmail}</div>
          </div>
          <button
            type="button"
            onClick={onLogout}
            className="w-full py-2 px-3 rounded-lg bg-slate-900 hover:bg-slate-800 text-slate-300 text-xs font-semibold flex items-center justify-center gap-1.5 transition cursor-pointer"
          >
            <span className="material-symbols-outlined text-[16px]">logout</span>
            <span>লগআউট করুন</span>
          </button>
        </div>
      </aside>

      {/* MAIN WORKSPACE VIEWPORT */}
      <div className="flex-1 flex flex-col min-w-0">
        {/* Top Bar Contract: Breadcrumb Left — Primary Actions Right */}
        <header className="bg-white border-b border-slate-200 px-6 py-4 flex flex-wrap items-center justify-between gap-4">
          <div className="flex items-center gap-2 text-xs text-slate-500 font-medium">
            <span>Admin</span>
            <span aria-hidden="true">/</span>
            <span className="font-bold text-slate-900 capitalize">{activeTab}</span>
          </div>

          <div className="flex items-center gap-2.5">
            {onDownloadZip && (
              <button
                type="button"
                onClick={onDownloadZip}
                className="px-3.5 py-2 rounded-xl bg-slate-900 hover:bg-slate-800 text-white text-xs font-bold flex items-center gap-1.5 transition cursor-pointer whitespace-nowrap shadow-xs"
                title="সম্পূর্ণ প্রজেক্ট সোর্স কোড ZIP ডাউনলোড করুন"
              >
                <span className="material-symbols-outlined text-[16px] text-emerald-400">download</span>
                <span>প্রজেক্ট ZIP এক্সপোর্ট</span>
              </button>
            )}

            <button
              type="button"
              onClick={onViewPublicSite}
              className="px-3.5 py-2 rounded-xl border border-slate-200 hover:bg-slate-100 text-slate-700 text-xs font-bold flex items-center gap-1.5 transition cursor-pointer whitespace-nowrap"
            >
              <span className="material-symbols-outlined text-[16px]">visibility</span>
              <span>পাবলিক ওয়েবসাইট দেখুন</span>
            </button>

            <button
              type="button"
              onClick={() => {
                setEditingCourse(null);
                setActiveTab('course_editor');
              }}
              className="px-4 py-2 rounded-xl bg-red-600 hover:bg-red-700 text-white text-xs font-bold flex items-center gap-1.5 transition cursor-pointer whitespace-nowrap"
            >
              <span className="material-symbols-outlined text-[16px]">add</span>
              <span>নতুন কোর্স যোগ করুন</span>
            </button>
          </div>
        </header>

        {/* Main Body */}
        <main className="p-6 max-w-7xl w-full mx-auto space-y-6">
          {error && (
            <div className="p-4 rounded-xl bg-red-50 border border-red-200 text-xs font-bold text-red-700 flex items-center justify-between">
              <span>{error}</span>
              <button
                type="button"
                onClick={fetchOverview}
                className="underline cursor-pointer"
              >
                আবার চেষ্টা করুন
              </button>
            </div>
          )}

          {loading ? (
            <div className="grid grid-cols-1 sm:grid-cols-4 gap-4">
              {[1, 2, 3, 4].map((n) => (
                <div
                  key={n}
                  className="h-28 rounded-xl bg-white border border-slate-200 p-5 animate-pulse"
                />
              ))}
            </div>
          ) : (
            <>
              {/* ================================================= */}
              {/* TAB 1: DASHBOARD OVERVIEW                         */}
              {/* ================================================= */}
              {activeTab === 'overview' && (
                <div className="space-y-6">
                  {/* Quick Offer Timer Banner */}
                  <div className="bg-gradient-to-r from-slate-900 via-slate-800 to-slate-900 text-white rounded-xl p-4 border border-slate-700 shadow-md flex flex-col md:flex-row items-center justify-between gap-3">
                    <div className="flex items-center gap-3">
                      <div className={`w-10 h-10 rounded-full flex items-center justify-center shrink-0 ${showCountdownTimer ? 'bg-red-500/20 text-red-400' : 'bg-slate-700 text-slate-400'}`}>
                        <span className="material-symbols-outlined text-[22px]">alarm</span>
                      </div>
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="text-xs font-bold text-slate-300">হোমপেজ অফার কাউন্টডাউন টাইমার:</span>
                          <span className={`text-[10px] font-extrabold px-2 py-0.5 rounded-full ${showCountdownTimer ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30' : 'bg-slate-700 text-slate-400'}`}>
                            {showCountdownTimer ? '🟢 বর্তমানে চালু আছে (ON)' : '⚪ বর্তমানে বন্ধ আছে (OFF)'}
                          </span>
                        </div>
                        <p className="text-xs text-white font-medium line-clamp-1 mt-0.5">
                          {countdownLabel || 'HSC ২৮ আর্লি বার্ড স্পেশাল উপহার সহ ছাড়ে বাকি:'}
                        </p>
                      </div>
                    </div>

                    <div className="flex items-center gap-2 shrink-0">
                      <button
                        type="button"
                        onClick={() => handleToggleTimerQuick(!showCountdownTimer)}
                        className={`px-3 py-1.5 rounded-lg text-xs font-bold transition cursor-pointer flex items-center gap-1.5 ${
                          showCountdownTimer
                            ? 'bg-red-600/30 hover:bg-red-600/50 text-red-200 border border-red-500/40'
                            : 'bg-emerald-600 hover:bg-emerald-500 text-white shadow-xs'
                        }`}
                      >
                        <span>{showCountdownTimer ? 'টাইমার বন্ধ করুন' : 'টাইমার চালু করুন'}</span>
                      </button>

                      <button
                        type="button"
                        onClick={() => setActiveTab('settings')}
                        className="px-3 py-1.5 rounded-lg bg-slate-700 hover:bg-slate-600 text-slate-200 text-xs font-bold transition cursor-pointer"
                      >
                        কাস্টমাইজ করুন
                      </button>
                    </div>
                  </div>

                  {/* Quick WhatsApp Support Number Banner */}
                  <div className="bg-gradient-to-r from-emerald-950 via-slate-900 to-emerald-950 text-white rounded-xl p-4 border border-emerald-800/60 shadow-md flex flex-col md:flex-row items-center justify-between gap-3">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center shrink-0">
                        <svg className="w-6 h-6 fill-current" viewBox="0 0 24 24">
                          <path d="M12.04 2c-5.46 0-9.91 4.45-9.91 9.91 0 1.75.46 3.45 1.32 4.95L2.05 22l5.25-1.38c1.45.79 3.08 1.21 4.74 1.21 5.46 0 9.91-4.45 9.91-9.91 0-2.65-1.03-5.14-2.9-7.01A9.816 9.816 0 0012.04 2zm5.78 14.15c-.24.67-1.39 1.28-1.92 1.36-.5.08-1.14.12-3.66-.92-3.22-1.33-5.3-4.57-5.46-4.78-.16-.21-1.3-1.73-1.3-3.3 0-1.57.82-2.34 1.11-2.66.29-.32.64-.4.85-.4.21 0 .43.002.61.01.2.008.47-.076.73.55.27.64.91 2.22.99 2.38.08.16.13.35.03.56-.1.21-.16.34-.31.52-.16.18-.33.4-.47.54-.16.15-.32.32-.14.63.19.31.83 1.37 1.78 2.22 1.22 1.09 2.25 1.42 2.57 1.58.32.16.51.13.7-.08.19-.21.82-.95 1.04-1.28.22-.32.43-.27.73-.16.29.11 1.87.88 2.19 1.04.32.16.53.24.61.37.08.14.08.79-.16 1.46z" />
                        </svg>
                      </div>
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="text-xs font-bold text-slate-300">হোয়াটসঅ্যাপ সাপোর্ট নম্বর:</span>
                          <span className="text-sm font-black text-emerald-400 font-mono tracking-wide">
                            {whatsappNumber || 'নম্বর সেট করা নেই'}
                          </span>
                        </div>
                        <p className="text-[11px] text-slate-400 mt-0.5">
                          ওয়েবসাইটের সকল হোয়াটসঅ্যাপ বাটন ও চ্যাট পপআপে এই নম্বরে সরাসরি মেসেজ যাবে।
                        </p>
                      </div>
                    </div>

                    <div className="flex items-center gap-2 shrink-0">
                      <button
                        type="button"
                        onClick={() => {
                          setActiveTab('settings');
                          setTimeout(() => {
                            document.getElementById('whatsapp-settings-card')?.scrollIntoView({ behavior: 'smooth' });
                          }, 100);
                        }}
                        className="px-4 py-2 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold transition cursor-pointer flex items-center gap-1.5 shadow-sm"
                      >
                        <span className="material-symbols-outlined text-[16px]">edit</span>
                        <span>নম্বর পরিবর্তন করুন</span>
                      </button>
                    </div>
                  </div>

                  {/* KPI Stat Cards */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 tabular-nums">
                    <div className="bg-white rounded-xl border border-slate-200 p-5">
                      <span className="text-xs font-semibold text-slate-500">
                        মোট কোর্স (Total Courses)
                      </span>
                      <div className="text-3xl font-extrabold text-slate-900 mt-2">
                        {toBengaliNumber(stats.totalCourses)}
                      </div>
                      <span className="text-[11px] text-slate-400 mt-1 block">
                        {toBengaliNumber(stats.totalCategories)}টি ক্যাটাগরিতে বিভক্ত
                      </span>
                    </div>

                    <div className="bg-white rounded-xl border border-slate-200 p-5">
                      <span className="text-xs font-semibold text-slate-500">
                        চালু কোর্স (Active Courses)
                      </span>
                      <div className="text-3xl font-extrabold text-emerald-600 mt-2">
                        {toBengaliNumber(stats.activeCourses)}
                      </div>
                      <span className="text-[11px] text-emerald-700 font-medium mt-1 block">
                        ● পাবলিক ওয়েবসাইটে দৃশ্যমান
                      </span>
                    </div>

                    <div className="bg-white rounded-xl border border-slate-200 p-5">
                      <span className="text-xs font-semibold text-slate-500">
                        বন্ধ কোর্স (Inactive / Disabled)
                      </span>
                      <div className="text-3xl font-extrabold text-amber-600 mt-2">
                        {toBengaliNumber(stats.inactiveCourses)}
                      </div>
                      <span className="text-[11px] text-slate-400 mt-1 block">
                        পাবলিক ওয়েবসাইটে লুকানো
                      </span>
                    </div>

                    <div className="bg-white rounded-xl border border-slate-200 p-5">
                      <span className="text-xs font-semibold text-slate-500">
                        মোট অ্যাফিলিয়েট ক্লিক (Total Clicks)
                      </span>
                      <div className="text-3xl font-extrabold text-blue-600 mt-2">
                        {toBengaliNumber(stats.totalClicks)}
                      </div>
                      <span className="text-[11px] text-blue-600 font-medium mt-1 block">
                        10 Minute School রিডাইরেক্ট কাউন্ট
                      </span>
                    </div>
                  </div>

                  {/* Popular Courses & Recent Clicks Split */}
                  <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
                    {/* Top Clicked Courses */}
                    <div className="lg:col-span-7 bg-white rounded-xl border border-slate-200 p-5 space-y-4">
                      <div className="flex items-center justify-between">
                        <div>
                          <h3 className="text-base font-extrabold text-slate-900">
                            জনপ্রিয় কোর্স ও ক্লিক পারফরম্যান্স
                          </h3>
                          <p className="text-xs text-slate-500">
                            কোন কোর্সে সবচেয়ে বেশি শিক্ষার্থী “কোর্সে ভর্তি হোন” চাপছে
                          </p>
                        </div>
                        <button
                          type="button"
                          onClick={() => setActiveTab('courses')}
                          className="text-xs font-bold text-blue-600 hover:text-blue-700 cursor-pointer"
                        >
                          সব কোর্স ম্যানেজ করুন →
                        </button>
                      </div>

                      <div className="space-y-3 tabular-nums">
                        {courses.slice(0, 6).map((c) => {
                          const pct = Math.round(((c.clickCount || 0) / maxClicks) * 100);
                          return (
                            <div key={c.id} className="space-y-1.5">
                              <div className="flex items-center justify-between text-xs">
                                <span className="font-bold text-slate-800 truncate max-w-md">
                                  {c.title}
                                </span>
                                <span className="font-mono font-bold text-slate-900">
                                  {toBengaliNumber(c.clickCount || 0)} clicks
                                </span>
                              </div>
                              <div className="w-full h-2 rounded-full bg-slate-100 overflow-hidden">
                                <div
                                  className="h-full bg-red-600 rounded-full"
                                  style={{ width: `${Math.max(4, pct)}%` }}
                                />
                              </div>
                            </div>
                          );
                        })}
                      </div>
                    </div>

                    {/* Recent Clicks Feed */}
                    <div className="lg:col-span-5 bg-white rounded-xl border border-slate-200 p-5 space-y-4">
                      <div>
                        <h3 className="text-base font-extrabold text-slate-900">
                          সাম্প্রতিক অ্যাফিলিয়েট ক্লিক লগ
                        </h3>
                        <p className="text-xs text-slate-500">
                          লাইভ ইউজার এনরোলমেন্ট রিডাইরেক্ট রেকর্ড
                        </p>
                      </div>

                      <div className="divide-y divide-slate-100 max-h-80 overflow-y-auto tabular-nums">
                        {recentClicks.length === 0 ? (
                          <div className="py-8 text-center text-xs text-slate-400">
                            এখনো কোনো ক্লিক রেকর্ড হয়নি।
                          </div>
                        ) : (
                          recentClicks.slice(0, 10).map((clk) => (
                            <div
                              key={clk.id}
                              className="py-2.5 flex items-center justify-between gap-3 text-xs"
                            >
                              <div className="min-w-0">
                                <div className="font-bold text-slate-800 truncate">
                                  {clk.courseTitle}
                                </div>
                                <div className="text-[11px] text-slate-400">
                                  Source: {clk.referrer || 'direct'} · /go/{clk.courseSlug}
                                </div>
                              </div>
                              <span className="text-[11px] font-mono text-emerald-700 shrink-0">
                                Redirected ↗
                              </span>
                            </div>
                          ))
                        )}
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {/* ================================================= */}
              {/* TAB 2: COURSE & IMAGE MANAGEMENT                  */}
              {/* ================================================= */}
              {activeTab === 'courses' && (
                <div className="space-y-4">
                  {/* Search & Filter Bar */}
                  <div className="bg-white rounded-xl border border-slate-200 p-4 flex flex-col sm:flex-row items-center justify-between gap-3">
                    <div className="flex items-center gap-2 w-full sm:w-auto flex-1">
                      <span className="material-symbols-outlined text-[20px] text-slate-400">
                        search
                      </span>
                      <input
                        type="text"
                        value={searchQuery}
                        onChange={(e) => setSearchQuery(e.target.value)}
                        placeholder="কোর্সের নাম বা slug লিখে খুঁজুন..."
                        className="w-full text-xs sm:text-sm outline-none text-slate-800"
                      />
                    </div>

                    <div className="flex items-center gap-2 w-full sm:w-auto justify-end">
                      <select
                        value={filterCat}
                        onChange={(e) => setFilterCat(e.target.value)}
                        className="px-3 py-2 rounded-lg border border-slate-200 text-xs font-bold text-slate-700 bg-slate-50"
                      >
                        <option value="all">সকল ক্যাটাগরি ({courses.length})</option>
                        {categories.map((cat) => (
                          <option key={cat.slug} value={cat.slug}>
                            {cat.name}
                          </option>
                        ))}
                      </select>

                      <button
                        type="button"
                        onClick={() => {
                          setEditingCourse(null);
                          setActiveTab('course_editor');
                        }}
                        className="px-4 py-2 rounded-lg bg-red-600 hover:bg-red-700 text-white text-xs font-bold whitespace-nowrap cursor-pointer"
                      >
                        + Add New Course
                      </button>
                    </div>
                  </div>

                  {/* Courses Table */}
                  <div className="bg-white rounded-xl border border-slate-200 overflow-hidden">
                    <div className="overflow-x-auto">
                      <table className="w-full text-left border-collapse">
                        <thead>
                          <tr className="border-b border-slate-200 bg-slate-50 text-[11px] font-extrabold text-slate-600 uppercase">
                            <th className="py-3 px-4">কোর্স ইমেজ / ব্যানার</th>
                            <th className="py-3 px-4">কোর্সের নাম ও ক্যাটাগরি</th>
                            <th className="py-3 px-4 text-right">ডিসকাউন্ট মূল্য</th>
                            <th className="py-3 px-4 text-right">ক্লিক সংখ্যা</th>
                            <th className="py-3 px-4 text-center">স্ট্যাটাস (Enable/Disable)</th>
                            <th className="py-3 px-4 text-right">অ্যাকশন</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-slate-200 text-xs tabular-nums">
                          {filteredCourses.map((c) => {
                            const grad = getGradientClasses(c.gradientTheme);
                            return (
                              <tr key={c.id} className="hover:bg-slate-50/80 transition">
                                <td className="py-3 px-4">
                                  <div
                                    onClick={() => {
                                      setEditingCourse(c);
                                      setActiveTab('course_editor');
                                    }}
                                    className={`w-28 h-16 rounded-lg overflow-hidden relative ${grad.bg} text-white p-2 flex items-end cursor-pointer group`}
                                    title="ইমেজ পরিবর্তন করতে ক্লিক করুন"
                                  >
                                    {c.imageUrl && (
                                      <img
                                        src={c.imageUrl}
                                        alt={c.title}
                                        referrerPolicy="no-referrer"
                                        className="absolute inset-0 w-full h-full object-cover object-center"
                                      />
                                    )}
                                    <div className="absolute inset-0 bg-black/35 group-hover:bg-black/55 transition flex items-center justify-center">
                                      <span className="text-[10px] font-bold text-white bg-black/50 px-1.5 py-0.5 rounded">
                                        {c.imageUrl ? ' ইমেজ এডিট' : 'ডিফল্ট ব্যানার'}
                                      </span>
                                    </div>
                                  </div>
                                </td>

                                <td className="py-3 px-4 max-w-xs">
                                  <div className="font-bold text-slate-900 line-clamp-1">
                                    {c.title}
                                  </div>
                                  <div className="text-[11px] text-slate-500 mt-0.5 font-mono">
                                    /go/{c.slug} · <span className="font-sans font-semibold text-blue-600">{c.categorySlug.toUpperCase()}</span>
                                  </div>
                                </td>

                                <td className="py-3 px-4 text-right whitespace-nowrap">
                                  <div className="font-extrabold text-emerald-600 text-sm">
                                    ৳{toBengaliNumber(c.discountPrice)}
                                  </div>
                                  <div className="text-[11px] text-slate-400">
                                    <span className="line-through">
                                      ৳{toBengaliNumber(c.originalPrice)}
                                    </span>{' '}
                                    ({toBengaliNumber(c.discountPercent)}% ছাড়)
                                  </div>
                                </td>

                                <td className="py-3 px-4 text-right font-mono font-bold text-slate-800">
                                  {toBengaliNumber(c.clickCount || 0)}
                                </td>

                                <td className="py-3 px-4 text-center">
                                  <button
                                    type="button"
                                    onClick={() => handleToggleCourseStatus(c)}
                                    className={`px-3 py-1 rounded-lg text-[11px] font-bold cursor-pointer transition ${
                                      c.status === 'active'
                                        ? 'bg-emerald-50 text-emerald-700 border border-emerald-200 hover:bg-emerald-100'
                                        : 'bg-slate-100 text-slate-600 border border-slate-300 hover:bg-slate-200'
                                    }`}
                                  >
                                    {c.status === 'active' ? '● Active (চালু)' : '○ Disabled (বন্ধ)'}
                                  </button>
                                </td>

                                <td className="py-3 px-4 text-right whitespace-nowrap">
                                  {confirmDeleteCourseId === c.id ? (
                                    <div className="inline-flex items-center gap-1.5">
                                      <button
                                        type="button"
                                        onClick={() => handleDeleteCourse(c.id)}
                                        className="px-2.5 py-1 rounded bg-red-600 text-white text-[11px] font-bold cursor-pointer"
                                      >
                                        নিশ্চিত ডিলিট
                                      </button>
                                      <button
                                        type="button"
                                        onClick={() => setConfirmDeleteCourseId(null)}
                                        className="px-2 py-1 rounded border border-slate-300 text-slate-600 text-[11px] cursor-pointer"
                                      >
                                        না
                                      </button>
                                    </div>
                                  ) : (
                                    <div className="inline-flex items-center gap-2">
                                      <button
                                        type="button"
                                        onClick={() => {
                                          setEditingCourse(c);
                                          setActiveTab('course_editor');
                                        }}
                                        className="px-3 py-1.5 rounded-lg bg-blue-50 hover:bg-blue-100 text-blue-700 font-bold text-xs cursor-pointer"
                                      >
                                        Edit / Image
                                      </button>
                                      <button
                                        type="button"
                                        onClick={() => setConfirmDeleteCourseId(c.id)}
                                        className="px-2.5 py-1.5 rounded-lg bg-red-50 hover:bg-red-100 text-red-600 font-bold text-xs cursor-pointer"
                                      >
                                        Delete
                                      </button>
                                    </div>
                                  )}
                                </td>
                              </tr>
                            );
                          })}
                        </tbody>
                      </table>
                    </div>
                  </div>
                </div>
              )}

              {/* ================================================= */}
              {/* TAB: DEDICATED COURSE EDITOR PAGE (FULL VIEW)     */}
              {/* ================================================= */}
              {activeTab === 'course_editor' && (
                <CourseEditorPage
                  course={editingCourse}
                  categories={categories}
                  onBackToList={() => setActiveTab('courses')}
                  onSave={handleSaveCourse}
                />
              )}

              {/* ================================================= */}
              {/* TAB 3: CATEGORY MANAGEMENT                        */}
              {/* ================================================= */}
              {activeTab === 'categories' && (
                <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
                  {/* Category Form */}
                  <div className="lg:col-span-5 bg-white rounded-xl border border-slate-200 p-5 space-y-4 h-fit">
                    <h3 className="text-base font-extrabold text-slate-900">
                      {editingCat ? 'ক্যাটাগরি এডিট করুন' : '+ নতুন ক্যাটাগরি যোগ করুন'}
                    </h3>
                    <form onSubmit={handleSaveCategory} className="space-y-3.5">
                      <div>
                        <label className="block text-xs font-bold text-slate-700 mb-1">
                          ক্যাটাগরির নাম (Section Title) *
                        </label>
                        <input
                          type="text"
                          required
                          value={catName}
                          onChange={(e) => setCatName(e.target.value)}
                          placeholder="যেমন: IELTS ও ভাষা শিক্ষা"
                          className="w-full px-3 py-2 rounded-xl border border-slate-300 text-xs"
                        />
                      </div>
                      <div>
                        <label className="block text-xs font-bold text-slate-700 mb-1">
                          ক্যাটাগরি Slug (ইংরেজি ছোট হাতের) *
                        </label>
                        <input
                          type="text"
                          required
                          value={catSlug}
                          onChange={(e) => setCatSlug(e.target.value)}
                          placeholder="যেমন: ielts"
                          className="w-full px-3 py-2 rounded-xl border border-slate-300 text-xs font-mono"
                        />
                      </div>
                      <div>
                        <label className="block text-xs font-bold text-slate-700 mb-1">
                          সাবটাইটেল (Section Kicker)
                        </label>
                        <input
                          type="text"
                          value={catSubtitle}
                          onChange={(e) => setCatSubtitle(e.target.value)}
                          placeholder="যেমন: উচ্চশিক্ষা ও ক্যারিয়ার"
                          className="w-full px-3 py-2 rounded-xl border border-slate-300 text-xs"
                        />
                      </div>
                      <div className="grid grid-cols-2 gap-3">
                        <div>
                          <label className="block text-xs font-bold text-slate-700 mb-1">
                            কালার থিম
                          </label>
                          <select
                            value={catColor}
                            onChange={(e) => setCatColor(e.target.value)}
                            className="w-full px-3 py-2 rounded-xl border border-slate-300 text-xs bg-white"
                          >
                            <option value="red">Red</option>
                            <option value="blue">Blue</option>
                            <option value="indigo">Indigo</option>
                            <option value="rose">Rose</option>
                            <option value="emerald">Emerald</option>
                          </select>
                        </div>
                        <div>
                          <label className="block text-xs font-bold text-slate-700 mb-1">
                            ক্রম (Display Order)
                          </label>
                          <input
                            type="number"
                            value={catOrder}
                            onChange={(e) => setCatOrder(Number(e.target.value))}
                            className="w-full px-3 py-2 rounded-xl border border-slate-300 text-xs"
                          />
                        </div>
                      </div>

                      <div className="flex items-center gap-2 pt-2">
                        <button
                          type="submit"
                          className="flex-1 py-2.5 px-4 rounded-xl bg-red-600 hover:bg-red-700 text-white text-xs font-bold cursor-pointer"
                        >
                          {editingCat ? 'ক্যাটাগরি আপডেট করুন' : 'ক্যাটাগরি সেভ করুন'}
                        </button>
                        {editingCat && (
                          <button
                            type="button"
                            onClick={() => {
                              setEditingCat(null);
                              setCatName('');
                              setCatSlug('');
                              setCatSubtitle('');
                            }}
                            className="py-2.5 px-3 rounded-xl border border-slate-300 text-xs font-bold text-slate-600 cursor-pointer"
                          >
                            বাতিল
                          </button>
                        )}
                      </div>
                    </form>
                  </div>

                  {/* Category List */}
                  <div className="lg:col-span-7 bg-white rounded-xl border border-slate-200 overflow-hidden">
                    <table className="w-full text-left border-collapse">
                      <thead>
                        <tr className="border-b border-slate-200 bg-slate-50 text-[11px] font-extrabold text-slate-600 uppercase">
                          <th className="py-3 px-4">ক্যাটাগরি নাম</th>
                          <th className="py-3 px-4">Slug</th>
                          <th className="py-3 px-4 text-center">স্ট্যাটাস</th>
                          <th className="py-3 px-4 text-right">অ্যাকশন</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-200 text-xs">
                        {categories.map((cat) => (
                          <tr key={cat.id} className="hover:bg-slate-50">
                            <td className="py-3 px-4">
                              <div className="font-bold text-slate-900">{cat.name}</div>
                              <div className="text-[11px] text-slate-400">{cat.subtitle}</div>
                            </td>
                            <td className="py-3 px-4 font-mono text-slate-600">{cat.slug}</td>
                            <td className="py-3 px-4 text-center">
                              <button
                                type="button"
                                onClick={() => handleToggleCategoryStatus(cat)}
                                className={`px-2.5 py-1 rounded text-[11px] font-bold cursor-pointer ${
                                  cat.status === 'active'
                                    ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                                    : 'bg-slate-100 text-slate-500 border border-slate-200'
                                }`}
                              >
                                {cat.status === 'active' ? 'Active' : 'Disabled'}
                              </button>
                            </td>
                            <td className="py-3 px-4 text-right space-x-2">
                              <button
                                type="button"
                                onClick={() => {
                                  setEditingCat(cat);
                                  setCatName(cat.name);
                                  setCatSlug(cat.slug);
                                  setCatSubtitle(cat.subtitle || '');
                                  setCatColor(cat.badgeColor);
                                  setCatOrder(cat.displayOrder);
                                }}
                                className="text-blue-600 font-bold hover:underline cursor-pointer"
                              >
                                Edit
                              </button>
                              {confirmDeleteCatId === cat.id ? (
                                <button
                                  type="button"
                                  onClick={() => handleDeleteCategory(cat.id)}
                                  className="text-red-600 font-bold underline cursor-pointer"
                                >
                                  Confirm?
                                </button>
                              ) : (
                                <button
                                  type="button"
                                  onClick={() => setConfirmDeleteCatId(cat.id)}
                                  className="text-red-600 font-bold hover:underline cursor-pointer"
                                >
                                  Delete
                                </button>
                              )}
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              )}

              {/* ================================================= */}
              {/* TAB 4: AFFILIATE LINKS & CLICK ANALYTICS          */}
              {/* ================================================= */}
              {activeTab === 'analytics' && (
                <div className="space-y-6">
                  <div className="bg-white rounded-xl border border-slate-200 p-5 space-y-4">
                    <div>
                      <h3 className="text-base font-extrabold text-slate-900">
                        ইন্টারনাল অ্যাফিলিয়েট রিডাইরেক্ট সিস্টেম (/go/course-slug) ও ক্লিক রিপোর্ট
                      </h3>
                      <p className="text-xs text-slate-500">
                        যেকোনো সোশ্যাল মিডিয়া, ফেসবুক পোস্ট বা হোয়াটসঅ্যাপে আপনার ইন্টারনাল ট্র্যাকিং লিংক শেয়ার করলে ক্লিক রেকর্ড হয়ে সরাসরি 10 Minute School-এ রিডাইরেক্ট হবে।
                      </p>
                    </div>

                    <div className="overflow-x-auto">
                      <table className="w-full text-left border-collapse">
                        <thead>
                          <tr className="border-b border-slate-200 bg-slate-50 text-[11px] font-extrabold text-slate-600 uppercase">
                            <th className="py-3 px-4">কোর্সের নাম</th>
                            <th className="py-3 px-4">ইন্টারনাল রিডাইরেক্ট লিংক</th>
                            <th className="py-3 px-4">টার্গেট 10MS Affiliate URL</th>
                            <th className="py-3 px-4 text-right">মোট ক্লিক</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-slate-200 text-xs tabular-nums">
                          {courses.map((c) => {
                            const goUrl = `${window.location.origin}/go/${c.slug}`;
                            return (
                              <tr key={c.id} className="hover:bg-slate-50">
                                <td className="py-3 px-4 font-bold text-slate-900 max-w-xs truncate">
                                  {c.title}
                                </td>
                                <td className="py-3 px-4">
                                  <div className="flex items-center gap-2">
                                    <code className="font-mono text-[11px] bg-slate-100 px-2 py-1 rounded text-slate-800">
                                      /go/{c.slug}
                                    </code>
                                    <button
                                      type="button"
                                      onClick={() => {
                                        navigator.clipboard.writeText(goUrl);
                                        setCopiedSlug(c.slug);
                                        setTimeout(() => setCopiedSlug(null), 2000);
                                      }}
                                      className="text-[11px] font-bold text-blue-600 hover:underline cursor-pointer"
                                    >
                                      {copiedSlug === c.slug ? 'কপি হয়েছে ✓' : 'Copy'}
                                    </button>
                                  </div>
                                </td>
                                <td className="py-3 px-4 max-w-xs truncate font-mono text-[11px] text-slate-500">
                                  <a
                                    href={c.affiliateUrl}
                                    target="_blank"
                                    rel="noreferrer"
                                    className="hover:text-blue-600 underline"
                                  >
                                    {c.affiliateUrl}
                                  </a>
                                </td>
                                <td className="py-3 px-4 text-right font-mono font-extrabold text-emerald-700">
                                  {toBengaliNumber(c.clickCount || 0)} clicks
                                </td>
                              </tr>
                            );
                          })}
                        </tbody>
                      </table>
                    </div>
                  </div>
                </div>
              )}

              {/* ================================================= */}
              {/* TAB: CUSTOMER INQUIRIES & MESSAGES                */}
              {/* ================================================= */}
              {activeTab === 'messages' && (
                <div className="space-y-6">
                  <div className="bg-white rounded-xl border border-slate-200 p-5 space-y-4">
                    <div className="flex items-center justify-between">
                      <div>
                        <h3 className="text-base font-extrabold text-slate-900">
                          কাস্টমার মেসেজ ও কোর্স সহায়তা ইনবক্স ({toBengaliNumber(inquiries.length)})
                        </h3>
                        <p className="text-xs text-slate-500">
                          ফ্লোটিং মেসেজ উইজেট থেকে শিক্ষার্থীদের পাঠানো প্রশ্ন ও যোগাযোগের তথ্য।
                        </p>
                      </div>
                    </div>

                    {inquiries.length === 0 ? (
                      <div className="p-10 text-center text-slate-400 space-y-2">
                        <span className="material-symbols-outlined text-4xl">mark_chat_read</span>
                        <p className="text-xs font-semibold text-slate-500">
                          বর্তমানে কোনো কাস্টমার ইনকোয়ারি নেই।
                        </p>
                      </div>
                    ) : (
                      <div className="overflow-x-auto">
                        <table className="w-full text-left border-collapse">
                          <thead>
                            <tr className="border-b border-slate-200 bg-slate-50 text-[11px] font-extrabold text-slate-600 uppercase">
                              <th className="py-3 px-4">তারিখ ও সময়</th>
                              <th className="py-3 px-4">শিক্ষার্থীর নাম</th>
                              <th className="py-3 px-4">ফোন / হোয়াটসঅ্যাপ</th>
                              <th className="py-3 px-4">আগ্রহী কোর্স</th>
                              <th className="py-3 px-4">বার্তা / প্রশ্ন</th>
                              <th className="py-3 px-4 text-right">অ্যাকশন</th>
                            </tr>
                          </thead>
                          <tbody className="divide-y divide-slate-200 text-xs">
                            {inquiries.map((inq) => (
                              <tr key={inq.id} className="hover:bg-slate-50">
                                <td className="py-3 px-4 text-slate-500 text-[11px] whitespace-nowrap">
                                  {new Date(inq.createdAt).toLocaleDateString('bn-BD', {
                                    day: 'numeric',
                                    month: 'short',
                                    hour: '2-digit',
                                    minute: '2-digit',
                                  })}
                                </td>
                                <td className="py-3 px-4 font-bold text-slate-900 whitespace-nowrap">
                                  {inq.name}
                                </td>
                                <td className="py-3 px-4 whitespace-nowrap">
                                  <a
                                    href={`https://wa.me/${inq.phoneOrEmail.replace(/[^0-9]/g, '')}`}
                                    target="_blank"
                                    rel="noreferrer"
                                    className="text-emerald-700 font-bold hover:underline"
                                  >
                                    {inq.phoneOrEmail}
                                  </a>
                                </td>
                                <td className="py-3 px-4 font-medium text-slate-700">
                                  {inq.courseTitle || 'সাধারণ তথ্য'}
                                </td>
                                <td className="py-3 px-4 text-slate-800 max-w-sm">
                                  {inq.message}
                                </td>
                                <td className="py-3 px-4 text-right whitespace-nowrap">
                                  <button
                                    type="button"
                                    onClick={() => handleDeleteInquiry(inq.id)}
                                    className="p-1.5 rounded-lg text-slate-400 hover:text-red-600 hover:bg-red-50 transition cursor-pointer"
                                    title="মুছে ফেলুন"
                                  >
                                    <span className="material-symbols-outlined text-[17px]">delete</span>
                                  </button>
                                </td>
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>
                    )}
                  </div>
                </div>
              )}

              {/* ================================================= */}
              {/* TAB 5: SITE & HERO SETTINGS                       */}
              {/* ================================================= */}
              {activeTab === 'settings' && (
                <div className="max-w-3xl space-y-6">
                  {/* DEDICATED COUNTDOWN TIMER CONTROL SYSTEM CARD */}
                  <div className="bg-white rounded-xl border-2 border-red-500/30 p-6 space-y-5 shadow-sm">
                    <div className="flex items-center justify-between border-b border-slate-100 pb-4">
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 rounded-xl bg-red-50 border border-red-200 flex items-center justify-center text-red-600 shrink-0">
                          <span className="material-symbols-outlined text-[24px]">alarm_on</span>
                        </div>
                        <div>
                          <h3 className="text-base font-extrabold text-slate-900">
                            ⏱️ অফার কাউন্টডাউন টাইমার সিস্টেম কন্ট্রোল
                          </h3>
                          <p className="text-xs text-slate-500">
                            যেকোনো নির্দিষ্ট কোর্স বা সাধারণ অফারের জন্য হোমপেজের টাইমার চালু (ON) বা বন্ধ (OFF) করুন।
                          </p>
                        </div>
                      </div>

                      <span className={`text-[11px] font-extrabold px-3 py-1 rounded-full border ${
                        showCountdownTimer
                          ? 'bg-emerald-50 text-emerald-700 border-emerald-300'
                          : 'bg-slate-100 text-slate-600 border-slate-300'
                      }`}>
                        {showCountdownTimer ? '🟢 স্ট্যাটাস: চালু (ON)' : '⚪ স্ট্যাটাস: বন্ধ (OFF)'}
                      </span>
                    </div>

                    {/* Master ON / OFF Toggle Switch */}
                    <div className="flex items-center justify-between p-4 bg-slate-50 border border-slate-200 rounded-xl">
                      <div>
                        <span className="font-extrabold text-xs sm:text-sm text-slate-900 block">
                          টাইমার ভিজিবিলিটি (ON / OFF)
                        </span>
                        <span className="text-[11px] sm:text-xs text-slate-500">
                          {showCountdownTimer
                            ? 'হোমপেজে টাইমার দৃশ্যমান ও লাইভ কাউন্টডাউন চলছে'
                            : 'হোমপেজ থেকে টাইমার সম্পূর্ণ বন্ধ ও লুকানো আছে'}
                        </span>
                      </div>
                      <button
                        type="button"
                        onClick={() => setShowCountdownTimer(!showCountdownTimer)}
                        className={`px-4 py-2 rounded-xl text-xs font-extrabold flex items-center gap-2 cursor-pointer transition shadow-xs ${
                          showCountdownTimer
                            ? 'bg-emerald-600 hover:bg-emerald-700 text-white'
                            : 'bg-slate-300 hover:bg-slate-400 text-slate-800'
                        }`}
                      >
                        <span className="w-2.5 h-2.5 rounded-full bg-white animate-pulse" />
                        <span>{showCountdownTimer ? 'সক্রিয় (ON)' : 'বন্ধ (OFF)'}</span>
                      </button>
                    </div>

                    {/* Course Selector Dropdown */}
                    <div>
                      <label className="block text-xs font-bold text-slate-700 mb-1">
                        যে কোর্সের জন্য টাইমার প্রযোজ্য (Target Course)
                      </label>
                      <select
                        value={countdownTargetCourse}
                        onChange={(e) => handleCourseSelectionChange(e.target.value)}
                        className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 text-xs bg-white font-medium text-slate-800 focus:outline-none focus:border-red-500"
                      >
                        <option value="all">🌟 সকল কোর্স / সাধারণ অফার (All Courses General)</option>
                        {courses.map((c) => (
                          <option key={c.slug} value={c.slug}>
                            📚 {c.title}
                          </option>
                        ))}
                      </select>
                      <span className="text-[11px] text-slate-400 mt-1 block">
                        যেকোনো কোর্স বেছে নিলে টাইমার লেবেল স্বয়ংক্রিয়ভাবে সেই কোর্সের নামে আপডেট হবে।
                      </span>
                    </div>

                    {/* Countdown Label Input + Quick Presets */}
                    <div>
                      <div className="flex items-center justify-between mb-1">
                        <label className="block text-xs font-bold text-slate-700">
                          কাউন্টডাউন টাইমার হেডিং / অফার বার্তা
                        </label>
                        <span className="text-[11px] text-slate-400">ক্লিক করে প্রিসেট বসান</span>
                      </div>
                      <input
                        type="text"
                        value={countdownLabel}
                        onChange={(e) => setCountdownLabel(e.target.value)}
                        placeholder="যেমন: HSC ২৮ আর্লি বার্ড স্পেশাল উপহার সহ ছাড়ে বাকি:"
                        className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 text-xs font-semibold text-slate-800 focus:outline-none focus:border-red-500"
                      />
                      <div className="flex flex-wrap gap-1.5 mt-2">
                        {[
                          'HSC ২৮ আর্লি বার্ড স্পেশাল উপহার সহ ছাড়ে বাকি:',
                          'HSC ২৭ ফুল সায়েন্স স্পেশাল সাইকেল ছাড়ে বাকি:',
                          '১০ম শ্রেণি SSC ২৭ শেষ মুহূর্তের প্রস্তুতি ছাড়ে বাকি:',
                          'বিশ্ববিদ্যালয় ও মেডিকেল ভর্তি স্পেশাল অফারে বাকি:',
                          'সীমিত সময়ের মেগা ডিসকাউন্ট অফারে বাকি:',
                        ].map((preset) => (
                          <button
                            key={preset}
                            type="button"
                            onClick={() => setCountdownLabel(preset)}
                            className="text-[10px] bg-slate-100 hover:bg-red-50 hover:text-red-600 px-2.5 py-1 rounded-md text-slate-600 border border-slate-200 transition cursor-pointer"
                          >
                            + {preset.split(' ')[0]} {preset.split(' ')[1]}
                          </button>
                        ))}
                      </div>
                    </div>

                    {/* Expiration Target Date & Quick Buttons */}
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      <div>
                        <label className="block text-xs font-bold text-slate-700 mb-1">
                          নির্দিষ্ট অফার শেষ হওয়ার তারিখ ও সময় (ঐচ্ছিক)
                        </label>
                        <input
                          type="datetime-local"
                          value={countdownTargetDate}
                          onChange={(e) => setCountdownTargetDate(e.target.value)}
                          className="w-full px-3.5 py-2 rounded-xl border border-slate-300 text-xs bg-white text-slate-800"
                        />
                      </div>
                      <div>
                        <label className="block text-xs font-bold text-slate-700 mb-1">
                          দ্রুত মেয়াদ নির্ধারণ
                        </label>
                        <div className="flex flex-wrap items-center gap-1.5 pt-0.5">
                          <button
                            type="button"
                            onClick={() => setQuickExpiryDays(1)}
                            className="px-2.5 py-1.5 bg-slate-100 hover:bg-slate-200 rounded-lg text-xs font-semibold text-slate-700 transition cursor-pointer"
                          >
                            +১ দিন
                          </button>
                          <button
                            type="button"
                            onClick={() => setQuickExpiryDays(2)}
                            className="px-2.5 py-1.5 bg-slate-100 hover:bg-slate-200 rounded-lg text-xs font-semibold text-slate-700 transition cursor-pointer"
                          >
                            +২ দিন
                          </button>
                          <button
                            type="button"
                            onClick={() => setQuickExpiryDays(5)}
                            className="px-2.5 py-1.5 bg-slate-100 hover:bg-slate-200 rounded-lg text-xs font-semibold text-slate-700 transition cursor-pointer"
                          >
                            +৫ দিন
                          </button>
                          <button
                            type="button"
                            onClick={() => setCountdownTargetDate('')}
                            className="px-2.5 py-1.5 bg-amber-50 hover:bg-amber-100 text-amber-800 rounded-lg text-xs font-semibold transition cursor-pointer"
                          >
                            অটো চলমান
                          </button>
                        </div>
                      </div>
                    </div>

                    {/* Live Preview of Countdown Banner */}
                    <div className="p-4 bg-slate-900 rounded-xl text-white space-y-2 border border-slate-800">
                      <div className="flex items-center justify-between text-[11px] text-slate-400">
                        <span className="font-bold text-rose-400">হোমপেজ লাইভ প্রিভিউ:</span>
                        <span>{showCountdownTimer ? '🟢 দৃশ্যমান (Active)' : '⚪ লুকানো (Inactive)'}</span>
                      </div>
                      {showCountdownTimer ? (
                        <div className="flex flex-col sm:flex-row items-center justify-between gap-3 bg-black/60 border border-red-500/40 p-3 rounded-lg text-xs">
                          <div className="flex items-center gap-2 text-rose-300 font-bold">
                            <span className="material-symbols-outlined text-red-500 text-[18px] animate-pulse">alarm</span>
                            <span>{countdownLabel || 'HSC ২৮ আর্লি বার্ড স্পেশাল উপহার সহ ছাড়ে বাকি:'}</span>
                          </div>
                          <div className="flex items-center gap-1.5 font-mono text-white text-xs">
                            <span className="bg-slate-800 px-2 py-0.5 rounded font-bold">০২ দিন</span> :
                            <span className="bg-slate-800 px-2 py-0.5 rounded font-bold">০৮ ঘণ্টা</span> :
                            <span className="bg-slate-800 px-2 py-0.5 rounded font-bold">৩৪ মিনিট</span> :
                            <span className="bg-red-950 text-red-400 px-2 py-0.5 rounded font-bold">৪৩ সেকেন্ড</span>
                          </div>
                        </div>
                      ) : (
                        <div className="p-3 bg-slate-800/80 rounded-lg text-xs text-slate-400 text-center font-medium">
                          ⏸️ টাইমার বন্ধ (OFF) রাখা হয়েছে। হোমপেজে এটি প্রদর্শিত হবে না।
                        </div>
                      )}
                    </div>

                    {/* Save Button for Timer */}
                    <div className="pt-2">
                      <button
                        type="button"
                        onClick={() => handleSaveTimerControl()}
                        disabled={savingTimer}
                        className="px-6 py-2.5 rounded-xl bg-gradient-to-r from-red-600 to-rose-600 hover:from-red-500 hover:to-rose-500 text-white text-xs font-bold transition shadow-md cursor-pointer disabled:opacity-50 flex items-center gap-2"
                      >
                        <span className="material-symbols-outlined text-[18px]">save</span>
                        <span>{savingTimer ? 'টাইমার সেভ হচ্ছে...' : 'কাউন্টডাউন টাইমার সেটিংস সেভ করুন'}</span>
                      </button>
                    </div>
                  </div>

                  {/* 1. DEDICATED WHATSAPP CONTACT & SUPPORT NUMBER CARD */}
                  <div id="whatsapp-settings-card" className="bg-white rounded-xl border-2 border-emerald-500/40 p-6 space-y-4 shadow-sm">
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-100 pb-3">
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 rounded-full bg-emerald-100 text-emerald-600 flex items-center justify-center shrink-0">
                          <svg className="w-6 h-6 fill-current" viewBox="0 0 24 24">
                            <path d="M12.04 2c-5.46 0-9.91 4.45-9.91 9.91 0 1.75.46 3.45 1.32 4.95L2.05 22l5.25-1.38c1.45.79 3.08 1.21 4.74 1.21 5.46 0 9.91-4.45 9.91-9.91 0-2.65-1.03-5.14-2.9-7.01A9.816 9.816 0 0012.04 2zm5.78 14.15c-.24.67-1.39 1.28-1.92 1.36-.5.08-1.14.12-3.66-.92-3.22-1.33-5.3-4.57-5.46-4.78-.16-.21-1.3-1.73-1.3-3.3 0-1.57.82-2.34 1.11-2.66.29-.32.64-.4.85-.4.21 0 .43.002.61.01.2.008.47-.076.73.55.27.64.91 2.22.99 2.38.08.16.13.35.03.56-.1.21-.16.34-.31.52-.16.18-.33.4-.47.54-.16.15-.32.32-.14.63.19.31.83 1.37 1.78 2.22 1.22 1.09 2.25 1.42 2.57 1.58.32.16.51.13.7-.08.19-.21.82-.95 1.04-1.28.22-.32.43-.27.73-.16.29.11 1.87.88 2.19 1.04.32.16.53.24.61.37.08.14.08.79-.16 1.46z" />
                          </svg>
                        </div>
                        <div>
                          <h3 className="text-base font-extrabold text-slate-900">
                            হোয়াটসঅ্যাপ সাপোর্ট নম্বর ও চ্যাট সেটিংস (WhatsApp Setup)
                          </h3>
                          <p className="text-xs text-slate-500">
                            এখানে আপনার নম্বরটি লিখুন। নম্বর টাইপ করার সাথে সাথেই wa.me লিঙ্ক স্বয়ংক্রিয় তৈরি হয়ে যাবে।
                          </p>
                        </div>
                      </div>

                      <span className="px-3 py-1 rounded-full bg-emerald-50 text-emerald-800 border border-emerald-300 text-xs font-bold tracking-tight">
                        🟢 সেভকৃত নম্বর: {whatsappNumber || 'নেই'}
                      </span>
                    </div>

                    <form onSubmit={handleSaveWhatsAppOnly} className="space-y-4">
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                        <div>
                          <label className="block text-xs font-bold text-slate-800 mb-1">
                            আপনার হোয়াটসঅ্যাপ নম্বর *
                          </label>
                          <input
                            type="text"
                            required
                            placeholder="যেমন: 01814-946474 অথবা 01608949565"
                            value={whatsappNumber}
                            onChange={(e) => handleWhatsappNumberChange(e.target.value)}
                            className="w-full px-3.5 py-2.5 rounded-xl border-2 border-emerald-500/60 focus:border-emerald-600 focus:outline-none text-sm font-bold text-slate-900 bg-emerald-50/25"
                          />
                          <span className="text-[11px] text-slate-400 mt-1 block">
                            যেকোনো ফরম্যাটে লিখুন (017... বা 018...)
                          </span>
                        </div>

                        <div>
                          <label className="block text-xs font-bold text-slate-800 mb-1">
                            জেনারেটেড হোয়াটসঅ্যাপ লিংক (wa.me URL)
                          </label>
                          <div className="flex items-center gap-2">
                            <input
                              type="url"
                              readOnly
                              value={whatsappLink}
                              className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 text-xs font-mono bg-slate-100 text-slate-700"
                            />
                            {whatsappLink && (
                              <a
                                href={whatsappLink}
                                target="_blank"
                                rel="noreferrer"
                                className="px-3.5 py-2.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-white text-xs font-bold whitespace-nowrap transition cursor-pointer"
                                title="নতুন ট্যাবে লিংকটি টেস্ট করুন"
                              >
                                টেস্ট ↗
                              </a>
                            )}
                          </div>
                        </div>
                      </div>

                      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pt-2">
                        <span className="text-[11px] text-slate-500">
                          💾 এই সেভ বাটনে চাপ দিলে নম্বরটি ডাটাবেজে স্থায়ীভাবে সেভ থাকবে।
                        </span>

                        <button
                          type="submit"
                          disabled={savingWhatsApp}
                          className="px-6 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-extrabold shadow-md hover:shadow-lg transition cursor-pointer flex items-center justify-center gap-2 disabled:opacity-50"
                        >
                          <span className="material-symbols-outlined text-[18px]">
                            {savingWhatsApp ? 'hourglass_empty' : 'save'}
                          </span>
                          <span>{savingWhatsApp ? 'সেভ হচ্ছে...' : 'হোয়াটসঅ্যাপ নম্বর সেভ করুন'}</span>
                        </button>
                      </div>
                    </form>
                  </div>

                  {/* 2. GENERAL WEBSITE BRANDING & SETTINGS CARD */}
                  <div className="bg-white rounded-xl border border-slate-200 p-6 space-y-5">
                    <div>
                      <h3 className="text-base font-extrabold text-slate-900">
                        ওয়েবসাইট ব্র্যান্ডিং ও হিরো সেকশন সেটিংস
                      </h3>
                      <p className="text-xs text-slate-500">
                        হোমপেজের মূল শিরোনাম, হিরো ব্যানার এবং রেফারেল কোড পরিবর্তন করুন।
                      </p>
                    </div>

                  <form onSubmit={handleSaveSettings} className="space-y-4">

                    <div>
                      <label className="block text-xs font-bold text-slate-700 mb-1">
                        হিরো টপ ব্যাজ টেক্সট
                      </label>
                      <input
                        type="text"
                        value={heroBadge}
                        onChange={(e) => setHeroBadge(e.target.value)}
                        className="w-full px-3.5 py-2 rounded-xl border border-slate-300 text-xs"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-bold text-slate-700 mb-1">
                        হিরো মূল শিরোনাম (Hero Headline)
                      </label>
                      <input
                        type="text"
                        value={heroTitle}
                        onChange={(e) => setHeroTitle(e.target.value)}
                        className="w-full px-3.5 py-2 rounded-xl border border-slate-300 text-xs"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-bold text-slate-700 mb-1">
                        হিরো সাবটাইটেল (Hero Description)
                      </label>
                      <textarea
                        rows={2}
                        value={heroSubtitle}
                        onChange={(e) => setHeroSubtitle(e.target.value)}
                        className="w-full px-3.5 py-2 rounded-xl border border-slate-300 text-xs"
                      />
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      <div>
                        <label className="block text-xs font-bold text-slate-700 mb-1">
                          কাউন্টডাউন টাইমার লেবেল
                        </label>
                        <input
                          type="text"
                          value={countdownLabel}
                          onChange={(e) => setCountdownLabel(e.target.value)}
                          className="w-full px-3.5 py-2 rounded-xl border border-slate-300 text-xs"
                        />
                      </div>
                      <div>
                        <label className="block text-xs font-bold text-slate-700 mb-1">
                          ডিফল্ট অ্যাফিলিয়েট রেফারেল কোড
                        </label>
                        <input
                          type="text"
                          value={defaultAffiliateRef}
                          onChange={(e) => setDefaultAffiliateRef(e.target.value)}
                          className="w-full px-3.5 py-2 rounded-xl border border-slate-300 text-xs font-mono"
                        />
                      </div>
                    </div>

                    <button
                      type="submit"
                      disabled={savingSettings}
                      className="px-6 py-2.5 rounded-xl bg-red-600 hover:bg-red-700 text-white text-xs font-bold cursor-pointer disabled:opacity-50"
                    >
                      {savingSettings ? 'সেভ হচ্ছে...' : 'সেটিংস সেভ করুন'}
                    </button>
                  </form>
                </div>
              </div>
            )}
          </>
        )}
        </main>
      </div>
    </div>
  );
};
